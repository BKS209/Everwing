using System;
using System.Diagnostics;
using System.IO;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using DragonArchive;

namespace Everwing.Views;

public sealed class BackgroundLayer : Control
{
    private readonly record struct Scene(IBrush? Gradient, Bitmap? Bitmap, BackgroundImage? Image);

    private readonly DispatcherTimer fade = new() { Interval = TimeSpan.FromMilliseconds(16) };
    private Scene current;
    private Scene? outgoing;
    private long? fadeStarted;

    public BackgroundLayer() => fade.Tick += (_, _) => InvalidateVisual();

    internal void Show(Bitmap? next, BackgroundImage? placement, IBrush? gradient = null, bool animate = false)
    {
        Scene previous = current;
        current = new Scene(gradient ?? previous.Gradient, next, placement);
        if (animate && outgoing == null)
            outgoing = previous;
        else if (!ReferenceEquals(previous.Bitmap, next))
            previous.Bitmap?.Dispose();
        InvalidateVisual();
    }

    internal void SetGradient(IBrush gradient)
    {
        current = current with { Gradient = gradient };
        InvalidateVisual();
    }

    internal void Clear()
    {
        FinishFade();
        Show(null, null);
    }

    private void FinishFade()
    {
        fade.Stop();
        fadeStarted = null;
        if (!ReferenceEquals(outgoing?.Bitmap, current.Bitmap)) outgoing?.Bitmap?.Dispose();
        outgoing = null;
    }

    internal static Bitmap OpenImage(string path)
    {
        using var stream = File.OpenRead(path);
        return new Bitmap(stream);
    }

    public override void Render(DrawingContext context)
    {
        var area = new Rect(Bounds.Size);
        if (area.Width <= 0 || area.Height <= 0) return;
        DrawScene(context, area, current);
        if (outgoing is not { } previous) return;

        double progress = fadeStarted is { } started
            ? Math.Clamp(Stopwatch.GetElapsedTime(started).TotalMilliseconds / 420, 0, 1)
            : 0;
        if (progress >= 1)
        {
            FinishFade();
            return;
        }

        using (context.PushRenderOptions(new RenderOptions { RequiresFullOpacityHandling = true }))
        using (context.PushOpacity(Math.Pow(1 - progress, 3)))
            DrawScene(context, area, previous);
        if (fadeStarted == null)
        {
            fadeStarted = Stopwatch.GetTimestamp();
            fade.Start();
        }
    }

    private void DrawScene(DrawingContext context, Rect area, Scene scene)
    {
        if (scene.Gradient != null) context.FillRectangle(scene.Gradient, area);
        if (scene.Bitmap is not { } bitmap || scene.Image is not { } image) return;
        Size source = bitmap.Size;
        double scale = Math.Max(area.Width / source.Width, area.Height / source.Height) * image.Scale;
        double width = source.Width * scale;
        double height = source.Height * scale;
        Point center = new(area.Center.X + area.Width * image.X, area.Center.Y + area.Height * image.Y);
        Matrix transform = Matrix.CreateScale(image.MirrorX ? -1 : 1, image.MirrorY ? -1 : 1)
            * Matrix.CreateRotation(image.Angle * Math.PI / 180)
            * Matrix.CreateTranslation(center.X, center.Y);
        using (context.PushClip(area))
        using (context.PushOpacity(image.Opacity))
        using (context.PushTransform(transform))
            context.DrawImage(bitmap, new Rect(-width / 2, -height / 2, width, height));
    }
}
