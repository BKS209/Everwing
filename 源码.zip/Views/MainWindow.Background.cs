using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using DragonArchive;

namespace Everwing.Views;

public partial class MainWindow
{
    private readonly DispatcherTimer backgroundTimer = new();
    private readonly HashSet<string> unavailableBackgrounds = new(StringComparer.OrdinalIgnoreCase);
    private BackgroundLayer backgroundLayer = null!;
    private BackgroundStore? backgroundStore;
    private BackgroundPool backgroundPool = new();
    private string? backgroundKey;
    private int backgroundIndex = -1;
    private string? ActiveBackground => backgroundIndex >= 0 ? backgroundPool.Images[backgroundIndex].FileName : null;

    private static LinearGradientBrush BackgroundGradient(AiProfile profile) => new()
    {
        StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative),
        EndPoint = new RelativePoint(1, 1, RelativeUnit.Relative),
        GradientStops =
        {
            new GradientStop(C(profile.BgTop), 0),
            new GradientStop(C(profile.BgMid), .45),
            new GradientStop(C(profile.BgBot), 1)
        }
    };

    private void InitializeBackground()
    {
        backgroundLayer = N<BackgroundLayer>("ProfileBackground");
        backgroundTimer.Tick += (_, _) => ChangeBackground(1);
        Closed += (_, _) => { backgroundTimer.Stop(); backgroundLayer.Clear(); };
    }

    private void LoadBackground(string key, string? preferred = null, IBrush? gradient = null, bool animate = false)
    {
        backgroundTimer.Stop();
        backgroundKey = key;
        backgroundIndex = -1;
        unavailableBackgrounds.Clear();
        backgroundStore = new BackgroundStore(key);
        try { backgroundPool = backgroundStore.Load(); }
        catch (Exception) { backgroundPool = new(); }
        int preferredIndex = backgroundPool.Images.FindIndex(image => image.FileName == preferred);
        var next = FindBackground(Math.Max(0, preferredIndex), 1);
        backgroundLayer.Show(next.Bitmap, next.Image, gradient, animate);
        RestartBackgroundTimer();
    }

    private void RestartBackgroundTimer()
    {
        backgroundTimer.Stop();
        if (backgroundPool.AutoRotate && backgroundPool.Images.Count - unavailableBackgrounds.Count > 1)
        {
            backgroundTimer.Interval = TimeSpan.FromSeconds(backgroundPool.IntervalSeconds);
            backgroundTimer.Start();
        }
    }

    private void ChangeBackground(int step)
    {
        bool animate = backgroundIndex >= 0;
        var next = FindBackground(animate ? backgroundIndex + step : 0, step);
        if (next.Bitmap != null) backgroundLayer.Show(next.Bitmap, next.Image, animate: animate);
        RestartBackgroundTimer();
    }

    private (Bitmap? Bitmap, BackgroundImage? Image) FindBackground(int start, int step)
    {
        int count = backgroundPool.Images.Count;
        if (backgroundStore == null || count == 0) return default;
        int index = (start + count) % count;
        for (int i = 0; i < count; i++, index = (index + step + count) % count)
        {
            if (index == backgroundIndex) return default;
            var image = backgroundPool.Images[index];
            if (unavailableBackgrounds.Contains(image.FileName)) continue;
            try
            {
                var next = BackgroundLayer.OpenImage(backgroundStore.PathFor(image));
                backgroundIndex = index;
                return (next, image);
            }
            catch (Exception) { unavailableBackgrounds.Add(image.FileName); }
        }
        return default;
    }

    private async Task EditBackground(AiProfile profile)
    {
        var pictures = new BackgroundStore(profile.Key);
        bool isActive = string.Equals(backgroundKey, profile.Key, StringComparison.OrdinalIgnoreCase);
        string? previous = isActive ? ActiveBackground : null;
        if (isActive) backgroundTimer.Stop();
        try
        {
            var dialog = new BackgroundEditor(profile, pictures, pictures.Load(), this, previous);
            if (await dialog.ShowDialog<bool>(this) && isActive)
            {
                LoadBackground(profile.Key, dialog.SelectedFile);
                RefreshSettings();
            }
        }
        catch (Exception ex) { statusText.Text = "无法打开背景图片池：" + ex.Message; }
        finally { if (isActive) RestartBackgroundTimer(); }
    }
}
