using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Threading;
using DragonArchive;

namespace Everwing.Views;

public partial class MainWindow
{
    private const double WanderFramesPerSecond = 30;
    private static readonly TimeSpan WanderFrameInterval = TimeSpan.FromSeconds(1 / WanderFramesPerSecond);
    private static readonly TimeSpan WanderFrameTolerance = TimeSpan.FromMilliseconds(2);
    private Action<TimeSpan> drawWanderFrame = null!;
    private TimeSpan? wanderNextFrame;
    private bool wanderFramePending;
    private bool wanderClosed;
    private readonly List<(string Text, string Meta, IBrush Ink)> wanderLines = new();
    private readonly List<(StackPanel Card, TranslateTransform Offset, long Started, Point From, Point To)> wanderCards = new();
    private Grid wanderMain = null!;
    private Canvas wanderCanvas = null!;
    private Button wanderReturn = null!;
    private Button wanderEnter = null!;
    private readonly TranslateTransform wanderOffset = new();
    private Control? wanderFocus;
    private bool wanderActive;
    private bool wanderSliding;
    private TimeSpan? wanderSlideStart;
    private bool wanderLinesReady;
    private long? wanderLastLine;
    private int wanderIndex;
    private int wanderMaxLines;

    private void InitializeMessageWander()
    {
        wanderMain = N<Grid>("MainInterface");
        wanderCanvas = N<Canvas>("WanderCanvas");
        wanderReturn = N<Button>("ExitWander");
        wanderEnter = N<Button>("EnterWander");
        InitializeWanderBackground();
        wanderMain.RenderTransform = wanderOffset;
        AddHandler(InputElement.KeyDownEvent, (_, e) =>
        {
            if (wanderSliding) e.Handled = true;
        }, RoutingStrategies.Tunnel);
        wanderEnter.AddHandler(InputElement.PointerPressedEvent, (_, _) =>
        {
            if (!wanderActive && !wanderSliding) wanderFocus = FocusManager?.GetFocusedElement() as Control;
        }, RoutingStrategies.Tunnel);
        wanderEnter.Click += (_, _) => SlideMessageWander(true);
        wanderReturn.Click += (_, _) => SlideMessageWander(false);
        drawWanderFrame = OnWanderFrame;
        wanderCanvas.SizeChanged += (_, _) =>
        {
            foreach (var item in wanderCards)
                item.Card.MaxWidth = Math.Max(1, wanderCanvas.Bounds.Width - 32);
        };
        Closed += (_, _) => wanderClosed = true;
    }

    private void SlideMessageWander(bool enter)
    {
        if (wanderSliding || enter == wanderActive) return;
        if (enter)
        {
            wanderFocus ??= FocusManager?.GetFocusedElement() as Control;
            wanderLinesReady = false;
            wanderMain.IsHitTestVisible = false;
            PrepareWanderBackground();
        }
        else
        {
            wanderBackgroundTimer.Stop();
            wanderCanvas.Children.Clear();
            wanderCards.Clear();
            wanderLines.Clear();
            wanderCanvas.IsVisible = false;
            wanderReturn.IsVisible = false;
            wanderMain.IsVisible = true;
            wanderOffset.Y = Bounds.Height;
        }
        wanderActive = enter;
        wanderSliding = true;
        wanderSlideStart = null;
        wanderNextFrame = null;
        QueueWanderFrame();
    }

    private void PrepareWanderLines()
    {
        if (wanderClosed || !wanderActive || wanderSliding) return;
        wanderMaxLines = AppSettings.Load().WanderMaxLines;
        wanderLines.Clear();
        foreach (var profile in profiles)
        {
            List<ArchiveRecord> entries;
            try { entries = store.Load(profile.Key); }
            catch { continue; }
            var ink = Br(ColorUtil.Mix(profile.AccentColor, System.Drawing.Color.Black, .32f));
            foreach (var record in entries.Where(r => r.Type == "message"))
            {
                string meta = QuoteMetaText(record, profile.Name);
                foreach (string sentence in Regex.Split(record.Text ?? "", @"(?<=[。！？!?；;])\s*|(?<=\.)\s+|[\r\n]+"))
                {
                    string line = sentence.Trim();
                    // Break unusually long entries into readable pieces.
                    while (line.Length > 160)
                    {
                        int length = char.IsHighSurrogate(line[159]) ? 159 : 160;
                        wanderLines.Add((line[..length], meta, ink));
                        line = line[length..].TrimStart();
                    }
                    if (line.Length > 0) wanderLines.Add((line, meta, ink));
                }
            }
        }
        ShuffleWanderLines();
        wanderLastLine = null;
        wanderLinesReady = true;
    }

    private void ShuffleWanderLines()
    {
        for (int i = wanderLines.Count - 1; i > 0; i--)
        {
            int j = rnd.Next(i + 1);
            (wanderLines[i], wanderLines[j]) = (wanderLines[j], wanderLines[i]);
        }
        wanderIndex = 0;
    }

    private void QueueWanderFrame()
    {
        if (wanderClosed || wanderFramePending || (!wanderActive && !wanderSliding)) return;
        wanderFramePending = true;
        RequestAnimationFrame(drawWanderFrame);
    }

    private void OnWanderFrame(TimeSpan frameTime)
    {
        wanderFramePending = false;
        if (wanderClosed) return;

        if (wanderSliding)
        {
            UpdateWanderSlide(frameTime);
            QueueWanderFrame();
            return;
        }

        var deadline = wanderNextFrame ?? frameTime;
        if (frameTime + WanderFrameTolerance >= deadline)
        {
            // Keep the cadence anchored to the frame clock and skip missed steps.
            var next = deadline + WanderFrameInterval;
            wanderNextFrame = next <= frameTime ? frameTime + WanderFrameInterval : next;
            UpdateMessageWander();
        }
        QueueWanderFrame();
    }

    private void UpdateWanderSlide(TimeSpan frameTime)
    {
        wanderSlideStart ??= frameTime;
        double progress = Math.Clamp((frameTime - wanderSlideStart.Value).TotalMilliseconds / 380, 0, 1);
        double eased = progress * progress * (3 - 2 * progress);
        wanderOffset.Y = Bounds.Height * (wanderActive ? eased : 1 - eased);
        if (wanderBackgroundVisible) wanderBackground.Opacity = wanderActive ? eased : 1 - eased;
        if (progress < 1) return;

        wanderSliding = false;
        wanderMain.IsVisible = !wanderActive;
        if (!wanderActive)
        {
            FinishWanderBackground();
            wanderMain.IsHitTestVisible = true;
            if (wanderFocus?.Focus() != true) wanderEnter.Focus();
            wanderFocus = null;
            return;
        }
        wanderCanvas.IsVisible = true;
        wanderReturn.IsVisible = true;
        wanderReturn.Focus();
        if (wanderBackgroundVisible && wanderBackgroundPool.Count > 1) wanderBackgroundTimer.Start();
        Dispatcher.UIThread.Post(PrepareWanderLines, DispatcherPriority.Background);
    }

    private void UpdateMessageWander()
    {
        if (!wanderLinesReady) return;
        if (wanderCards.Count < wanderMaxLines && (wanderLastLine == null || (wanderLines.Count > 0 &&
            Stopwatch.GetElapsedTime(wanderLastLine.Value).TotalSeconds >= 6.0 / wanderMaxLines)))
        {
            AddWanderLine();
            wanderLastLine = Stopwatch.GetTimestamp();
        }

        for (int i = wanderCards.Count - 1; i >= 0; i--)
        {
            var item = wanderCards[i];
            double age = Stopwatch.GetElapsedTime(item.Started).TotalSeconds;
            if (wanderLines.Count > 0 && age >= 6)
            {
                wanderCanvas.Children.Remove(item.Card);
                wanderCards.RemoveAt(i);
                continue;
            }
            double progress = Math.Min(age / 6, 1);
            double x = item.From.X + (item.To.X - item.From.X) * progress;
            double y = item.From.Y + (item.To.Y - item.From.Y) * progress;
            item.Offset.X = 16 + x * Math.Max(0, wanderCanvas.Bounds.Width - item.Card.DesiredSize.Width - 32);
            item.Offset.Y = 16 + y * Math.Max(0, wanderCanvas.Bounds.Height - item.Card.DesiredSize.Height - 100);
            item.Card.Opacity = wanderLines.Count == 0 ? 1 : Math.Clamp(Math.Min(age / .65, (6 - age) / .85), 0, 1);
        }
    }

    private void AddWanderLine()
    {
        if (wanderIndex >= wanderLines.Count) ShuffleWanderLines();
        var (text, meta, ink) = wanderLines.Count == 0 ? ("还没有留言", "", brushInk) : wanderLines[wanderIndex++];
        var offset = new TranslateTransform();
        var card = new StackPanel
        {
            Spacing = 4, Opacity = 0, RenderTransform = offset,
            MaxWidth = Math.Max(1, wanderCanvas.Bounds.Width - 32)
        };
        card.Children.Add(new TextBlock
        {
            Text = text, Foreground = ink, FontSize = 17, TextWrapping = TextWrapping.Wrap
        });
        if (meta.Length > 0)
        {
            card.Children.Add(new TextBlock
            {
                Text = meta, Foreground = ink, FontSize = 12,
                TextAlignment = TextAlignment.Right, TextWrapping = TextWrapping.Wrap
            });
        }
        var start = wanderLines.Count == 0 ? new Point(.5, .5) : new Point(rnd.NextDouble(), rnd.NextDouble());
        var end = wanderLines.Count == 0 || rnd.Next(3) == 0
            ? start : new Point(rnd.NextDouble(), rnd.NextDouble());
        wanderCanvas.Children.Add(card);
        wanderCards.Add((card, offset, Stopwatch.GetTimestamp(), start, end));
    }
}
