using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Templates;
using Presenters = Avalonia.Controls.Presenters;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Styling;
using DragonArchive;

namespace Everwing.Views;

internal sealed partial class BackgroundEditor
{
    private void ApplyTheme(AiProfile profile)
    {
        static IBrush Brush(System.Drawing.Color color) => new SolidColorBrush(Color.Parse(ColorUtil.ToHex(color)));
        var ink = Brush(profile.Ink);
        var accent = Brush(profile.AccentColor);
        var card = Brush(profile.CardColor);
        var line = Brush(ColorUtil.Mix(profile.AccentColor, System.Drawing.Color.White, .55f));
        var soft = Brush(profile.Soft);
        Background = soft;
        Foreground = ink;

        void Style<T>(System.Func<Selector?, Selector> selector, params Setter[] setters) where T : Control
        {
            var style = new Style(s => selector(s.OfType<T>()));
            foreach (var setter in setters) style.Setters.Add(setter);
            Styles.Add(style);
        }

        Style<Button>(s => s!, new(Button.CornerRadiusProperty, new CornerRadius(16)),
            new(Button.PaddingProperty, new Thickness(13, 6)), new(Button.BorderThicknessProperty, new Thickness(1)),
            new(Button.BorderBrushProperty, line), new(Button.BackgroundProperty, card), new(Button.ForegroundProperty, ink));
        Style<Button>(s => s!.Class(":pointerover").Template().OfType<Presenters.ContentPresenter>().Name("PART_ContentPresenter"),
            new(Presenters.ContentPresenter.BackgroundProperty, soft), new(Presenters.ContentPresenter.BorderBrushProperty, accent),
            new(Presenters.ContentPresenter.ForegroundProperty, ink));
        Style<Button>(s => s!.Class("filled").Class(":pointerover").Template().OfType<Presenters.ContentPresenter>().Name("PART_ContentPresenter"),
            new(Presenters.ContentPresenter.BackgroundProperty, accent), new(Presenters.ContentPresenter.ForegroundProperty, Brushes.White));
        Style<TextBox>(s => s!, new(TextBox.CornerRadiusProperty, new CornerRadius(16)), new(TextBox.BorderBrushProperty, line),
            new(TextBox.BackgroundProperty, card), new(TextBox.ForegroundProperty, ink), new(TextBox.PaddingProperty, new Thickness(10, 4)));
        Style<TextBox>(s => s!.Class(":focus").Template().OfType<Border>().Name("PART_BorderElement"),
            new(Border.BorderBrushProperty, accent), new(Border.BackgroundProperty, card));
        Style<ToggleButton>(s => s!.Class("mirror"), new(ToggleButton.BorderBrushProperty, line),
            new(ToggleButton.BackgroundProperty, card), new(ToggleButton.ForegroundProperty, ink));
        Style<ToggleButton>(s => s!.Class("mirror").Class(":checked"),
            new(ToggleButton.BackgroundProperty, accent), new(ToggleButton.BorderBrushProperty, accent),
            new(ToggleButton.ForegroundProperty, Brushes.White));
        list.Background = card;
        list.BorderBrush = line;
        list.BorderThickness = new Thickness(1);
        list.CornerRadius = new CornerRadius(12);
        Style<ListBoxItem>(s => s!.Class(":selected").Template().OfType<Presenters.ContentPresenter>(),
            new(Presenters.ContentPresenter.BackgroundProperty, soft), new(Presenters.ContentPresenter.ForegroundProperty, ink));

        foreach (var toggle in new[] { mirrorX, mirrorY })
        {
            toggle.Classes.Add("mirror");
            toggle.Width = toggle.Height = 34;
            toggle.CornerRadius = new CornerRadius(17);
            toggle.BorderThickness = new Thickness(1);
            toggle.Padding = new Thickness(0);
            toggle.HorizontalContentAlignment = HorizontalAlignment.Center;
            toggle.VerticalContentAlignment = VerticalAlignment.Center;
            toggle.Template = new FuncControlTemplate<ToggleButton>((control, _) =>
            {
                var presenter = new Presenters.ContentPresenter();
                presenter.Bind(Presenters.ContentPresenter.ContentProperty, control.GetObservable(ContentControl.ContentProperty));
                presenter.Bind(Presenters.ContentPresenter.BackgroundProperty, control.GetObservable(BackgroundProperty));
                presenter.Bind(Presenters.ContentPresenter.ForegroundProperty, control.GetObservable(ForegroundProperty));
                presenter.Bind(Presenters.ContentPresenter.BorderBrushProperty, control.GetObservable(BorderBrushProperty));
                presenter.CornerRadius = new CornerRadius(17);
                presenter.BorderThickness = new Thickness(1);
                presenter.HorizontalContentAlignment = HorizontalAlignment.Center;
                presenter.VerticalContentAlignment = VerticalAlignment.Center;
                return presenter;
            });
        }
    }

    private static Control Mirror(string name, ToggleButton toggle)
    {
        AutomationProperties.SetName(toggle, name);
        ToolTip.SetTip(toggle, name);
        return Row(toggle, new TextBlock { Text = name, VerticalAlignment = VerticalAlignment.Center });
    }
}
