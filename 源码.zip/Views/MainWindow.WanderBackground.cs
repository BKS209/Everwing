using System;
using System.Collections.Generic;
using System.Linq;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using DragonArchive;

namespace Everwing.Views;

public partial class MainWindow
{
    private readonly DispatcherTimer wanderBackgroundTimer = new();
    private readonly List<(string Path, BackgroundImage Image, IBrush Gradient)> wanderBackgroundPool = new();
    private readonly List<string> recentWanderBackgrounds = new();
    private BackgroundLayer wanderBackground = null!;
    private bool wanderBackgroundVisible;

    private void InitializeWanderBackground()
    {
        wanderBackground = N<BackgroundLayer>("WanderBackground");
        wanderBackgroundTimer.Tick += (_, _) =>
        {
            ShowNextWanderBackground(animate: true);
            if (wanderBackgroundPool.Count <= 1) wanderBackgroundTimer.Stop();
        };
        Closed += (_, _) =>
        {
            wanderBackgroundTimer.Stop();
            wanderBackground.Clear();
        };
    }

    private Control BuildWanderBackgroundSettings(AppSettings settings)
    {
        const string rotationLabel = "留言漫游背景轮换";
        var enabled = new ToggleButton
        {
            Content = rotationLabel,
            Classes = { "wander-rotation" },
            IsChecked = settings.WanderBackgroundRotation,
            VerticalAlignment = VerticalAlignment.Center
        };
        AutomationProperties.SetName(enabled, rotationLabel);
        var interval = NumBox(settings.WanderBackgroundSeconds);
        interval.Width = 76;
        AutomationProperties.SetName(interval, rotationLabel + "间隔（秒）");
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        row.Children.Add(enabled);
        row.Children.Add(new TextBlock { Text = "间隔（秒）", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        row.Children.Add(interval);
        row.Children.Add(MakeButton("保存轮换", "", (_, _) =>
        {
            try
            {
                var latest = AppSettings.Load();
                latest.WanderBackgroundRotation = enabled.IsChecked == true;
                latest.WanderBackgroundSeconds = ReadNum(interval, latest.WanderBackgroundSeconds, 1, AppSettings.MaxWanderBackgroundSeconds);
                latest.Save();
                statusText.Text = "留言漫游轮换设置已保存。";
            }
            catch (Exception ex) { statusText.Text = "保存失败：" + ex.Message; }
        }));
        return row;
    }

    private void PrepareWanderBackground()
    {
        var settings = AppSettings.Load();
        if (!settings.WanderBackgroundRotation) return;

        foreach (var profile in profiles)
        {
            var store = new BackgroundStore(profile.Key);
            BackgroundPool pool;
            try { pool = store.Load(); }
            catch (Exception) { continue; }
            if (pool.Images.Count == 0) continue;
            var gradient = BackgroundGradient(profile);
            foreach (var image in pool.Images)
                wanderBackgroundPool.Add((store.PathFor(image), image, gradient));
        }

        if (!ShowNextWanderBackground(animate: false)) return;
        wanderBackgroundVisible = true;
        backgroundTimer.Stop();
        wanderBackgroundTimer.Interval = TimeSpan.FromSeconds(settings.WanderBackgroundSeconds);
    }

    private bool ShowNextWanderBackground(bool animate)
    {
        while (wanderBackgroundPool.Count > 0)
        {
            if (wanderBackgroundPool.Count == 1 && recentWanderBackgrounds.Contains(wanderBackgroundPool[0].Path)) return false;
            int historyLength = Math.Min(4, wanderBackgroundPool.Count - 1);
            var excluded = recentWanderBackgrounds.TakeLast(historyLength).ToHashSet();
            var candidates = wanderBackgroundPool.Where(entry => !excluded.Contains(entry.Path)).ToArray();
            var next = candidates[rnd.Next(candidates.Length)];
            Bitmap bitmap;
            try
            {
                bitmap = BackgroundLayer.OpenImage(next.Path);
            }
            catch (Exception)
            {
                wanderBackgroundPool.Remove(next);
                continue;
            }
            wanderBackground.Show(bitmap, next.Image, next.Gradient, animate);

            recentWanderBackgrounds.Add(next.Path);
            if (recentWanderBackgrounds.Count > 4) recentWanderBackgrounds.RemoveAt(0);
            return true;
        }
        return false;
    }

    private void FinishWanderBackground()
    {
        wanderBackgroundPool.Clear();
        recentWanderBackgrounds.Clear();
        if (!wanderBackgroundVisible) return;
        wanderBackgroundVisible = false;
        wanderBackground.Clear();
        RestartBackgroundTimer();
    }
}
