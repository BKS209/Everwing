using System;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Styling;

namespace Everwing.Views;

public partial class MainWindow
{
    private CancellationTokenSource? pageFade;

    private static async Task Fade(Control control, double from, double to, int milliseconds, CancellationToken token)
    {
        var animation = new Animation
        {
            Duration = TimeSpan.FromMilliseconds(milliseconds),
            Easing = new CubicEaseOut(),
            Children =
            {
                new KeyFrame { Cue = new Cue(0), Setters = { new Setter(OpacityProperty, from) } },
                new KeyFrame { Cue = new Cue(1), Setters = { new Setter(OpacityProperty, to) } }
            }
        };
        try { await animation.RunAsync(control, token); }
        catch (OperationCanceledException) { }
    }

    private async void AnimatePage()
    {
        pageFade?.Cancel();
        using var animation = new CancellationTokenSource();
        pageFade = animation;
        try { await Fade(pageHost, .48, 1, 220, animation.Token); }
        finally { if (ReferenceEquals(pageFade, animation)) pageFade = null; }
    }

    private static void AnimateDropdown(ComboBox combo, Action<Border>? stylePopup = null)
    {
        Popup? popup = null;
        CancellationTokenSource? current = null;
        async void Open(object? sender, EventArgs args)
        {
            if (popup?.Child is not Control content) return;
            if (content is Border border) stylePopup?.Invoke(border);
            current?.Cancel();
            using var animation = new CancellationTokenSource();
            current = animation;
            try { await Fade(content, .12, 1, 180, animation.Token); }
            finally { if (ReferenceEquals(current, animation)) current = null; }
        }
        void Close(object? sender, EventArgs args) => current?.Cancel();
        combo.TemplateApplied += (_, e) =>
        {
            if (popup != null)
            {
                popup.Opened -= Open;
                popup.Closed -= Close;
                current?.Cancel();
            }
            popup = e.NameScope.Find("PART_Popup") as Popup;
            if (popup == null) return;
            popup.Opened += Open;
            popup.Closed += Close;
        };
    }
}
