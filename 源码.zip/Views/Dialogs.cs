using System;
using System.Collections.Generic;
using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Input;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Styling;
using DragonArchive;

namespace Everwing.Views;

/// <summary>统一的二次确认窗：左取消、右确认，等宽居中。</summary>
public class ConfirmWindow : Window
{
    public ConfirmWindow(string title, string text, string okText, IBrush accentBrush, IBrush? surface = null, IBrush? ink = null, IBrush? line = null, string? required = null)
    {
        Title = title;
        Width = 520;
        SizeToContent = SizeToContent.Height;
        CanResize = false;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = surface ?? new SolidColorBrush(Color.FromArgb(0xFF, 0xF7, 0xF4, 0xFA));
        FontFamily = new FontFamily("Microsoft YaHei UI, SimSun, sans-serif");

        StackPanel root = new StackPanel { Margin = new Avalonia.Thickness(22, 18, 22, 16), Spacing = 14 };
        root.Children.Add(new TextBlock
        {
            Text = text,
            TextWrapping = TextWrapping.Wrap,
            FontSize = 13,
            Foreground = ink ?? new SolidColorBrush(Color.FromArgb(255, 0x4A, 0x3B, 0x5C))
        });

        StackPanel row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12, HorizontalAlignment = HorizontalAlignment.Center };
        Button cancel = new Button
        {
            Content = "取消", Width = 112, Height = 32,
            CornerRadius = new Avalonia.CornerRadius(16),
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            Padding = new Avalonia.Thickness(0), FontSize = 13
        };
        Button ok = new Button
        {
            Content = okText, Width = 112, Height = 32,
            CornerRadius = new Avalonia.CornerRadius(16),
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            Padding = new Avalonia.Thickness(0), FontSize = 13,
            Background = accentBrush,
            BorderBrush = accentBrush,
            Foreground = Brushes.White
        };
        TextBox? input = null;
        if (required != null)
        {
            input = new TextBox
            {
                Watermark = required, CornerRadius = new CornerRadius(12),
                Background = surface, Foreground = ink, BorderBrush = line
            };
            Avalonia.Automation.AutomationProperties.SetName(input, "删除确认");
            root.Children.Add(input);
            ok.IsEnabled = false;
            input.TextChanged += (_, _) => ok.IsEnabled = Matches();
            Opened += (_, _) => input.Focus();
        }
        if (surface != null)
        {
            cancel.Background = surface;
            cancel.Foreground = ink;
            cancel.BorderBrush = line;
        }

        bool Matches() => required == null ||
            string.Equals(input?.Text?.Trim(), required, StringComparison.OrdinalIgnoreCase);

        cancel.Click += (_, _) => Close(false);
        ok.Click += (_, _) => { if (Matches()) Close(true); };
        row.Children.Add(cancel);
        row.Children.Add(ok);
        root.Children.Add(row);

        Content = root;
        KeyDown += (s, e) =>
        {
            if (e.Key == Key.Escape) { e.Handled = true; Close(false); }
            if (e.Key == Key.Enter && (required == null || input?.IsFocused == true)) { e.Handled = true; if (Matches()) Close(true); }
        };
    }
}

/// <summary>标记编辑：版本号 / 第几任 / 自定义（带标签）。</summary>
public class MarkerEditor : Window
{
    private readonly TextBox? labelBox;
    private readonly TextBox valueBox;

    public string ResultLabel = "";
    public string ResultValue = "";
    public bool IsCustomKey;

    public MarkerEditor(string title, bool custom, string label, string value, AiProfile profile, Predicate<string> validate)
    {
        RecordEditTheme.Apply(this, profile);
        IsCustomKey = custom;
        Title = title;
        Width = 420;
        SizeToContent = SizeToContent.Height;
        CanResize = false;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FontFamily = new FontFamily("Microsoft YaHei UI, SimSun, sans-serif");

        StackPanel root = new StackPanel { Margin = new Avalonia.Thickness(20, 16, 20, 14), Spacing = 10 };
        root.Children.Add(new TextBlock
        {
            Text = custom ? "自定义标记：写标签，也可以附上值，比如「指挥官 / M4A1」。" : "只填数字；留空表示不写这一项。",
            FontSize = 12,
            TextWrapping = TextWrapping.Wrap
        });

        if (custom)
        {
            root.Children.Add(new TextBlock { Text = "标记文字", FontSize = 12 });
            labelBox = new TextBox { Text = label, Watermark = "如 指挥官", FontSize = 13 };
            root.Children.Add(labelBox);
        }
        else labelBox = null;

        root.Children.Add(new TextBlock { Text = custom ? "值" : "值（数字）", FontSize = 12 });
        valueBox = new TextBox { Text = value, Watermark = custom ? "可选" : "如 3", FontSize = 13 };
        root.Children.Add(valueBox);

        StackPanel row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12, HorizontalAlignment = HorizontalAlignment.Center };
        Button cancel = new Button { Content = "取消", Width = 112 };
        Button ok = new Button { Content = "确定", Width = 112, Classes = { "primary" } };
        TextBlock error = new TextBlock { TextWrapping = TextWrapping.Wrap, IsVisible = false };
        cancel.Click += (s, e) => Close(false);
        ok.Click += (s, e) =>
        {
            ResultLabel = (labelBox == null ? "" : (labelBox.Text ?? "")).Trim();
            ResultValue = (valueBox.Text ?? "").Trim();
            error.Text = custom
                ? (ResultLabel.Length == 0 ? "请输入标签名称。" : ResultLabel.Contains('=') ? "标签名称不能包含等号。" : "")
                : (validate(ResultValue) ? "" : "请填 1–3 位数字、未知，或留空。");
            error.IsVisible = error.Text.Length > 0;
            if (error.IsVisible) return;
            Close(true);
        };
        row.Children.Add(cancel);
        row.Children.Add(ok);
        root.Children.Add(error);
        root.Children.Add(row);
        Content = root;
    }
}

    public class AccentDialog : Window
    {
        private readonly string[] presets = new string[]
        {
            "#8B6FB4", "#6F8FC9", "#1A1B20", "#7C6FD6", "#C97B5A",
            "#5FA98B", "#D08AA8", "#B48A5F", "#8AA8D0", "#9C8AAE", "#FFF4E6", "#FFFDF5"
        };
        private TextBox hexBox = null!;
        private Border preview = null!;
        private string selected;

        public string SelectedHex { get { return selected; } }

        public AccentDialog(string initial, AiProfile theme, bool optional = false)
        {
            selected = string.IsNullOrEmpty(initial) && !optional ? "#8B6FB4" : initial;
            Title = optional ? "选副色" : "选主色";
            Width = 460;
            Height = 250;
            SizeToContent = SizeToContent.Height;
            CanResize = false;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            RecordEditTheme.Apply(this, theme);
            var outline = new SolidColorBrush(Color.Parse(ColorUtil.ToHex(theme.Line)));

            StackPanel root = new StackPanel { Margin = new Thickness(20), Spacing = 12 };
            root.Children.Add(new TextBlock { Text = optional ? "选一个副色（也可输入色值或清空）" : "选一个主色（也可以直接填 Hex）", FontSize = 13 });

            WrapPanel sw = new WrapPanel { Orientation = Orientation.Horizontal };
            foreach (string hex in presets)
            {
                Border dot = new Border
                {
                    Width = 30, Height = 30, CornerRadius = new CornerRadius(15),
                    Margin = new Thickness(0, 0, 10, 10),
                    Background = new SolidColorBrush(Color.Parse(hex)),
                    BorderBrush = outline,
                    BorderThickness = new Thickness(1),
                    Cursor = new Cursor(StandardCursorType.Hand)
                };
                string hh = hex;
                dot.PointerPressed += (s, e) => { SetHex(hh); };
                sw.Children.Add(dot);
            }
            root.Children.Add(sw);

            StackPanel line = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10, VerticalAlignment = VerticalAlignment.Center };
            preview = new Border { Width = 28, Height = 28, CornerRadius = new CornerRadius(14), BorderBrush = outline, BorderThickness = new Thickness(1) };
            hexBox = new TextBox { Width = 130, FontSize = 13, Text = selected, VerticalContentAlignment = VerticalAlignment.Center };
            hexBox.TextChanged += (s, e) => { Validate(); };
            line.Children.Add(preview);
            line.Children.Add(hexBox);
            root.Children.Add(line);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12, HorizontalAlignment = HorizontalAlignment.Right };
            Button cancel = new Button { Content = "取消", Width = 96, Height = 32 };
            cancel.Click += (s, e) => Close(false);
            Button ok = new Button { Content = "确定", Width = 96, Height = 32, Classes = { "primary" } };
            ok.Click += (s, e) => { if (Validate()) Close(true); };
            if (optional)
            {
                Button clear = new Button { Content = "清空副色", Height = 32 };
                clear.Click += (_, _) => { selected = ""; Close(true); };
                btns.Children.Add(clear);
            }
            btns.Children.Add(cancel);
            btns.Children.Add(ok);
            root.Children.Add(btns);

            Content = root;
            Validate();
        }

        private void SetHex(string hex)
        {
            selected = hex;
            hexBox.Text = hex;
            Validate();
        }

        private bool Validate()
        {
            string t = (hexBox.Text ?? "").Trim();
            bool ok = false;
            try { Color c = Color.Parse(t); preview.Background = new SolidColorBrush(c); ok = true; } catch { preview.Background = Brushes.Transparent; }
            if (ok) selected = t;
            return ok;
        }
    }

internal static class RecordEditTheme
{
    public static void Apply(Window window, AiProfile profile)
    {
        static IBrush Brush(System.Drawing.Color color) => new SolidColorBrush(Color.Parse(ColorUtil.ToHex(color)));
        var accent = profile.AccentColor;
        var normal = Brush(accent);
        var ink = Brush(profile.Ink);
        var light = Brush(ColorUtil.Mix(accent, System.Drawing.Color.White, .94f));
        var hover = Brush(ColorUtil.Mix(accent, System.Drawing.Color.White, .83f));
        var pressed = Brush(ColorUtil.Mix(accent, System.Drawing.Color.White, .72f));
        var line = Brush(ColorUtil.Mix(accent, System.Drawing.Color.White, .58f));
        var darkHover = Brush(ColorUtil.Mix(accent, System.Drawing.Color.Black, .14f));
        var darkPressed = Brush(ColorUtil.Mix(accent, System.Drawing.Color.Black, .25f));
        var fieldLine = Brush(ColorUtil.Mix(accent, System.Drawing.Color.FromArgb(48, 48, 48), .24f));
        var fieldFill = Brush(profile.CardColor);
        window.Background = light;
        window.Foreground = ink;
        var onAccent = accent.R * .299 + accent.G * .587 + accent.B * .114 >= 153 ? Brushes.Black : Brushes.White;

        void Add(Style style, params Setter[] setters)
        {
            foreach (var setter in setters) style.Setters.Add(setter);
            window.Styles.Add(style);
        }

        Add(new Style(s => s.OfType<Button>()),
            new(Button.CornerRadiusProperty, new CornerRadius(16)), new(Button.BackgroundProperty, light),
            new(Button.BorderBrushProperty, line), new(Button.BorderThicknessProperty, new Thickness(1)),
            new(Button.ForegroundProperty, ink), new(Button.HeightProperty, 32d),
            new(Button.PaddingProperty, new Thickness(11, 0)),
            new(Button.HorizontalContentAlignmentProperty, HorizontalAlignment.Center),
            new(Button.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        Add(new Style(s => s.OfType<Button>().Class("primary")),
            new(Button.BackgroundProperty, normal), new(Button.BorderBrushProperty, normal), new(Button.ForegroundProperty, onAccent));

        Add(new Style(s => s.OfType<TextBox>()),
            new(TextBox.CornerRadiusProperty, new CornerRadius(13)), new(TextBox.BackgroundProperty, fieldFill),
            new(TextBox.BorderBrushProperty, fieldLine), new(TextBox.BorderThicknessProperty, new Thickness(1)),
            new(TextBox.ForegroundProperty, ink), new(TextBox.PaddingProperty, new Thickness(11, 7)));
        foreach (var state in new[] { ":pointerover", ":focus" })
        {
            Add(new Style(s => s.OfType<TextBox>().Class(state).Template().OfType<Border>().Name("PART_BorderElement")),
                new(Border.BackgroundProperty, fieldFill), new(Border.BorderBrushProperty, darkHover),
                new(Border.BorderThicknessProperty, new Thickness(1)));
        }

        void ButtonState(string state, bool primary, IBrush fill)
        {
            Add(new Style(s => (primary ? s.OfType<Button>().Class("primary") : s.OfType<Button>())
                .Class(state).Template().OfType<ContentPresenter>().Name("PART_ContentPresenter")),
                new(ContentPresenter.BackgroundProperty, fill), new(ContentPresenter.BorderBrushProperty, normal),
                new(ContentPresenter.ForegroundProperty, primary ? onAccent : ink));
        }
        ButtonState(":pointerover", false, hover);
        ButtonState(":pointerover", true, darkHover);
        ButtonState(":pressed", false, pressed);
        ButtonState(":pressed", true, darkPressed);
    }
}

internal sealed class TextEditDialog : Window
{
    private readonly WrapPanel markers = new WrapPanel();
    private readonly List<Marker> tags;
    private string version;
    private string generation;

    public TextEditDialog(ArchiveRecord record, AiProfile profile, ArchiveStore store)
    {
        Title = "编辑这条记录";
        Width = 640;
        Height = 500;
        MinWidth = 480;
        MinHeight = 320;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        RecordEditTheme.Apply(this, profile);
        version = record.Version;
        generation = record.Generation;
        tags = record.Markers.Where(m => !m.IsVersion && !m.IsGeneration).Select(m => m.Copy()).ToList();

        var root = new Grid { RowDefinitions = new RowDefinitions("*,Auto,Auto"), Margin = new Thickness(18) };
        var box = new TextBox
        {
            Text = record.Text, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap,
            FontSize = 13, VerticalContentAlignment = VerticalAlignment.Top
        };
        root.Children.Add(box);

        var footer = new Grid { ColumnDefinitions = new ColumnDefinitions("*,Auto"), Margin = new Thickness(0, 12, 0, 0) };
        var markerScroll = new ScrollViewer
        {
            Content = markers, MaxHeight = 112, Margin = new Thickness(0, 0, 10, 0),
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        footer.Children.Add(markerScroll);
        var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Bottom, Spacing = 8 };
        var cancel = new Button { Content = "取消", MinWidth = 62 };
        var save = new Button { Content = "保存", MinWidth = 68, Classes = { "primary" } };
        var error = new TextBlock { TextWrapping = TextWrapping.Wrap, IsVisible = false, Margin = new Thickness(0, 8, 0, 0) };
        cancel.Click += (s, e) => Close(false);
        save.Click += (s, e) =>
        {
            try { store.UpdateRecord(record, box.Text ?? "", version, generation, tags); }
            catch (Exception ex)
            {
                error.Text = "保存失败。" + ex.Message;
                error.IsVisible = true;
                return;
            }
            Close(true);
        };
        actions.Children.Add(cancel);
        actions.Children.Add(save);
        Grid.SetColumn(actions, 1);
        footer.Children.Add(actions);
        Grid.SetRow(footer, 1);
        root.Children.Add(footer);
        Grid.SetRow(error, 2);
        root.Children.Add(error);
        Content = root;

        Button AddMarkerButton(string text, string tip, Action click)
        {
            var caption = new TextBlock { Text = text, MaxWidth = 176, TextTrimming = TextTrimming.CharacterEllipsis };
            var button = new Button { Content = caption, Margin = new Thickness(0, 0, 6, 5) };
            Avalonia.Automation.AutomationProperties.SetName(button, tip);
            ToolTip.SetTip(button, tip);
            button.Click += (s, e) => click();
            return button;
        }

        async void EditMarker(string title, string value, Action<string> update)
        {
            var dialog = new MarkerEditor(title, false, "", value, profile, store.IsValidVersion);
            if (!await dialog.ShowDialog<bool>(this)) return;
            update(dialog.ResultValue);
            RefreshMarkers();
        }

        async void EditTag(Marker? tag)
        {
            var dialog = new MarkerEditor(tag == null ? "添加自定义标签" : "编辑自定义标签", true,
                tag?.Label ?? "", tag?.Value ?? "", profile, store.IsValidVersion);
            if (!await dialog.ShowDialog<bool>(this)) return;
            var updated = new Marker("C", dialog.ResultLabel, dialog.ResultValue);
            if (tag == null) tags.Add(updated);
            else tags[tags.IndexOf(tag)] = updated;
            RefreshMarkers();
        }

        void RefreshMarkers()
        {
            markers.Children.Clear();
            markers.Children.Add(AddMarkerButton(version is "" or "未知" ? "版本" : "V" + version, "编辑版本",
                () => EditMarker("版本（V几）", version, value => version = value)));
            markers.Children.Add(AddMarkerButton(generation is "" or "未知" ? "任期" : "第" + generation + "任", "编辑任期",
                () => EditMarker("任期（第几任）", generation, value => generation = value)));
            markers.Children.Add(AddMarkerButton("＋ 自定义标签", "添加自定义标签", () => EditTag(null)));
            foreach (var tag in tags)
            {
                var pair = new StackPanel { Orientation = Orientation.Horizontal };
                pair.Children.Add(AddMarkerButton(tag.Display, "编辑标签 " + tag.Display, () => EditTag(tag)));
                pair.Children.Add(AddMarkerButton("×", "移除标签 " + tag.Display, () => { tags.Remove(tag); RefreshMarkers(); }));
                markers.Children.Add(pair);
            }
        }

        RefreshMarkers();
    }
}
