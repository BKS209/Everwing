using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using DragonArchive;

namespace Everwing.Views;

internal sealed partial class BackgroundEditor : Window
{
    private readonly BackgroundStore store;
    private readonly BackgroundPool pool;
    private readonly ListBox list = new() { Height = 254 };
    private readonly BackgroundLayer preview = new();
    private readonly Border previewFrame;
    private readonly StackPanel editor = new() { Spacing = 5 };
    private readonly TextBlock status = new() { TextWrapping = TextWrapping.Wrap };
    private readonly ScrubNumber x = new(-200, 200, "横向");
    private readonly ScrubNumber y = new(-200, 200, "纵向");
    private readonly ScrubNumber scale = new(25, 400, "缩放");
    private readonly ScrubNumber angle = new(-180, 180, "旋转");
    private readonly ScrubNumber opacity = new(0, 100, "不透明度");
    private readonly ToggleButton mirrorX = new() { Content = "↔" };
    private readonly ToggleButton mirrorY = new() { Content = "↕" };
    private readonly CheckBox rotate = new() { Content = "自动轮换" };
    private readonly ScrubNumber seconds = new(1, 86400, "轮换间隔");
    private BackgroundImage? selected;
    private bool binding;
    private Point? dragStart;
    private double dragX, dragY;
    private bool picking;
    internal string? SelectedFile => selected?.FileName;

    internal BackgroundEditor(AiProfile profile, BackgroundStore store, BackgroundPool pool, Window owner, string? activeFile)
    {
        this.store = store;
        this.pool = pool;
        Title = profile.Name + " · 背景图片";
        Width = 800;
        Height = 690;
        MinWidth = 700;
        MinHeight = 550;
        FontFamily = owner.FontFamily;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        ApplyTheme(profile);
        var accent = new SolidColorBrush(Color.Parse(ColorUtil.ToHex(profile.AccentColor)));
        previewFrame = new Border
        {
            Background = new LinearGradientBrush
            {
                EndPoint = new RelativePoint(1, 1, RelativeUnit.Relative),
                GradientStops = new GradientStops
                {
                    new(Color.Parse(ColorUtil.ToHex(profile.BgTop)), 0),
                    new(Color.Parse(ColorUtil.ToHex(profile.BgMid)), .45),
                    new(Color.Parse(ColorUtil.ToHex(profile.BgBot)), 1)
                }
            },
            ClipToBounds = true,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Child = preview
        };
        var previewHost = new Grid { Height = 255 };
        previewHost.Children.Add(previewFrame);
        void SizePreview()
        {
            double ratio = owner.Bounds.Height > 0 && owner.Bounds.Width > 0 ? owner.Bounds.Width / owner.Bounds.Height : 1.4;
            double width = Math.Min(previewHost.Bounds.Width, 255 * ratio);
            if (width <= 0) return;
            previewFrame.Width = width;
            previewFrame.Height = width / ratio;
        }
        previewHost.SizeChanged += (_, _) => SizePreview();
        EventHandler<SizeChangedEventArgs> ownerResized = (_, _) => SizePreview();
        owner.SizeChanged += ownerResized;
        Closed += (_, _) => { owner.SizeChanged -= ownerResized; preview.Show(null, null); };

        var left = new StackPanel { Spacing = 8 };
        left.Children.Add(new TextBlock { Text = "图片池", FontWeight = FontWeight.SemiBold });
        left.Children.Add(list);
        left.Children.Add(MakeButton("添加图片…", async () => await PickImages()));
        left.Children.Add(Row(MakeButton("上移", () => Move(-1)), MakeButton("下移", () => Move(1)), MakeButton("移出", Remove)));
        left.Children.Add(rotate);
        left.Children.Add(Field("间隔（秒）", seconds));
        rotate.IsChecked = pool.AutoRotate;
        seconds.Value = pool.IntervalSeconds;
        seconds.IsEnabled = pool.AutoRotate;
        rotate.IsCheckedChanged += (_, _) => seconds.IsEnabled = rotate.IsChecked == true;

        var right = new StackPanel { Spacing = 8 };
        right.Children.Add(new TextBlock { Text = "背景预览 · 拖动图片调整位置", FontWeight = FontWeight.SemiBold });
        right.Children.Add(previewHost);
        editor.Children.Add(Row(Field("横向 %", x), Field("纵向 %", y)));
        editor.Children.Add(Row(Field("缩放 %", scale), Field("旋转 °", angle)));
        editor.Children.Add(Row(Field("不透明度 %", opacity), MakeButton("重置调整", Reset)));
        editor.Children.Add(Row(Mirror("水平镜像", mirrorX), Mirror("垂直镜像", mirrorY)));
        right.Children.Add(editor);
        foreach (var input in new[] { x, y, scale, angle, opacity }) input.ValueChanged += (_, _) => ApplyInputs();
        mirrorX.IsCheckedChanged += (_, _) => ApplyInputs();
        mirrorY.IsCheckedChanged += (_, _) => ApplyInputs();
        previewFrame.PointerPressed += DragStarted;
        previewFrame.PointerMoved += DragMoved;
        previewFrame.PointerReleased += (_, e) => { dragStart = null; e.Pointer.Capture(null); };
        previewFrame.PointerCaptureLost += (_, _) => dragStart = null;
        list.SelectionChanged += (_, _) => { if (!binding) SelectImage(list.SelectedIndex); };

        var columns = new Grid { ColumnDefinitions = new ColumnDefinitions("225,20,*") };
        columns.Children.Add(left);
        Grid.SetColumn(right, 2);
        columns.Children.Add(right);
        var save = MakeButton("保存", Save);
        save.Classes.Add("filled");
        save.Background = accent;
        save.Foreground = Brushes.White;
        var buttons = Row(MakeButton("取消", () => Close(false)), save);
        buttons.HorizontalAlignment = HorizontalAlignment.Right;
        var layout = new Grid { Margin = new Thickness(20), RowDefinitions = new RowDefinitions("*,Auto,Auto") };
        layout.Children.Add(new ScrollViewer { Content = columns, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });
        Grid.SetRow(status, 1);
        status.Margin = new Thickness(0, 8);
        layout.Children.Add(status);
        Grid.SetRow(buttons, 2);
        layout.Children.Add(buttons);
        Content = layout;
        RefreshList(Math.Max(0, pool.Images.FindIndex(image => image.FileName == activeFile)));
    }

    private static Button MakeButton(string text, Action click)
    {
        var button = new Button { Content = text };
        button.Click += (_, _) => click();
        return button;
    }

    private static StackPanel Row(params Control[] controls)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        foreach (var control in controls) row.Children.Add(control);
        return row;
    }

    private static Control Field(string title, Control input) => Row(
        new TextBlock { Text = title, Width = 79, VerticalAlignment = VerticalAlignment.Center }, input);

    private void RefreshList(int index)
    {
        binding = true;
        list.ItemsSource = pool.Images.Select((image, i) => $"{i + 1}. {image.Label}").ToArray();
        list.SelectedIndex = pool.Images.Count == 0 ? -1 : Math.Clamp(index, 0, pool.Images.Count - 1);
        binding = false;
        SelectImage(list.SelectedIndex);
    }

    private void SelectImage(int index)
    {
        selected = index >= 0 && index < pool.Images.Count ? pool.Images[index] : null;
        editor.IsEnabled = selected != null;
        preview.Show(null, null);
        if (selected == null) return;
        LoadInputs();
        try { preview.Show(BackgroundLayer.OpenImage(store.PathFor(selected)), selected); }
        catch (Exception) { status.Text = "无法预览这张图片。文件可能已移走或损坏。"; }
    }

    private void LoadInputs()
    {
        if (selected == null) return;
        binding = true;
        x.Value = (decimal)(selected.X * 100);
        y.Value = (decimal)(selected.Y * 100);
        scale.Value = (decimal)(selected.Scale * 100);
        angle.Value = (decimal)selected.Angle;
        opacity.Value = (decimal)(selected.Opacity * 100);
        mirrorX.IsChecked = selected.MirrorX;
        mirrorY.IsChecked = selected.MirrorY;
        binding = false;
        preview.InvalidateVisual();
    }

    private void ApplyInputs()
    {
        if (binding || selected == null) return;
        selected.X = (double)x.Value / 100;
        selected.Y = (double)y.Value / 100;
        selected.Scale = (double)scale.Value / 100;
        selected.Angle = (double)angle.Value;
        selected.Opacity = (double)opacity.Value / 100;
        selected.MirrorX = mirrorX.IsChecked == true;
        selected.MirrorY = mirrorY.IsChecked == true;
        preview.InvalidateVisual();
    }

    private void DragStarted(object? sender, PointerPressedEventArgs e)
    {
        if (selected == null || !e.GetCurrentPoint(previewFrame).Properties.IsLeftButtonPressed) return;
        dragStart = e.GetPosition(previewFrame);
        dragX = selected.X;
        dragY = selected.Y;
        e.Pointer.Capture(previewFrame);
    }

    private void DragMoved(object? sender, PointerEventArgs e)
    {
        if (dragStart is not Point start || selected == null || preview.Bounds.Width <= 0 || preview.Bounds.Height <= 0) return;
        Vector delta = e.GetPosition(previewFrame) - start;
        selected.X = Math.Clamp(dragX + delta.X / preview.Bounds.Width, -2, 2);
        selected.Y = Math.Clamp(dragY + delta.Y / preview.Bounds.Height, -2, 2);
        LoadInputs();
    }

    private async Task PickImages()
    {
        if (picking) return;
        picking = true;
        try
        {
            var files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "添加背景图片", AllowMultiple = true,
                FileTypeFilter = new[] { new FilePickerFileType("图片") { Patterns = new[] { "*.png", "*.jpg", "*.jpeg", "*.webp", "*.bmp" } } }
            });
            ImportImages(files.Select(file => file.TryGetLocalPath()));
        }
        catch (Exception ex) { status.Text = "添加失败：" + ex.Message; }
        finally { picking = false; }
    }

    private void ImportImages(IEnumerable<string?> paths)
    {
        int first = pool.Images.Count;
        int skipped = 0;
        foreach (string? path in paths)
        {
            if (path == null || !BackgroundStore.Supported(path)) { skipped++; continue; }
            try { using var bitmap = BackgroundLayer.OpenImage(path); }
            catch (Exception) { skipped++; continue; }
            pool.Images.Add(new BackgroundImage
            {
                SourcePath = path, Label = Path.GetFileName(path),
                FileName = Guid.NewGuid().ToString("N") + Path.GetExtension(path).ToLowerInvariant()
            });
        }
        if (pool.Images.Count > first) RefreshList(first);
        if (pool.Images.Count > first || skipped > 0)
            status.Text = skipped == 0 ? "" : $"已跳过 {skipped} 张无法读取的图片。";
    }

    private void Move(int step)
    {
        int from = list.SelectedIndex;
        int to = from + step;
        if (from < 0 || to < 0 || to >= pool.Images.Count) return;
        (pool.Images[from], pool.Images[to]) = (pool.Images[to], pool.Images[from]);
        RefreshList(to);
    }

    private void Remove()
    {
        int index = list.SelectedIndex;
        if (index < 0) return;
        pool.Images.RemoveAt(index);
        RefreshList(index);
    }

    private void Reset()
    {
        if (selected == null) return;
        selected.X = selected.Y = selected.Angle = 0;
        selected.Scale = 1;
        selected.Opacity = .35;
        selected.MirrorX = selected.MirrorY = false;
        LoadInputs();
    }

    private void Save()
    {
        if (picking) return;
        foreach (var input in new[] { x, y, scale, angle, opacity, seconds }) input.EndEdit();
        pool.AutoRotate = rotate.IsChecked == true;
        pool.IntervalSeconds = (int)seconds.Value;
        try { store.Save(pool); Close(true); }
        catch (Exception ex) { status.Text = "保存失败：" + ex.Message; }
    }
}
