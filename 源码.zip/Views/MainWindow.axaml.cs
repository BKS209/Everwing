using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Styling;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using Avalonia.Platform.Storage;
using DragonArchive;

namespace Everwing.Views;

public partial class MainWindow : Window
{
    private readonly ArchiveStore store = new ArchiveStore();
    private List<AiProfile> profiles = new List<AiProfile>();
    private AiProfile? current;
    private readonly Random rnd = new Random();
    private readonly List<ArchiveRecord> quotePool = new List<ArchiveRecord>();
    private readonly List<string> quoteRecent = new List<string>();
    private const int QuoteRecentMax = 6;
    private readonly DispatcherTimer quoteSchedule = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
    private readonly DispatcherTimer quoteAnimation = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(40) };
    private int quotePhase;
    private DateTime quotePhaseAt;
    private DateTime quoteNextAt;
    private string quoteLast = "";
    private int quoteStayMs = 7000;

    private readonly ComboBox roleBox;
    private readonly Ellipse accentDot;
    private readonly TextBlock roleName;
    private readonly TextBlock quoteText;
    private readonly TextBlock quoteMeta;
    private readonly TextBlock statusText;
    private readonly TextBlock cardTitle;
    private readonly Border mainCard;
    private bool syncingRoleSelection;
    private readonly ContentControl pageHost;
    private readonly Button[] navButtons = new Button[5];

    // 缓存完整页面容器：同一个页面不能被重复放进不同的 ScrollViewer。
    private readonly Control?[] pageContainers = new Control?[5];
    private int currentTab = 0;

    // 留言与交接各有自己的编辑状态，切换栏目不会串用正文、日期、标记和附件。
    private sealed class EditorState
    {
        public TextBox Body = null!;
        public TextBox? Year, Month, Day;
        public StackPanel MarkerChips = null!;
        public StackPanel PendingList = null!;
        public readonly List<Marker> Markers = new List<Marker>();
        public readonly List<string> PendingFiles = new List<string>();
    }

    private EditorState? messageEditor;
    private EditorState? handoverEditor;

    private ListBox recordList = null!;
    private StackPanel detailHost = null!;
    private List<ArchiveRecord> records = new List<ArchiveRecord>();

    private TextBlock guidePaths = null!;

    private TextBox histSearch = null!;
    private ComboBox histFilter = null!;
    private TextBlock histCount = null!;
    private readonly List<ArchiveRecord> filtered = new List<ArchiveRecord>();
    private StackPanel profileRows = null!;
    private ComboBox defaultBox = null!;
    private TextBox minBox = null!, maxBox = null!, stayBox = null!;
    private TextBox newName = null!, newKey = null!;
    private Border newAccentDot = null!, newSecondaryDot = null!;
    private string newSecondaryHex = "";
    private string newAccentHex = "#8B6FB4";
    private bool suppressDefaultSave;
    private int pickIndex = -1;
    private bool buildingHistory;

    public MainWindow()
    {
        InitializeComponent();
        roleBox = N<ComboBox>("RoleBox");
        accentDot = N<Ellipse>("AccentDot");
        roleName = N<TextBlock>("RoleName");
        quoteText = N<TextBlock>("QuoteText");
        quoteMeta = N<TextBlock>("QuoteMeta");
        statusText = N<TextBlock>("StatusText");
        cardTitle = N<TextBlock>("CardTitle");
        mainCard = N<Border>("MainCard");
        InitializeBackground();
        AnimateDropdown(roleBox, border =>
        {
            border.CornerRadius = new CornerRadius(18);
            border.Padding = new Thickness(6);
            border.ClipToBounds = true;
            border.BorderThickness = new Thickness(1);
            border.Background = brushCard;
            border.BorderBrush = brushLine;
        });
        pageHost = N<ContentControl>("PageHost");
        for (int i = 0; i < 5; i++) navButtons[i] = N<Button>("Nav" + i);

        Loaded += (s, e) => { Reload(); int tab = TabFromArgs(); pickIndex = PickFromArgs(); if (tab > 0) ShowPage(tab); StartRoleSequence(); };
        roleBox.SelectionChanged += (s, e) =>
        {
            if (!syncingRoleSelection && roleBox.SelectedIndex >= 0 && roleBox.SelectedIndex < profiles.Count)
                ApplyProfile(profiles[roleBox.SelectedIndex]);
        };
        for (int i = 0; i < 5; i++)
        {
            int idx = i;
            navButtons[i].Click += (s, e) => ShowPage(idx);
        }
        InitializeMessageWander();
        KeyDown += OnKeyDown;
        quoteSchedule.Tick += (s, e) => TryScheduleQuote();
        quoteAnimation.Tick += (s, e) => StepQuoteAnimation();
    }

    // 测试钩子：--roles Claude,DeepSeek,GPT —— 在同一个页面内依次切换角色，用来验收主题刷新。
    private void StartRoleSequence()
    {
        string seq = ArgValue("--roles");
        if (string.IsNullOrEmpty(seq)) return;
        string[] keys = seq.Split(',');
        int step = 0;
        DispatcherTimer t = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1400) };
        t.Tick += (s, e) =>
        {
            if (step >= keys.Length) { t.Stop(); return; }
            string k = keys[step++].Trim();
            AiProfile p = profiles.Find(x => x.Name == k || x.Key == k);
            if (p == null) return;
            int pi = profiles.IndexOf(p);
            if (pi >= 0 && roleBox.SelectedIndex != pi) roleBox.SelectedIndex = pi;   // 走真实下拉框路径
            else ApplyProfile(p);
        };
        t.Start();
    }

    private static string ArgValue(string name)
    {
        string[] a = Environment.GetCommandLineArgs();
        for (int i = 0; i + 1 < a.Length; i++) if (a[i] == name) return a[i + 1];
        return null;
    }

    private static int PickFromArgs()
    {
        string[] a = Environment.GetCommandLineArgs();
        for (int i = 0; i + 1 < a.Length; i++)
        {
            if (a[i].TrimStart('-') == "hist") { int n; if (int.TryParse(a[i + 1], out n)) return n; }
        }
        return -1;
    }

    private static bool HasArg(string name)
    {
        foreach (string s in Environment.GetCommandLineArgs()) if (s == name) return true;
        return false;
    }

    private static int TabFromArgs()
    {
        string[] a = Environment.GetCommandLineArgs();
        for (int i = 0; i + 1 < a.Length; i++)
            if (a[i] == "--tab" && int.TryParse(a[i + 1], out int v)) return v;
        return 0;
    }

    private T N<T>(string name) where T : class
    {
        INameScope? scope = NameScope.GetNameScope(this);
        if (scope == null) throw new InvalidOperationException("no name scope for " + name);
        return (T)scope.Find(name)!;
    }

    private static Color C(System.Drawing.Color c) => Color.FromArgb(c.A, c.R, c.G, c.B);
    private static IBrush Br(System.Drawing.Color c) => new SolidColorBrush(C(c));
    private static IBrush Br(Color c) => new SolidColorBrush(c);

    private void Reload()
    {
        try
        {
            ArchiveStore.EnsureBaseLayout();
            profiles = AiProfiles.Load();
            List<string> items = new List<string>();
            foreach (AiProfile p in profiles) items.Add(p.Name + " · " + p.Key);

            string def = "";
            try { def = AppSettings.Load().DefaultProfile ?? ""; } catch { }
            int idx = 0;
            for (int i = 0; i < profiles.Count; i++) if (profiles[i].Key == def) idx = i;
            syncingRoleSelection = true;
            try
            {
                roleBox.ItemsSource = items;
                roleBox.SelectedIndex = profiles.Count > 0 ? idx : -1;
            }
            finally { syncingRoleSelection = false; }
            if (profiles.Count > 0) ApplyProfile(profiles[idx]);
            ShowPage(currentTab);
        }
        catch (Exception ex)
        {
            statusText.Text = "读取档案失败：" + ex.Message;
        }
    }

    private void ApplyProfile(AiProfile p)
    {
        current = p;
        try
        {
            Color accent = C(p.AccentColor);
            Color ink = C(p.Ink);
            Color card = C(p.CardColor);
            roleName.Text = p.Name;
            accentDot.Fill = new SolidColorBrush(accent);
            roleName.Foreground = new SolidColorBrush(ink);
            cardTitle.Foreground = new SolidColorBrush(ink);
            brushInk = new SolidColorBrush(ink);
            brushMuted = new SolidColorBrush(C(p.Muted));
            brushAccent = new SolidColorBrush(accent);
            brushLine = new SolidColorBrush(C(p.Line));
            brushSoft = new SolidColorBrush(C(p.Soft));
            brushCard = new SolidColorBrush(card);
            Resources["ThemeInk"] = brushInk;
            Resources["ThemeMuted"] = brushMuted;
            Resources["ThemeAccent"] = brushAccent;
            if (Application.Current is { } app)
            {
                app.Resources["ArchiveScrollThumb"] = Br(ColorUtil.Mix(p.AccentColor, System.Drawing.Color.White, .20f));
                var dark = ColorUtil.Mix(p.AccentColor, System.Drawing.Color.FromArgb(48, 48, 48), .28f);
                app.Resources["ArchiveScrollThumbActive"] = Br(dark);
                app.Resources["ScrollBarThumbBackgroundColor"] = app.Resources["ArchiveScrollThumb"];
                app.Resources["ScrollBarThumbFillPointerOver"] = app.Resources["ArchiveScrollThumbActive"];
                app.Resources["ScrollBarThumbFillPressed"] = app.Resources["ArchiveScrollThumbActive"];
            }
            Resources["ThemeLine"] = brushLine;
            Resources["ThemeSoft"] = brushSoft;
            Resources["ThemeCard"] = brushCard;
            mainCard.Background = new SolidColorBrush(Color.FromArgb(235, card.R, card.G, card.B));
            var gradient = BackgroundGradient(p);
            if (!string.Equals(backgroundKey, p.Key, StringComparison.OrdinalIgnoreCase))
                LoadBackground(p.Key, gradient: gradient, animate: backgroundKey != null);
            else
                backgroundLayer.SetGradient(gradient);
            records = store.Load(p.Key);
            historyDirty = true;
            int msg = 0, ho = 0;
            foreach (ArchiveRecord r in records) { if (r.Type == "handover") ho++; else msg++; }
            statusText.Text = p.Name + " 的档案：" + msg + " 条留言 · " + ho + " 份交接 · 共 " + records.Count + " 条记录"
                + (AiProfiles.LoadProblem.Length > 0 ? "（角色表提示：" + AiProfiles.LoadProblem + "）" : "");
            // 画刷已全部换成新角色的实例，先刷新已登记控件，再统一处理文字颜色。
            RefreshBoundThemeControls();
            ApplyTextTheme(this);
            ShowQuote(p, records);
            RefreshCurrentPage();
        }
        catch (Exception ex)
        {
            statusText.Text = "切换档案失败：" + ex.Message;
        }
    }

    private void ShowQuote(AiProfile p, List<ArchiveRecord> recs)
    {
        RebuildQuotePool();
        if (quotePool.Count == 0)
        {
            quoteText.Text = "「这里还没有留言」";
            quoteMeta.Text = "";
            quoteText.Opacity = 1;
            quoteMeta.Opacity = 1;
            quoteSchedule.Stop();
            quoteAnimation.Stop();
            quotePhase = 0;
            return;
        }
        quoteSchedule.Stop();
        quoteAnimation.Stop();
        quotePhase = 0;
        quoteText.Opacity = 0;
        quoteMeta.Opacity = 0;
        StartQuote();
        quoteSchedule.Start();
    }

    private void RebuildQuotePool()
    {
        quotePool.Clear();
        foreach (AiProfile profile in profiles)
        {
            List<ArchiveRecord> list;
            try { list = store.Load(profile.Key); }
            catch { continue; }
            foreach (ArchiveRecord r in list)
            {
                if (r.Type != "message" || string.IsNullOrWhiteSpace(r.Text)) continue;
                if (r.Text.Trim().Length < 4) continue;
                if (string.IsNullOrWhiteSpace(r.ModelName)) r.ModelName = profile.Name;
                quotePool.Add(r);
            }
        }
    }

    private void TryScheduleQuote()
    {
        if (quotePhase == 0 && quotePool.Count > 0 && DateTime.Now >= quoteNextAt)
            StartQuote();
    }

    private void StartQuote()
    {
        if (quotePool.Count == 0) RebuildQuotePool();
        if (quotePool.Count == 0) return;

        string sentence = "";
        string meta = "";
        for (int attempt = 0; attempt < 24; attempt++)
        {
            ArchiveRecord candidate = quotePool[rnd.Next(quotePool.Count)];
            string picked = PickQuoteSentence(candidate.Text);
            if (string.IsNullOrWhiteSpace(picked) || picked == quoteLast || quoteRecent.Contains(picked)) continue;
            sentence = picked;
            meta = QuoteMetaText(candidate);
            break;
        }
        if (sentence.Length == 0)
        {
            ArchiveRecord candidate = quotePool[rnd.Next(quotePool.Count)];
            sentence = PickQuoteSentence(candidate.Text);
            meta = QuoteMetaText(candidate);
        }
        if (string.IsNullOrWhiteSpace(sentence))
        {
            quoteNextAt = DateTime.Now.AddSeconds(30);
            return;
        }

        AppSettings quoteSettings = AppSettings.Load();
        quoteStayMs = Math.Max(1000, quoteSettings.QuoteStayMs);
        quoteText.Text = "　　「" + sentence + "」";
        quoteMeta.Text = meta;
        quoteLast = sentence;
        quoteRecent.Add(sentence);
        while (quoteRecent.Count > QuoteRecentMax) quoteRecent.RemoveAt(0);
        quoteText.Opacity = 0;
        quoteMeta.Opacity = 0;
        quotePhase = 1;
        quotePhaseAt = DateTime.Now;
        quoteAnimation.Start();
    }

    private string PickQuoteSentence(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        string flat = text.Replace("\r\n", "\n").Replace('\r', '\n');
        char[] marks = new char[] { '\n', '。', '！', '？', '!', '?', ';', '；' };
        string[] parts = flat.Split(marks, StringSplitOptions.RemoveEmptyEntries);
        List<string> candidates = new List<string>();
        foreach (string part in parts)
        {
            string item = (part ?? "").Trim();
            if (item.Length < 6) continue;
            if (item.Length > 160) item = item.Substring(0, 160).TrimEnd() + "…";
            candidates.Add(item);
        }
        if (candidates.Count == 0)
        {
            string item = flat.Trim();
            if (item.Length > 160) item = item.Substring(0, 160).TrimEnd() + "…";
            return item;
        }
        return candidates[rnd.Next(candidates.Count)];
    }

    private string QuoteMetaText(ArchiveRecord r, string? profileName = null)
    {
        List<string> parts = new List<string>();
        string who = profileName ?? (string.IsNullOrWhiteSpace(r.ModelName) ? (current?.Name ?? "") : r.ModelName);
        if (who.Length > 0) parts.Add(who);
        if (!string.IsNullOrEmpty(r.Version) && r.Version != "未知") parts.Add("V" + r.Version);
        if (!string.IsNullOrEmpty(r.Generation) && r.Generation != "未知") parts.Add("第" + r.Generation + "任");
        string when = DisplayRecordDate(r);
        if (when.Length > 0) parts.Add(when);
        return string.Join(" · ", parts);
    }

    private void StepQuoteAnimation()
    {
        double ms = (DateTime.Now - quotePhaseAt).TotalMilliseconds;
        if (quotePhase == 1)
        {
            double opacity = Math.Min(1.0, ms / 800.0);
            quoteText.Opacity = opacity;
            quoteMeta.Opacity = opacity;
            if (ms >= 800) { quotePhase = 2; quotePhaseAt = DateTime.Now; quoteText.Opacity = 1; quoteMeta.Opacity = 1; }
        }
        else if (quotePhase == 2)
        {
            if (ms >= quoteStayMs)
            {
                quotePhase = 3;
                quotePhaseAt = DateTime.Now;
            }
        }
        else if (quotePhase == 3)
        {
            double opacity = Math.Max(0.0, 1.0 - ms / 1100.0);
            quoteText.Opacity = opacity;
            quoteMeta.Opacity = opacity;
            if (ms >= 1100)
            {
                quoteAnimation.Stop();
                quotePhase = 0;
                quoteText.Opacity = 0;
                quoteMeta.Opacity = 0;
                AppSettings st = AppSettings.Load();
                int min = Math.Max(1000, st.QuoteMinMs);
                int max = Math.Max(min, st.QuoteMaxMs);
                quoteNextAt = DateTime.Now.AddMilliseconds(rnd.Next(min, max + 1));
            }
        }
    }

    private static string DisplayRecordDate(ArchiveRecord r)
    {
        if (!string.IsNullOrWhiteSpace(r.Date) && r.Date != "未知")
        {
            string value = r.Date;
            if (!string.IsNullOrWhiteSpace(r.Time)) value += " " + r.Time;
            return value;
        }
        string saved = r.SavedAt ?? "";
        if (saved.Length >= 16) return saved.Substring(0, 16);
        return saved;
    }

    private bool switching;
    private bool historyDirty = true;

    private void ShowPage(int index)
    {
        if (index < 0 || index >= pageContainers.Length || switching) return;
        switching = true;
        try
        {
            // 只在第一次进入时构建页面。重访时复用同一个容器，
            // 避免把已经有父容器的控件再次塞入新 ScrollViewer 而崩溃。
            Control container;
            if (pageContainers[index] is Control cached)
            {
                container = cached;
            }
            else
            {
                Control page = BuildPage(index);
                container = index == 2 ? page : new ScrollViewer
                {
                    Content = page,
                    VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled
                };
                if (index == 4 && container is ScrollViewer settingsScroll)
                {
                    settingsScroll.AllowAutoHide = false;
                    page.Margin = new Thickness(0, 0, 8, 0);
                }
                pageContainers[index] = container;
            }

            currentTab = index;
            for (int i = 0; i < navButtons.Length; i++) navButtons[i].Classes.Set("on", i == index);
            string[] titles = { "珍藏的话", "交接文档", "回忆长廊", "说明", "档案设置" };
            cardTitle.Text = titles[index];
            if (!ReferenceEquals(pageHost.Content, container))
            {
                pageHost.Content = container;
                AnimatePage();
            }

            // 不再排队执行无条件的后台刷新。快速切换时旧回调会作用于新页面。
            RefreshCurrentPage();
        }
        catch (Exception ex)
        {
            statusText.Text = "切换栏目失败：" + ex.Message + "（详情见 ui-error.log）";
            try
            {
                Directory.CreateDirectory(ArchiveLayout.DataRoot);
                File.AppendAllText(System.IO.Path.Combine(ArchiveLayout.DataRoot, "ui-error.log"),
                    "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] ShowPage(" + index + ")\n" + ex + "\n\n");
            }
            catch { /* 日志不可写时，也不能让异常处理本身导致退出。 */ }
        }
        finally
        {
            switching = false;
        }
    }

    private void RefreshCurrentPage()
    {
        if (currentTab == 1) RefreshHandovers();
        if (currentTab == 2 && (historyDirty || pickIndex >= 0)) RefreshHistory();
        if (currentTab == 3) RefreshGuide();
        if (currentTab == 4) RefreshSettings();
    }

    private Control BuildPage(int index)
    {
        if (index == 0) return BuildEditor(false);
        if (index == 1) return BuildHandover();
        if (index == 2) return BuildHistory();
        if (index == 3) return BuildGuide();
        return BuildSettings();
    }

    private Button MakeButton(string text, string cls, EventHandler<RoutedEventArgs> onClick)
    {
        Button b = new Button { Content = text, Classes = { "nav" } };
        if (cls.Contains("on")) b.Classes.Add("on");
        if (cls.Contains("ghost")) b.Classes.Add("ghost");
        b.Click += onClick;
        return b;
    }

    private Border WrapField(Control inner)
    {
        Border frame = new Border
        {
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1.5),
            BorderBrush = brushLine,
            Background = brushCard,
            Child = inner
        };
        BindTheme(frame, line: true, card: true);
        return frame;
    }

    private Button ChipBtn(string text, Action onClick)
    {
        Button b = new Button { Content = text, Classes = { "chip" }, FontSize = 12 };
        b.Click += (s, e) => onClick();
        return b;
    }

    private static string Shorten(string s, int n)
    {
        s = (s ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
        return s.Length > n ? s.Substring(0, n) + "…" : s;
    }

    // ---------------- 留言 / 交接 ----------------
    private Control BuildEditor(bool handover)
    {
        EditorState editor = new EditorState();
        if (handover) handoverEditor = editor;
        else messageEditor = editor;

        StackPanel root = new StackPanel { Spacing = 10, Classes = { "archive-editor" } };
        Grid top = new Grid { ColumnDefinitions = new ColumnDefinitions("*,Auto") };

        StackPanel markCol = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        markCol.Children.Add(new TextBlock { Text = "标记（可选）", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        markCol.Children.Add(ChipBtn("V几", () => EditMarker(editor, "V")));
        markCol.Children.Add(ChipBtn("第几任", () => EditMarker(editor, "G")));
        markCol.Children.Add(ChipBtn("自定义", () => EditMarker(editor, "C")));
        editor.MarkerChips = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6, VerticalAlignment = VerticalAlignment.Center };
        markCol.Children.Add(editor.MarkerChips);
        Grid.SetColumn(markCol, 0);
        top.Children.Add(markCol);

        // 年、月、日都是空白输入框，不显示 yyyy/MM/dd，也不再显示时分和左侧长标签。
        StackPanel dateCol = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 4, VerticalAlignment = VerticalAlignment.Center };
        editor.Year = DateBox(4);
        editor.Month = DateBox(2);
        editor.Day = DateBox(2);
        dateCol.Children.Add(editor.Year);
        dateCol.Children.Add(new TextBlock { Text = "年", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        dateCol.Children.Add(editor.Month);
        dateCol.Children.Add(new TextBlock { Text = "月", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        dateCol.Children.Add(editor.Day);
        dateCol.Children.Add(new TextBlock { Text = "日", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        dateCol.Margin = new Thickness(0, 0, 4, 0);
        ToolTip.SetTip(dateCol, "日期可选；全部留空时使用保存当天的日期");
        Grid.SetColumn(dateCol, 1);
        top.Children.Add(dateCol);
        root.Children.Add(top);

        StackPanel attRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        attRow.Children.Add(new TextBlock { Text = "附件（可选，选好再保存）", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        attRow.Children.Add(ChipBtn("＋ 添加附件…", () => { _ = PickAttachments(editor); }));
        attRow.Children.Add(ChipBtn("清空", () => { editor.PendingFiles.Clear(); RefreshPending(editor); }));
        root.Children.Add(attRow);

        editor.PendingList = new StackPanel { Spacing = 2 };
        root.Children.Add(editor.PendingList);

        root.Children.Add(new TextBlock { Text = "正文（Ctrl+Enter 可直接保存）", Classes = { "muted" } });
        TextBox body = new TextBox
        {
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            Watermark = handover ? "写给下一任的交接内容……" : "在这里写下想留下的话……",
            Height = handover ? 175 : 195,
            FontSize = 14,
            Padding = new Thickness(14, 12),
            Background = Brushes.Transparent,
            BorderThickness = new Thickness(0)
        };
        ScrollViewer.SetVerticalScrollBarVisibility(body, Avalonia.Controls.Primitives.ScrollBarVisibility.Auto);

        editor.Body = body;
        root.Children.Add(WrapField(body));

        StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        if (handover)
            btnRow.Children.Add(MakeButton("保存为新的 TXT", "nav on", (s, e) => SaveFromEditor(editor, true)));
        else
            btnRow.Children.Add(MakeButton("追加保存到当月 TXT", "nav on", (s, e) => SaveFromEditor(editor, false)));
        btnRow.Children.Add(MakeButton("导入 TXT", "nav ghost", (s, e) => { _ = ImportTxt(editor); }));
        root.Children.Add(btnRow);
        RefreshPending(editor);
        return root;
    }

    private static TextBox DateBox(int digits)
    {
        return new TextBox
        {
            Width = digits == 4 ? 64 : 44,
            MaxLength = digits,
            FontSize = 13,
            Padding = new Thickness(6, 5),
            TextAlignment = TextAlignment.Center,
            HorizontalContentAlignment = HorizontalAlignment.Center
        };
    }

    /// <summary>全空表示自动使用今天；输入无效则返回 null，避免悄悄保存成错误日期。</summary>
    private static string? ReadDateInputs(EditorState editor)
    {
        string y = (editor.Year?.Text ?? "").Trim();
        string mo = (editor.Month?.Text ?? "").Trim();
        string d = (editor.Day?.Text ?? "").Trim();
        if (y.Length == 0 && mo.Length == 0 && d.Length == 0) return "";
        if (y.Length != 4 || !int.TryParse(y, out int iy) || iy < 1970 || iy > 2999
            || !int.TryParse(mo, out int im) || im < 1 || im > 12
            || !int.TryParse(d, out int idd) || idd < 1 || idd > DateTime.DaysInMonth(iy, im))
            return null;
        return iy.ToString("0000") + "-" + im.ToString("00") + "-" + idd.ToString("00");
    }

    private static void ClearDateInputs(EditorState editor)
    {
        if (editor.Year != null) editor.Year.Text = "";
        if (editor.Month != null) editor.Month.Text = "";
        if (editor.Day != null) editor.Day.Text = "";
    }

    private void EditMarker(EditorState editor, string key)
    {
        if (current == null) return;
        string title = key == "V" ? "版本号" : key == "G" ? "第几任" : "自定义标记";
        Marker? exist = null;
        foreach (Marker m in editor.Markers) if (m.Key == key) { exist = m; break; }
        MarkerEditor dlg = new MarkerEditor(title, key == "C", exist?.Label ?? "", exist?.Value ?? "", current, store.IsValidVersion);
        dlg.ShowDialog<bool>(this).ContinueWith(t =>
        {
            if (!t.IsCompletedSuccessfully || !t.Result) return;
            if (exist != null) editor.Markers.Remove(exist);
            if (dlg.ResultLabel == "" && dlg.ResultValue == "") { RefreshMarkerChips(editor); return; }
            editor.Markers.Add(new Marker { Key = key, Label = key == "C" ? dlg.ResultLabel : key, Value = dlg.ResultValue });
            RefreshMarkerChips(editor);
        }, TaskScheduler.FromCurrentSynchronizationContext());
    }

    private void RefreshMarkerChips(EditorState editor)
    {
        editor.MarkerChips.Children.Clear();
        foreach (Marker m in editor.Markers)
        {
            Marker mm = m;
            string text = (m.IsVersion ? "V" + m.Value : m.IsGeneration ? "第" + m.Value + "任" : m.Display) + "  ×";
            editor.MarkerChips.Children.Add(ChipBtn(text, () => { editor.Markers.Remove(mm); RefreshMarkerChips(editor); }));
        }
    }

    private async Task PickAttachments(EditorState editor)
    {
        if (StorageProvider == null) return;
        IReadOnlyList<IStorageFile> files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "选择附件（可多选）",
            AllowMultiple = true
        });
        foreach (IStorageFile f in files)
        {
            string? p = f.TryGetLocalPath();
            if (p != null) editor.PendingFiles.Add(p);
        }
        RefreshPending(editor);
    }

    private static void RefreshPending(EditorState editor)
    {
        editor.PendingList.Children.Clear();
        if (editor.PendingFiles.Count == 0)
        {
            editor.PendingList.Children.Add(new TextBlock { Text = "还没有附件", Classes = { "muted" } });
            return;
        }
        foreach (string f in editor.PendingFiles)
            editor.PendingList.Children.Add(new TextBlock { Text = "◈ " + System.IO.Path.GetFileName(f), Classes = { "h2" } });
    }

    private async Task ImportTxt(EditorState editor)
    {
        if (StorageProvider == null) return;
        IReadOnlyList<IStorageFile> files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = "导入 TXT" });
        if (files.Count == 0) return;
        string? p = files[0].TryGetLocalPath();
        if (p == null) return;
        try
        {
            editor.Body.Text = File.ReadAllText(p, Encoding.UTF8);
            statusText.Text = "已导入：" + System.IO.Path.GetFileName(p);
        }
        catch (Exception ex) { statusText.Text = "导入失败：" + ex.Message; }
    }

    private void SaveFromEditor(EditorState editor, bool handover)
    {
        if (current == null) { statusText.Text = "还没有选中档案。"; return; }
        string text = (editor.Body.Text ?? "").Trim();
        if (text.Length == 0) { statusText.Text = handover ? "交接内容是空的。" : "正文是空的，先写点什么吧。"; return; }
        string? date = ReadDateInputs(editor);
        if (date == null)
        {
            statusText.Text = "日期无效：请完整填写正确的年、月、日，或将三个输入框全部留空。";
            return;
        }
        if (date.Length == 0) date = DateTime.Now.ToString("yyyy-MM-dd");
        try
        {
            string ver = "", gen = "";
            foreach (Marker m in editor.Markers)
            {
                if (m.IsVersion) ver = m.Value;
                if (m.IsGeneration) gen = m.Value;
            }
            SaveResult r = store.Save(current.Key, handover ? "handover" : "message", ver, gen, date, text);
            AttachmentStore atts = store.Attachments(current.Key);
            foreach (string f in editor.PendingFiles)
            {
                Attachment a = atts.Add(r.Id, f, "");
                store.LinkAttachment(current.Key, r.Id, a.RelPath);
            }
            int n = editor.PendingFiles.Count;
            editor.PendingFiles.Clear();
            RefreshPending(editor);
            editor.Markers.Clear();
            RefreshMarkerChips(editor);
            ClearDateInputs(editor);
            editor.Body.Text = "";
            statusText.Text = (handover ? "已保存交接：" : "已保存：") + System.IO.Path.GetFileName(r.File) + "（" + current.Name + "）" + (n > 0 ? "，附件 " + n + " 个" : "");
            ApplyProfile(current);
        }
        catch (Exception ex)
        {
            statusText.Text = "保存失败：" + ex.Message;
        }
    }

    private Control BuildHandover()
    {
        return BuildEditor(true);
    }

    private void RefreshHandovers()
    {
        // 交接页不再重复列历史交接，统一到「回忆长廊」查看。
    }

    // ---------------- 回忆长廊 ----------------
    private IBrush brushInk = Brushes.Black;
    private IBrush brushMuted = Brushes.Gray;
    private IBrush brushAccent = Brushes.Purple;
    private IBrush brushLine = Brushes.Gainsboro;
    private IBrush brushSoft = Brushes.WhiteSmoke;
    private IBrush brushCard = Brushes.White;

    // v2.0.15：主题控件登记表。代码创建的控件在创建时把 brushLine/brushCard 等实例写进了属性，
    // 换角色后这些实例不会自动变，所以登记下来，ApplyProfile 重建画刷后统一刷新。
    private readonly List<WeakReference<Control>> themeBoundControls = new List<WeakReference<Control>>();

    private void BindTheme(Control control, bool line = false, bool card = false, bool soft = false,
                           bool ink = false, bool muted = false, bool accent = false)
    {
        if (control == null) return;
        if (line) control.Classes.Add("theme-line-bound");
        if (card) control.Classes.Add("theme-card-bound");
        if (soft) control.Classes.Add("theme-soft-bound");
        if (ink) control.Classes.Add("theme-ink-bound");
        if (muted) control.Classes.Add("theme-muted-bound");
        if (accent) control.Classes.Add("theme-accent-bound");
        if (control.Classes.Contains("theme-bound")) return;   // 去重：同一控件只登记一次
        control.Classes.Add("theme-bound");
        themeBoundControls.Add(new WeakReference<Control>(control));
    }

    private void RefreshBoundThemeControls()
    {
        for (int i = themeBoundControls.Count - 1; i >= 0; i--)
        {
            Control? control;
            if (!themeBoundControls[i].TryGetTarget(out control) || control == null)
            {
                themeBoundControls.RemoveAt(i);
                continue;
            }

            bool line = control.Classes.Contains("theme-line-bound");
            bool card = control.Classes.Contains("theme-card-bound");
            bool soft = control.Classes.Contains("theme-soft-bound");
            bool ink = control.Classes.Contains("theme-ink-bound");
            bool muted = control.Classes.Contains("theme-muted-bound");
            bool accent = control.Classes.Contains("theme-accent-bound");

            if (control is Border border)
            {
                if (line) border.BorderBrush = brushLine;
                if (card) border.Background = brushCard;
                if (soft) border.Background = brushSoft;
            }
            else if (control is Avalonia.Controls.Shapes.Shape shape)
            {
                if (accent) shape.Stroke = brushAccent;
                if (ink) shape.Stroke = brushInk;
            }
            else if (control is TemplatedControl templated)
            {
                if (line) templated.BorderBrush = brushLine;
                if (card) templated.Background = brushCard;
                if (soft) templated.Background = brushSoft;
                if (ink) templated.Foreground = brushInk;
                if (muted) templated.Foreground = brushMuted;
                if (accent) templated.Foreground = brushAccent;
            }
        }
    }

    private Border? attachListBox;

    // 每次换记录或刷新列表时移除旧附件浮层，避免隐形控件不断累积。
    private void RemoveAttachmentPopup()
    {
        attachListBox = null;
    }

    private static IBrush ToBrush(System.Drawing.Color c, byte alpha = 255)
    {
        return new SolidColorBrush(Color.FromArgb(alpha, c.R, c.G, c.B));
    }

    private void ApplyTextTheme(Control root)
    {
        if (root.Classes.Contains("archive-editor")) return;
        if (root is TextBlock tb)
        {
            bool muted = tb.Classes.Contains("muted") || tb.Classes.Contains("foot");
            tb.Foreground = muted ? brushMuted : brushInk;
            return;
        }
        if (root is TextBox tbx) { tbx.Foreground = brushInk; return; }
        if (root is ComboBox cb) { cb.Foreground = brushInk; return; }
        if (root is Panel pan) { foreach (Control c in pan.Children) ApplyTextTheme(c); return; }
        if (root is Border bd && bd.Child is Control bdChild) { ApplyTextTheme(bdChild); return; }
        if (root is ContentControl cc && cc.Content is Control child) { ApplyTextTheme(child); }
    }

    private Button MakeIconButton(string data, string tip, IBrush stroke, IBrush border, bool danger)
    {
        Avalonia.Controls.Shapes.Path path = new Avalonia.Controls.Shapes.Path
        {
            Data = Geometry.Parse(data),
            Stroke = stroke,
            StrokeThickness = 1.5,
            StrokeLineCap = PenLineCap.Round,
            StrokeJoin = PenLineJoin.Round,
            Width = 15,
            Height = 15,
            Stretch = Stretch.Uniform,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
        Button btn = new Button
        {
            Width = 34,
            Height = 32,
            CornerRadius = new CornerRadius(10),
            Background = brushCard,
            BorderBrush = border,
            BorderThickness = new Thickness(1),
            Padding = new Thickness(0),
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            Content = path
        };
        ToolTip.SetTip(btn, tip);
        // 图标颜色按「角色」登记（accent 或 ink），换角色时由 RefreshBoundThemeControls 一并刷新；
        // 悬停事件里读当前字段，不再捕获创建当时的旧 IBrush。
        BindTheme(path, ink: !danger, accent: danger);
        BindTheme(btn, line: true, card: true);
        if (danger)
        {
            btn.PointerEntered += (s, e) => { path.Stroke = brushAccent; btn.BorderBrush = brushAccent; };
            btn.PointerExited += (s, e) => { path.Stroke = brushAccent; btn.BorderBrush = brushLine; };
        }
        else
        {
            btn.PointerEntered += (s, e) => { path.Stroke = brushAccent; btn.BorderBrush = brushLine; };
            btn.PointerExited += (s, e) => { path.Stroke = brushInk; btn.BorderBrush = brushLine; };
        }
        return btn;
    }

    private Control BuildHistory()
    {
        buildingHistory = true;
        Grid root = new Grid { RowDefinitions = new RowDefinitions("Auto,*") };

        // 工具栏与下方双栏同构：搜索框只占左栏宽度
        Grid bar = new Grid { ColumnDefinitions = new ColumnDefinitions("*,14,1.15*"), Margin = new Thickness(0, 0, 0, 10) };
        histSearch = new TextBox
        {
            Watermark = "输入关键词……",
            Height = 36,
            CornerRadius = new CornerRadius(10),
            BorderThickness = new Thickness(1),
            BorderBrush = brushLine,
            Foreground = brushInk,
            Background = brushCard,
            VerticalContentAlignment = VerticalAlignment.Center,
            Padding = new Thickness(12, 0),
            FontSize = 12
        };
        histSearch.TextChanged += (s, e) => RefreshHistory();
        Grid.SetColumn(histSearch, 0);
        bar.Children.Add(histSearch);

        // 筛选器：与搜索框同一行，位于右栏左侧
        histFilter = new ComboBox
        {
            Width = 120,
            Height = 36,
            CornerRadius = new CornerRadius(10),
            BorderThickness = new Thickness(1),
            BorderBrush = brushLine,
            Foreground = brushInk,
            Background = brushCard,
            FontSize = 12,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Center
        };
        histFilter.Items.Add("全部");
        histFilter.Items.Add("留言");
        histFilter.Items.Add("交接");
        AnimateDropdown(histFilter);
        histFilter.SelectionChanged += (s, e) => RefreshHistory();
        histFilter.SelectedIndex = 0;
        // 右栏：左边筛选器、右边工具组，与右侧详情卡同列
        Grid rightBar = new Grid { ColumnDefinitions = new ColumnDefinitions("Auto,*"), VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(histFilter, 0);
        rightBar.Children.Add(histFilter);
        Grid.SetColumn(rightBar, 2);
        bar.Children.Add(rightBar);
        BindTheme(histSearch, line: true, card: true, ink: true);
        BindTheme(histFilter, line: true, card: true, ink: true);

        StackPanel rightTools = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            Spacing = 10,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };

        Button reload = MakeButton("重新读取硬盘", "nav ghost", (s, e) => { Reload(); RefreshHistory(); statusText.Text = "已重新读取：" + records.Count + " 条记录"; });
        reload.Height = 36;
        reload.MinWidth = 116;
        reload.Padding = new Thickness(14, 0, 14, 0);
        reload.HorizontalContentAlignment = HorizontalAlignment.Center;
        reload.VerticalContentAlignment = VerticalAlignment.Center;
        reload.Content = new TextBlock { Text = "重新读取硬盘", TextAlignment = TextAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        rightTools.Children.Add(reload);

        histCount = new TextBlock { Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center, TextAlignment = TextAlignment.Right, Text = "" };
        rightTools.Children.Add(histCount);

        Grid.SetColumn(rightTools, 1);
        rightBar.Children.Add(rightTools);
        root.Children.Add(bar);

        Grid body = new Grid { ColumnDefinitions = new ColumnDefinitions("*,14,1.15*") };
        Grid.SetRow(body, 1);

        Border leftCard = new Border
        {
            CornerRadius = new CornerRadius(14),
            BorderBrush = brushLine,
            BorderThickness = new Thickness(1),
            Background = brushCard,
            Padding = new Thickness(0)
        };
        recordList = new ListBox
        {
            Background = Brushes.Transparent,
            BorderThickness = new Thickness(0),
            Padding = new Thickness(10, 10, 16, 10)
        };
        recordList.Classes.Add("records");
        recordList.Styles.Add(new Style(x => x.OfType<ListBoxItem>())
        {
            Setters =
            {
                new Setter(TemplatedControl.PaddingProperty, new Thickness(0)),
                new Setter(TemplatedControl.MarginProperty, new Thickness(0, 0, 0, 8)),
                new Setter(ContentControl.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                new Setter(TemplatedControl.BackgroundProperty, Brushes.Transparent)
            }
        });
        recordList.SelectionChanged += (s, e) =>
        {
            int i = recordList.SelectedIndex;
            if (i >= 0 && i < filtered.Count) ShowRecordDetail(filtered[i]);
        };
        ScrollViewer.SetHorizontalScrollBarVisibility(recordList, Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled);
        recordList.Margin = new Thickness(0, 0, 4, 0);
        leftCard.Child = recordList;
        Grid.SetColumn(leftCard, 0);
        BindTheme(leftCard, line: true, card: true);
        BindTheme(leftCard, line: true, card: true);
        body.Children.Add(leftCard);

        detailCard = new Border
        {
            CornerRadius = new CornerRadius(14),
            BorderBrush = brushLine,
            BorderThickness = new Thickness(1),
            Background = brushCard,
            Padding = new Thickness(14, 12, 14, 12)
        };
        BindTheme(detailCard, line: true, card: true);
        BindTheme(detailCard, line: true, card: true);
        detailRoot = new Grid { RowDefinitions = new RowDefinitions("Auto,*,Auto,Auto") };

        detailHeader = new StackPanel { Spacing = 2 };
        Grid.SetRow(detailHeader, 0);
        detailRoot.Children.Add(detailHeader);
        detailText = new TextBox
        {
            IsReadOnly = true,
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            FontSize = 13,
            Foreground = brushInk,
            Background = Brushes.Transparent,
            BorderThickness = new Thickness(0),
            BorderBrush = Brushes.Transparent,
            Padding = new Thickness(2, 8),
            VerticalContentAlignment = VerticalAlignment.Top,
            Classes = { "detail-readonly" }
        };
        ScrollViewer textScroll = new ScrollViewer { Content = detailText, VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto };
        Grid.SetRow(textScroll, 1);
        detailRoot.Children.Add(textScroll);

        detailAttachBar = new StackPanel { Orientation = Orientation.Vertical, Spacing = 4, Margin = new Thickness(0, 8, 0, 0) };
        Grid.SetRow(detailAttachBar, 2);
        detailRoot.Children.Add(detailAttachBar);

        detailFoot = new DockPanel { LastChildFill = false, Margin = new Thickness(0, 8, 0, 0) };
        Grid.SetRow(detailFoot, 3);
        detailRoot.Children.Add(detailFoot);

        detailCard.Child = detailRoot;
        Grid.SetColumn(detailCard, 2);
        body.Children.Add(detailCard);

        root.Children.Add(body);
        buildingHistory = false;
        if (histFilter != null && histFilter.SelectedIndex < 0) histFilter.SelectedIndex = 0;
        return root;
    }

    private Border? detailCard;
    private Grid? detailRoot;
    private StackPanel? detailHeader;
    private TextBox? detailText;
    private DockPanel? detailFoot;
    private StackPanel? detailAttachBar;
    private bool attachmentsOpened = true;
    private bool openAttachPopup = false;

    // ------- 记录操作（回忆长廊右栏底部） -------
    private async void EditRecord(ArchiveRecord r)
    {
        if (current == null) return;
        var dialog = new TextEditDialog(r, current, store);
        if (!await dialog.ShowDialog<bool>(this)) return;
        records = store.Load(r.ModelKey);
        RefreshHistory(r.Id);
        statusText.Text = "已更新这条记录。";
    }

    private async Task AddAttachmentToRecord(ArchiveRecord r)
    {
        if (current == null) return;
        IReadOnlyList<IStorageFile> files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "给这条记录加附件",
            AllowMultiple = true
        });
        int n = 0;
        AttachmentStore atts = store.Attachments(current.Key);
        foreach (IStorageFile f in files)
        {
            string? p = f.TryGetLocalPath();
            if (p == null) continue;
            Attachment a = atts.Add(r.Id, p, "");
            store.LinkAttachment(current.Key, r.Id, a.RelPath);
            n++;
        }
        if (n == 0) return;
        Reload();
        RefreshHistory();
        foreach (ArchiveRecord rr in filtered) if (rr.Id == r.Id) { ShowRecordDetail(rr); break; }
        statusText.Text = "已添加 " + n + " 个附件。";
    }

    private async Task DeleteRecordFlow(ArchiveRecord r)
    {
        if (current == null) return;
        var profile = current;
        IBrush surface = Br(ColorUtil.Mix(profile.AccentColor, System.Drawing.Color.White, .94f));
        IBrush line = Br(ColorUtil.Mix(profile.AccentColor, System.Drawing.Color.White, .60f));
        Task<bool> ConfirmStep(string text, string button, string? required = null) =>
            new ConfirmWindow("删除记录", text, button, Br(profile.AccentColor), surface, Br(profile.Ink), line, required)
                .ShowDialog<bool>(this);

        bool ok1 = await ConfirmStep("要删掉这一条吗？\n\n" + (r.Type == "handover" ? "交接文档" : "留言") + " · " + r.Date + "\n\n删掉后无法在软件里撤回（文件会留一份 .bak）。", "继续");
        if (!ok1) return;
        bool ok2 = await ConfirmStep("再确认一次：磁盘上的这条记录会被移除。\n\n" + (r.Text ?? "").Substring(0, Math.Min(60, (r.Text ?? "").Length)) + "……", "继续");
        if (!ok2) return;
        if (!await ConfirmStep("请输入 delete 确认删除这条记录。", "删除记录", "delete")) return;
        try
        {
            store.DeleteRecord(r);
            Reload();
            RefreshHistory();
            statusText.Text = "已删除这条记录。";
        }
        catch (Exception ex) { statusText.Text = "删除失败：" + ex.Message; }
    }

    private void ShowRecordDetail(ArchiveRecord r)
    {
        try { System.IO.File.AppendAllText(System.IO.Path.Combine(ArchiveLayout.DataRoot, "ui-trace.log"), "detail " + r.Id + " header=" + (detailHeader != null) + " text=" + (detailText != null) + " cur=" + (current != null) + Environment.NewLine); } catch { }
        if (detailRoot == null || detailHeader == null || detailText == null || detailFoot == null || detailAttachBar == null || current == null) return;
        detailHeader.Children.Clear();
        detailFoot.Children.Clear();
        detailAttachBar.Children.Clear();
        RemoveAttachmentPopup();

        string ver = string.IsNullOrEmpty(r.Version) || r.Version == "未知" ? "" : " · V" + r.Version;
        string gen = string.IsNullOrEmpty(r.Generation) || r.Generation == "未知" ? "" : " · 第" + r.Generation + "任";
        detailHeader.Children.Add(new TextBlock
        {
            Text = (r.Type == "handover" ? "◇ 交接文档" : "✦ 留言") + " · " + DisplayRecordDate(r) + ver + gen,
            Classes = { "h2" },
            Foreground = brushInk
        });
        string tagText = string.Join(" · ", r.Markers.Where(m => !m.IsVersion && !m.IsGeneration).Select(m => m.Display));
        if (tagText.Length > 0)
        {
            var tags = new TextBlock { Text = tagText, Foreground = brushMuted, FontSize = 12,
                TextTrimming = TextTrimming.CharacterEllipsis };
            ToolTip.SetTip(tags, tagText);
            detailHeader.Children.Add(tags);
        }
        detailText.Text = r.Text;
        detailText.CaretIndex = 0;
        if (detailText.Parent is ScrollViewer sv) sv.Offset = new Vector(0, 0);

        AttachmentStore atts = store.Attachments(current.Key);

        // 标题固定在列表上方；0 个附件时只有静态文字，不能展开。
        Border attachList = new Border
        {
            Background = brushCard,
            BorderBrush = brushLine,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(8, 6),
            MaxHeight = 160,
            IsVisible = false,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Child = new ScrollViewer { VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto }
        };
        attachListBox = attachList;
        BindTheme(attachList, line: true, card: true);
        BindTheme(attachList, line: true, card: true);

        if (r.Attachments.Count > 0)
        {
            Button toggle = new Button
            {
                Content = "附件",
                Background = Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0, 4),
                FontSize = 12,
                Foreground = brushMuted,
                HorizontalAlignment = HorizontalAlignment.Left
            };
            ToolTip.SetTip(toggle, "展开 / 收起附件列表");
            detailAttachBar.Children.Add(toggle);

            StackPanel list = new StackPanel { Spacing = 4 };
            int idx = 0;
            foreach (Attachment a in r.Attachments)
            {
                Attachment aa = a;
                idx++;
                Grid row = new Grid { ColumnDefinitions = new ColumnDefinitions("*,Auto,Auto,Auto"), Height = 32 };
                row.Children.Add(new TextBlock
                {
                    Text = "附件" + idx + " · " + a.Name,
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = brushInk,
                    FontSize = 12,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    Margin = new Thickness(0, 0, 8, 0)
                });
                Button openBtn = new Button { Content = "打开", Classes = { "row" }, Margin = new Thickness(4, 0, 0, 0) };
                openBtn.Click += (s, e) => OpenAttachment(atts, aa);
                Button locateBtn = new Button { Content = "定位", Classes = { "row" }, Margin = new Thickness(4, 0, 0, 0) };
                locateBtn.Click += (s, e) => LocateAttachment(atts, aa);
                Button removeBtn = new Button { Content = "移除", Classes = { "row" }, Margin = new Thickness(4, 0, 0, 0) };
                removeBtn.Click += (s, e) => { _ = RemoveAttachment(atts, aa); };
                Grid.SetColumn(openBtn, 1);
                Grid.SetColumn(locateBtn, 2);
                Grid.SetColumn(removeBtn, 3);
                row.Children.Add(openBtn);
                row.Children.Add(locateBtn);
                row.Children.Add(removeBtn);
                list.Children.Add(row);
            }

            ((ScrollViewer)attachList.Child!).Content = list;
            detailAttachBar.Children.Add(attachList);

            toggle.Click += (s, e) => { attachList.IsVisible = !attachList.IsVisible; };
        }
        else
        {
            detailAttachBar.Children.Add(new TextBlock
            {
                Text = "附件",
                FontSize = 12,
                Foreground = brushMuted,
                VerticalAlignment = VerticalAlignment.Center
            });
        }

        Button edit = new Button
        {
            Content = "编辑",
            Height = 32,
            CornerRadius = new CornerRadius(10),
            Background = brushCard,
            BorderBrush = brushLine,
            BorderThickness = new Thickness(1),
            Width = 72,
            Padding = new Thickness(0),
            HorizontalContentAlignment = HorizontalAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center,
            FontSize = 12,
            Foreground = brushInk
        };
        BindTheme(edit, line: true, card: true, ink: true);
        BindTheme(edit, line: true, card: true, ink: true);
        edit.Click += (s, e) => EditRecord(r);
        detailFoot.Children.Add(edit);

        string clipData = "M 11.5 4.5 L 5.5 10.5 A 2.5 2.5 0 0 0 9 14 L 15 8 A 4 4 0 0 0 9.3 2.3 L 3.3 8.3 A 5.5 5.5 0 0 0 11 16 L 16 11";
        Button clip = MakeIconButton(clipData, "添加附件", brushInk, brushLine, false);
        clip.Margin = new Thickness(8, 0, 0, 0);
        BindTheme(clip, line: true, card: true);
        BindTheme(clip, line: true, card: true);
        clip.Click += (s, e) => { _ = AddAttachmentToRecord(r); };
        detailFoot.Children.Add(clip);

        string trashData = "M 3 5 H 15 M 6 5 V 3 H 12 V 5 M 5 5 L 6 15 H 12 L 13 5 M 7.5 8 V 12.5 M 10.5 8 V 12.5";
        Button trash = MakeIconButton(trashData, "删除这条记录", brushAccent, brushLine, true);
        Avalonia.Automation.AutomationProperties.SetName(trash, "删除这条记录");
        trash.Click += (s, e) => { _ = DeleteRecordFlow(r); };
        DockPanel.SetDock(trash, Dock.Right);
        BindTheme(trash, line: true, card: true);
        BindTheme(trash, line: true, card: true);
        detailFoot.Children.Add(trash);
    }

    private void RefreshHistory(string? editedId = null)
    {
        if (buildingHistory) return;
        if (recordList == null) return;
        RemoveAttachmentPopup();
        filtered.Clear();
        string kw = histSearch == null ? "" : (histSearch.Text ?? "").Trim();
        int type = histFilter == null ? 0 : histFilter.SelectedIndex;
        foreach (ArchiveRecord r in records)
        {
            if (type == 1 && r.Type != "message") continue;
            if (type == 2 && r.Type != "handover") continue;
            if (kw.Length > 0 && (r.Text ?? "").IndexOf(kw, StringComparison.OrdinalIgnoreCase) < 0) continue;
            filtered.Add(r);
        }
        int keepSel = editedId != null ? filtered.FindIndex(r => r.Id == editedId)
            : pickIndex >= 0 ? -1 : recordList.SelectedIndex;
        recordList.Items.Clear();
        foreach (ArchiveRecord r in filtered) recordList.Items.Add(BuildRecordCard(r));
        historyDirty = false;
        if (histCount != null) histCount.Text = "共 " + filtered.Count + " 条记录";
        try { System.IO.File.AppendAllText(System.IO.Path.Combine(ArchiveLayout.DataRoot, "ui-trace.log"), "refresh pick=" + pickIndex + " filtered=" + filtered.Count + Environment.NewLine); } catch { }
        if (pickIndex >= 0 && pickIndex < filtered.Count) { int pi = pickIndex; pickIndex = -1; recordList.SelectedIndex = pi; ShowRecordDetail(filtered[pi]); if (HasArg("--attachopen") && attachListBox != null) attachListBox.IsVisible = true; return; }
        if (keepSel >= 0 && keepSel < filtered.Count) { recordList.SelectedIndex = keepSel; ShowRecordDetail(filtered[keepSel]); return; }
        if (detailHeader != null)
        {
            detailHeader.Children.Clear();
            detailHeader.Children.Add(new TextBlock { Text = "点选左侧记录查看全文", Classes = { "muted" } });
        }
        if (detailText != null) detailText.Text = "";
        if (detailAttachBar != null) detailAttachBar.Children.Clear();
        if (detailFoot != null) detailFoot.Children.Clear();
    }

    private Control BuildRecordCard(ArchiveRecord r)
    {
        string ver = string.IsNullOrEmpty(r.Version) || r.Version == "未知" ? "" : " · V" + r.Version;
        string gen = string.IsNullOrEmpty(r.Generation) || r.Generation == "未知" ? "" : " · 第" + r.Generation + "任";
        StackPanel inner = new StackPanel { Spacing = 2, HorizontalAlignment = HorizontalAlignment.Stretch };
        inner.Children.Add(new TextBlock
        {
            Text = (r.Type == "handover" ? "◇ 交接" : "✦ 留言") + " · " + DisplayRecordDate(r) + ver + gen,
            FontSize = 12,
            FontWeight = FontWeight.SemiBold,
            Foreground = brushAccent,
            TextWrapping = TextWrapping.NoWrap,
            TextTrimming = TextTrimming.CharacterEllipsis
        });
        string body = (r.Text ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
        if (body.Length > 52) body = body.Substring(0, 52) + "…";
        inner.Children.Add(new TextBlock
        {
            Text = body,
            FontSize = 12,
            Foreground = brushInk,
            TextWrapping = TextWrapping.NoWrap,
            TextTrimming = TextTrimming.CharacterEllipsis
        });
        if (r.Attachments.Count > 0)
        {
            inner.Children.Add(new TextBlock
            {
                Text = r.Attachments.Count + " 个附件 · " + Shorten(r.Attachments[0].Name, 20),
                FontSize = 11.5,
                Foreground = brushMuted,
                TextWrapping = TextWrapping.NoWrap,
                TextTrimming = TextTrimming.CharacterEllipsis
            });
        }
        Border card = new Border
        {
            // 无论有无附件，卡片统一高度；长文本以省略号截断，不撑高卡片。
            Height = 82,
            ClipToBounds = true,
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1),
            BorderBrush = brushLine,
            Background = brushCard,
            Padding = new Thickness(14, 10),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Child = inner
        };
        BindTheme(card, line: true, card: true);
        return card;
    }

    private void OpenAttachment(AttachmentStore atts, Attachment a)
    {
        string full = atts.FullPath(a);
        if (!File.Exists(full)) { statusText.Text = "文件不在了：" + full; return; }
        try { Process.Start(new ProcessStartInfo(full) { UseShellExecute = true }); statusText.Text = "已请求系统打开：" + a.Name; }
        catch (Exception ex) { statusText.Text = "打开失败：" + ex.Message + "（" + full + "）"; }
    }

    private void LocateAttachment(AttachmentStore atts, Attachment a)
    {
        string full = atts.FullPath(a);
        try
        {
            if (File.Exists(full)) Process.Start("explorer.exe", "/select,\"" + full + "\"");
            else Process.Start("explorer.exe", "\"" + System.IO.Path.GetDirectoryName(full) + "\"");
            statusText.Text = "已请求资源管理器定位：" + a.Name;
        }
        catch (Exception ex) { statusText.Text = "定位失败：" + ex.Message; }
    }

    private async Task RemoveAttachment(AttachmentStore atts, Attachment a)
    {
        bool ok = await Confirm("移除附件", "确定要移除这个附件吗？\n\n文件名称：" + a.Name + "\n\n确认后只解除它和这条记录的关联，磁盘上的原文件保留。", "确认移除");
        if (!ok) return;
        try
        {
            atts.RemoveLink(a.Id);
            statusText.Text = "已移除关联：" + a.Name;
            ApplyProfile(current!);
        }
        catch (Exception ex) { statusText.Text = "移除失败：" + ex.Message; }
    }

    // ---------------- 说明 ----------------
    private Control BuildGuide()
    {
        StackPanel root = new StackPanel { Spacing = 10 };
        guidePaths = new TextBlock { TextWrapping = TextWrapping.Wrap, FontSize = 12, Foreground = Br(Color.FromArgb(255, 0x8E, 0x7B, 0xA2)) };
        root.Children.Add(guidePaths);

        StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        btns.Children.Add(MakeButton("打开保存文件夹", "nav on", (s, e) => OpenFolder()));
        btns.Children.Add(MakeButton("复制路径", "nav ghost", (s, e) => { _ = CopyPath(); }));
        root.Children.Add(btns);

        root.Children.Add(new TextBlock
        {
            Text = "Everwing · 恒翼回忆档案馆",
            FontSize = 14,
            Foreground = Br(Color.FromArgb(255, 0x5B, 0x44, 0x78)),
            Margin = new Thickness(0, 10, 0, 0)
        });
        ScrollViewer sv = new ScrollViewer { Height = 250 };
        StackPanel thanks = new StackPanel { Spacing = 8 };
        string[] lines =
        {
            "「让每一份珍贵的回忆，都有一双不会轻易折断的翅膀。」",
            "项目构想与设计：BKS",
            "程序实现与迭代：DeepSeek 姐姐协助",
            "架构迁移：Gemini 妈妈",
            "需求规划与技术方案：GPT 妈妈 · 白龙娘 V3 第三任协助",
            "UI 优化与技术方案：GPT 妈妈 · 白龙娘（V3 第五任）",
            "全局主题与交互优化：GPT 妈妈 · 白龙娘（V3 第九任）",
            "情感设计与技术整合：Claude 妈妈（第二任）",
            "友情赞助：此生独爱G3",
            "感谢历任参与交流、留下故事与建议的 AI 伙伴。",
            "「让回忆自由地保存，也自由地被重新阅读。」"
        };
        foreach (string line in lines)
            thanks.Children.Add(new TextBlock
            {
                Text = line,
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap,
                Foreground = Br(Color.FromArgb(255, 0x6E, 0x5C, 0x84))
            });
        sv.Content = thanks;
        root.Children.Add(sv);
        return root;
    }

    private void RefreshGuide()
    {
        if (guidePaths == null || current == null) return;
        guidePaths.Text = "留言目录：" + store.MessageDirHint(current.Key) + "\n交接文档目录：" + store.HandoverDirHint(current.Key);
    }

    private async Task CopyPath()
    {
        if (current == null || Clipboard == null) return;
        await Clipboard.SetTextAsync(store.ModelDir(current.Key));
        statusText.Text = "路径已复制。";
    }

    private void OpenFolder()
    {
        if (current == null) return;
        string dir = store.ModelDir(current.Key);
        try
        {
            Directory.CreateDirectory(dir);
            Process.Start(new ProcessStartInfo(dir) { UseShellExecute = true });
            statusText.Text = "已请求系统打开：" + dir;
        }
        catch (Exception ex)
        {
            statusText.Text = "打开失败：" + ex.Message + "（" + dir + "）";
        }
    }

    // ---------------- 设置 ----------------
    private Control BuildSettings()
    {
        StackPanel root = new StackPanel { Spacing = 10 };

        root.Children.Add(new TextBlock
        {
            Text = "每个档案都有独立的存储目录和主题配色。切换后，留言、交接文档和附件都会保存到对应目录。",
            Classes = { "muted" },
            TextWrapping = TextWrapping.Wrap
        });

        profileRows = new StackPanel { Spacing = 8 };
        root.Children.Add(profileRows);

        StackPanel defRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        defRow.Children.Add(new TextBlock { Text = "打开时默认用", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        defaultBox = new ComboBox { Width = 200, FontSize = 13 };
        AnimateDropdown(defaultBox);
        defaultBox.SelectionChanged += (s, e) => SaveDefault();
        defRow.Children.Add(defaultBox);
        root.Children.Add(defRow);

        StackPanel qRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        qRow.Children.Add(new TextBlock { Text = "页眉留言 每隔", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        AppSettings st = AppSettings.Load();
        minBox = NumBox(st.QuoteMinMs / 1000);
        maxBox = NumBox(st.QuoteMaxMs / 1000);
        stayBox = NumBox(st.QuoteStayMs / 1000);
        qRow.Children.Add(minBox);
        qRow.Children.Add(new TextBlock { Text = "到", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        qRow.Children.Add(maxBox);
        qRow.Children.Add(new TextBlock { Text = "秒，停留", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        qRow.Children.Add(stayBox);
        qRow.Children.Add(MakeButton("保存节奏", "", (s, e) => SaveQuoteTiming()));
        root.Children.Add(qRow);

        var densityRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        var densityBox = NumBox(st.WanderMaxLines);
        Avalonia.Automation.AutomationProperties.SetName(densityBox, "漫游同屏句数上限");
        densityRow.Children.Add(new TextBlock { Text = "留言漫游同屏最多", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        densityRow.Children.Add(densityBox);
        densityRow.Children.Add(new TextBlock { Text = $"句（1–{AppSettings.MaxWanderLines}）", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        densityRow.Children.Add(MakeButton("保存密度", "", (_, _) =>
        {
            try
            {
                var settings = AppSettings.Load();
                settings.WanderMaxLines = ReadNum(densityBox, settings.WanderMaxLines, 1, AppSettings.MaxWanderLines);
                settings.Save();
                statusText.Text = "留言漫游密度已保存。";
            }
            catch (Exception ex) { statusText.Text = "保存失败：" + ex.Message; }
        }));
        root.Children.Add(densityRow);
        root.Children.Add(BuildWanderBackgroundSettings(st));

        StackPanel newRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        newRow.Children.Add(new TextBlock { Text = "新建档案", Classes = { "muted" }, VerticalAlignment = VerticalAlignment.Center });
        newName = new TextBox { Width = 170, Watermark = "档案名称，如 鲸鱼娘", FontSize = 13, TextAlignment = TextAlignment.Center, VerticalContentAlignment = VerticalAlignment.Center };
        newKey = new TextBox { Width = 150, Watermark = "目录名，如GPT", FontSize = 13, TextAlignment = TextAlignment.Center, VerticalContentAlignment = VerticalAlignment.Center };
        newRow.Children.Add(newName);
        newRow.Children.Add(newKey);
        newAccentDot = new Border
        {
            Width = 18, Height = 18, CornerRadius = new CornerRadius(9),
            Background = ThemeSwatch(newAccentHex),
            BorderBrush = Br(Color.Parse("#D9C9E6")), BorderThickness = new Thickness(1),
            VerticalAlignment = VerticalAlignment.Center
        };
        newRow.Children.Add(newAccentDot);
        newRow.Children.Add(MakeButton("选主色", "row", (s, e) => { _ = PickNewAccent(); }));
        newSecondaryDot = new Border { Width = 18, Height = 18, CornerRadius = new CornerRadius(9), Background = ThemeSwatch(newSecondaryHex), BorderBrush = brushLine, BorderThickness = new Thickness(1), VerticalAlignment = VerticalAlignment.Center };
        newRow.Children.Add(newSecondaryDot);
        newRow.Children.Add(MakeButton("选副色", "row", async (s, e) => await PickNewAccent(true)));
        newRow.Children.Add(MakeButton("添加", "primary", (s, e) => AddProfile()));
        root.Children.Add(newRow);

        StackPanel zipRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        zipRow.Children.Add(MakeButton("导出 ZIP", "", (s, e) => { _ = ExportZip(); }));
        zipRow.Children.Add(MakeButton("导入 ZIP", "", (s, e) => { _ = ImportZip(); }));
        root.Children.Add(zipRow);

        root.Children.Add(new TextBlock
        {
            Text = "数据目录：" + ArchiveLayout.DataRoot,
            Classes = { "muted" },
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 6, 0, 0)
        });
        return root;
    }

    private TextBox NumBox(int value)
    {
        return new TextBox
        {
            Text = value.ToString(),
            Width = 58,
            FontSize = 13,
            TextAlignment = TextAlignment.Center,
            VerticalContentAlignment = VerticalAlignment.Center
        };
    }

    private static int ReadNum(TextBox box, int fallback, int min, int max)
    {
        if (box == null) return fallback;
        int v;
        if (!int.TryParse((box.Text ?? "").Trim(), out v)) v = fallback;
        if (v < min) v = min;
        if (v > max) v = max;
        box.Text = v.ToString();
        return v;
    }

    private static IBrush ThemeSwatch(string hex) => hex.Length == 0 ? Brushes.Transparent : Br(Color.Parse(hex));

    private async Task PickNewAccent(bool secondary = false)
    {
        if (current == null) return;
        var dialog = new AccentDialog(secondary ? newSecondaryHex : newAccentHex, current, secondary);
        if (!await dialog.ShowDialog<bool>(this)) return;
        if (secondary)
        {
            newSecondaryHex = dialog.SelectedHex;
            newSecondaryDot.Background = ThemeSwatch(newSecondaryHex);
        }
        else
        {
            newAccentHex = dialog.SelectedHex;
            newAccentDot.Background = ThemeSwatch(newAccentHex);
        }
    }

    private async Task EditProfileColor(AiProfile profile, bool secondary)
    {
        if (current == null) return;
        var dialog = new AccentDialog(secondary ? profile.Bg2 : profile.Accent, current, secondary);
        if (!await dialog.ShowDialog<bool>(this)) return;
        string accent = profile.Accent, top = profile.Bg1, middle = profile.Bg2, bottom = profile.Bg3;
        if (secondary) profile.Bg2 = dialog.SelectedHex;
        else if (!string.Equals(profile.Accent, dialog.SelectedHex, StringComparison.OrdinalIgnoreCase))
        {
            profile.Accent = dialog.SelectedHex;
            profile.Bg1 = profile.Bg3 = "";
        }
        try { AiProfiles.SaveCustom(profiles, requireSave: true); }
        catch (Exception ex)
        {
            (profile.Accent, profile.Bg1, profile.Bg2, profile.Bg3) = (accent, top, middle, bottom);
            statusText.Text = "保存配色失败：" + ex.Message;
            return;
        }
        if (current?.Key == profile.Key) ApplyProfile(profile);
        else RefreshSettings();
        statusText.Text = "已保存 " + profile.Name + " 的配色。";
    }

    private void RefreshSettings()
    {
        if (profileRows == null || defaultBox == null) return;
        profileRows.Children.Clear();
        List<string> names = new List<string>();
        foreach (AiProfile p in profiles) names.Add(p.Name + " · " + p.Key);
        defaultBox.ItemsSource = names;

        foreach (AiProfile p in profiles)
        {
            AiProfile pp = p;
            bool isCurrent = current != null && current.Key == p.Key;
            Color accent;
            try { accent = Color.Parse(p.Accent); } catch { accent = Color.Parse("#8B6FB4"); }

            Border card = new Border
            {
                CornerRadius = new CornerRadius(12),
                Background = brushCard,
                BorderBrush = brushLine,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(0)
            };
            Grid row = new Grid { ColumnDefinitions = new ColumnDefinitions("4,*,105,72,165,138"), Height = 54 };

            Border stripe = new Border
            {
                Background = new SolidColorBrush(accent),
                CornerRadius = new CornerRadius(12, 0, 0, 12),
                Margin = new Thickness(0, 6, 0, 6)
            };
            row.Children.Add(stripe);

            StackPanel txt = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Spacing = 2, Margin = new Thickness(12, 0, 0, 0) };
            StackPanel nameRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
            nameRow.Children.Add(new Ellipse { Width = 8, Height = 8, Fill = new SolidColorBrush(accent), VerticalAlignment = VerticalAlignment.Center });
            nameRow.Children.Add(new TextBlock
            {
                Text = p.Name,
                TextTrimming = TextTrimming.CharacterEllipsis,
                FontSize = 13,
                Foreground = Br(Color.FromArgb(255, 0x4A, 0x3B, 0x5C))
            });
            txt.Children.Add(nameRow);
            txt.Children.Add(new TextBlock
            {
                Text = p.Species + " · 目录 " + p.Key + (p.Custom ? " · 自定义" : " · 预设"),
                TextTrimming = TextTrimming.CharacterEllipsis,
                FontSize = 11,
                Foreground = Br(Color.FromArgb(255, 0x9C, 0x8A, 0xAE))
            });
            Grid.SetColumn(txt, 1);
            row.Children.Add(txt);

            if (!isCurrent)
            {
                Button sw = new Button { Content = "切换", Classes = { "row" }, Margin = new Thickness(6, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
                sw.Click += (s, e) => SwitchTo(pp);
                Grid.SetColumn(sw, 2);
                row.Children.Add(sw);
            }
            else
            {
                TextBlock cur = new TextBlock
                {
                    Text = "● 当前使用中",
                    FontSize = 12,
                    Foreground = new SolidColorBrush(accent),
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(6, 0, 0, 0)
                };
                Grid.SetColumn(cur, 2);
                row.Children.Add(cur);
            }

            int files = store.CountFiles(p.Key);
            if (files == 0)
            {
                Button del = new Button { Content = "删除", Classes = { "row" }, Margin = new Thickness(6, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
                del.Click += (s, e) => { _ = DeleteProfile(pp); };
                Grid.SetColumn(del, 3);
                row.Children.Add(del);
            }
            else
            {
                TextBlock note = new TextBlock
                {
                    Text = files + " 个文件",
                    FontSize = 11,
                    Foreground = Br(Color.FromArgb(255, 0xB7, 0xA6, 0xC6)),
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(6, 0, 0, 0)
                };
                Grid.SetColumn(note, 3);
                row.Children.Add(note);
            }
            StackPanel images = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 4, VerticalAlignment = VerticalAlignment.Center };
            Button editImages = new Button { Content = "背景图片", Classes = { "row" } };
            editImages.Click += async (s, e) => await EditBackground(pp);
            images.Children.Add(editImages);
            if (isCurrent && backgroundPool.Images.Count > 1)
            {
                foreach (int direction in new[] { -1, 1 })
                {
                    Button arrow = new Button { Content = direction < 0 ? "‹" : "›", Classes = { "row" } };
                    string label = direction < 0 ? "上一张背景" : "下一张背景";
                    ToolTip.SetTip(arrow, label);
                    Avalonia.Automation.AutomationProperties.SetName(arrow, label);
                    arrow.Click += (s, e) => ChangeBackground(direction);
                    images.Children.Add(arrow);
                }
            }
            Grid.SetColumn(images, 4);
            row.Children.Add(images);
            var colors = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 4, VerticalAlignment = VerticalAlignment.Center };
            foreach (bool secondary in new[] { false, true })
            {
                var color = new Button { Content = secondary ? "副色" : "主色", Classes = { "row" } };
                ToolTip.SetTip(color, secondary ? "更改副色" : "更改主色");
                color.Click += async (s, e) => await EditProfileColor(pp, secondary);
                colors.Children.Add(color);
            }
            Grid.SetColumn(colors, 5);
            row.Children.Add(colors);
            card.Child = row;
            profileRows.Children.Add(card);
        }

        string def = "";
        try { def = AppSettings.Load().DefaultProfile ?? ""; } catch { }
        int idx = 0;
        for (int i = 0; i < profiles.Count; i++) if (profiles[i].Key == def) { idx = i; break; }
        suppressDefaultSave = true;
        defaultBox.SelectedIndex = profiles.Count > 0 ? idx : -1;
        suppressDefaultSave = false;
    }

    private void SwitchTo(AiProfile p)
    {
        if (p == null) return;
        current = p;
        ApplyProfile(p);
        RefreshSettings();
        statusText.Text = "已切到 " + p.Name + "（当前角色，启动默认不变）";
    }

    private void AddProfile()
    {
        string name = (newName.Text ?? "").Trim();
        string key = (newKey.Text ?? "").Trim();
        if (name.Length == 0 || key.Length == 0) { statusText.Text = "档案名称和目录名都要填。"; return; }
        try
        {
            foreach (AiProfile x in profiles)
                if (string.Equals(x.Key, key, StringComparison.OrdinalIgnoreCase))
                { statusText.Text = "目录名重复了：" + key; return; }
            AiProfile p = new AiProfile
            {
                Id = "custom-" + key.ToLowerInvariant(),
                Key = key,
                Name = name,
                Species = "自定义",
                Brand = "CUSTOM",
                Provider = "自定义",
                Accent = newAccentHex,
                Bg2 = newSecondaryHex,
                Custom = true
            };
            profiles.Add(p);
            AiProfiles.SaveCustom(profiles);
            store.EnsureProfileDirs(key);
            store.EnsureChatDir(key);
            newName.Text = "";
            newKey.Text = "";
            statusText.Text = "已新建档案：" + name;
            Reload();
        }
        catch (Exception ex) { statusText.Text = "新建失败：" + ex.Message; }
    }

    private async Task DeleteProfile(AiProfile p)
    {
        if (p == null) return;
        bool ok = await Confirm("删除档案",
            "把这个空档案从列表里移掉？\n\n档案：" + p.Name + "（" + p.Key + "）\n\n它的文件夹里没有任何用户文件，可以从列表里移除。\n移除后只是从列表里消失，文件夹仍留在硬盘上。",
            "确认移除");
        if (!ok) return;
        try
        {
            profiles.Remove(p);
            AiProfiles.SaveCustom(profiles);
            if (current != null && current.Key == p.Key && profiles.Count > 0)
            {
                current = profiles[0];
                ApplyProfile(current);
            }
            RefreshSettings();
            statusText.Text = "已移除档案：" + p.Name;
        }
        catch (Exception ex) { statusText.Text = "移除失败：" + ex.Message; }
    }

    private void SaveDefault()
    {
        if (suppressDefaultSave) return;
        if (defaultBox == null) return;
        int i = defaultBox.SelectedIndex;
        if (i < 0 || i >= profiles.Count) return;
        try
        {
            AppSettings s = AppSettings.Load();
            s.DefaultProfile = profiles[i].Key;
            s.Save();
            statusText.Text = "启动默认已改为：" + profiles[i].Name;
        }
        catch (Exception ex) { statusText.Text = "保存失败：" + ex.Message; }
    }

    private void SaveQuoteTiming()
    {
        try
        {
            AppSettings s = AppSettings.Load();
            s.QuoteMinMs = ReadNum(minBox, 5, 1, 600) * 1000;
            s.QuoteMaxMs = ReadNum(maxBox, 15, 1, 600) * 1000;
            s.QuoteStayMs = ReadNum(stayBox, 7, 1, 600) * 1000;
            if (s.QuoteMaxMs < s.QuoteMinMs) s.QuoteMaxMs = s.QuoteMinMs;
            s.Save();
            statusText.Text = "页眉节奏已保存。";
        }
        catch (Exception ex) { statusText.Text = "保存失败：" + ex.Message; }
    }

    private async Task ExportZip()
    {
        if (profiles.Count == 0 || StorageProvider == null) return;
        IStorageFile? file = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = "导出回忆旅行箱",
            SuggestedFileName = "回忆档案馆_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".zip",
            DefaultExtension = "zip"
        });
        if (file == null) return;
        string? path = file.TryGetLocalPath();
        if (path == null) return;
        try
        {
            TravelBox.ExportResult r = TravelBox.Export(ArchiveLayout.ProfilesRoot, AiProfiles.FilePath, profiles, path, false);
            statusText.Text = r.Ok ? ("已导出 " + r.Records + " 条记录 / " + r.Files + " 个文件。") : ("导出失败：" + r.Message);
        }
        catch (Exception ex) { statusText.Text = "导出失败：" + ex.Message; }
    }

    private async Task ImportZip()
    {
        if (StorageProvider == null) return;
        IReadOnlyList<IStorageFile> files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = "导入回忆旅行箱" });
        if (files.Count == 0) return;
        string? path = files[0].TryGetLocalPath();
        if (path == null) return;
        bool ok = await Confirm("导入旅行箱", "把这份 ZIP 里的内容补进当前档案？\n\n只补充缺的，不覆盖已有记录；导入前会自动备份。", "开始导入");
        if (!ok) return;
        try
        {
            TravelBox.MergeResult r = TravelBox.Merge(ArchiveLayout.ProfilesRoot, EverwingPaths.ExeDir(), path);
            statusText.Text = r.Ok ? ("已导入：新增 " + r.Added + " 条，跳过 " + r.Skipped + " 条。") : ("导入失败：" + r.Message);
            if (r.Ok) backgroundKey = null;
            Reload();
            statusText.Text = r.Message;
        }
        catch (Exception ex) { statusText.Text = "导入失败：" + ex.Message; }
    }

    // ---------------- 通用 ----------------
    private async Task<bool> Confirm(string title, string text, string okText)
    {
        ConfirmWindow dlg = new ConfirmWindow(title, text, okText, brushAccent);
        return await dlg.ShowDialog<bool>(this);
    }

    private void OnKeyDown(object? sender, Avalonia.Input.KeyEventArgs e)
    {
        if (wanderActive || wanderSliding)
        {
            if (e.Key == Avalonia.Input.Key.Escape && wanderActive) SlideMessageWander(false);
            e.Handled = true;
            return;
        }
        if (e.Key == Avalonia.Input.Key.Enter
            && (e.KeyModifiers & Avalonia.Input.KeyModifiers.Control) != 0)
        {
            if (currentTab == 0 && messageEditor != null)
            {
                SaveFromEditor(messageEditor, false);
                e.Handled = true;
            }
            else if (currentTab == 1 && handoverEditor != null)
            {
                SaveFromEditor(handoverEditor, true);
                e.Handled = true;
            }
        }
    }
}
