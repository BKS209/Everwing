using System;
using System.Globalization;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;

namespace Everwing.Views;

internal sealed class ScrubNumber : Grid
{
    private readonly Button display = new() { HorizontalAlignment = HorizontalAlignment.Stretch, HorizontalContentAlignment = HorizontalAlignment.Center };
    private readonly TextBox input = new() { TextAlignment = Avalonia.Media.TextAlignment.Center, VerticalContentAlignment = VerticalAlignment.Center, IsVisible = false };
    private readonly decimal min, max;
    private decimal value, startValue;
    private double startX;
    private IPointer? pointer;
    private bool dragged;

    internal event EventHandler? ValueChanged;
    internal decimal Value
    {
        get => value;
        set
        {
            decimal next = Math.Clamp(value, min, max);
            if (this.value == next && display.Content != null) return;
            this.value = next;
            display.Content = next.ToString("0.##", CultureInfo.CurrentCulture);
            ValueChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    internal ScrubNumber(int min, int max, string label)
    {
        this.min = min;
        this.max = max;
        Width = 106;
        Height = 34;
        display.Cursor = new Cursor(StandardCursorType.SizeWestEast);
        AutomationProperties.SetName(display, label);
        AutomationProperties.SetName(input, label);
        ToolTip.SetTip(display, "左右拖动调整 · 单击输入");
        Children.Add(display);
        Children.Add(input);
        display.AddHandler(PointerPressedEvent, Press, Avalonia.Interactivity.RoutingStrategies.Tunnel);
        display.PointerMoved += Move;
        display.AddHandler(PointerReleasedEvent, Release, Avalonia.Interactivity.RoutingStrategies.Tunnel);
        display.PointerCaptureLost += (_, _) => pointer = null;
        display.Click += (_, _) => BeginEdit();
        input.LostFocus += (_, _) => EndEdit(true);
        input.KeyDown += (_, e) =>
        {
            if (e.Key != Key.Enter && e.Key != Key.Escape) return;
            EndEdit(e.Key == Key.Enter);
            display.Focus();
            e.Handled = true;
        };
        Value = min;
    }

    private void Press(object? sender, PointerPressedEventArgs e)
    {
        if (pointer != null || !e.GetCurrentPoint(display).Properties.IsLeftButtonPressed) return;
        pointer = e.Pointer;
        startX = e.GetPosition(this).X;
        startValue = Value;
        dragged = false;
        display.Focus();
        e.Pointer.Capture(display);
        e.Handled = true;
    }

    private void Move(object? sender, PointerEventArgs e)
    {
        if (pointer != e.Pointer) return;
        double delta = e.GetPosition(this).X - startX;
        if (!dragged && Math.Abs(delta) < 4) return;
        dragged = true;
        Value = startValue + (decimal)Math.Round(delta / 2, MidpointRounding.AwayFromZero);
    }

    private void Release(object? sender, PointerReleasedEventArgs e)
    {
        if (pointer != e.Pointer) return;
        pointer = null;
        e.Pointer.Capture(null);
        e.Handled = true;
        if (!dragged) BeginEdit();
    }

    private void BeginEdit()
    {
        input.Text = Value.ToString("0.##", CultureInfo.CurrentCulture);
        input.IsVisible = true;
        display.IsVisible = false;
        input.Focus();
        input.SelectAll();
    }

    internal void EndEdit(bool commit = true)
    {
        if (!input.IsVisible) return;
        if (commit && decimal.TryParse(input.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out decimal typed))
            Value = typed;
        display.IsVisible = true;
        input.IsVisible = false;
    }
}
