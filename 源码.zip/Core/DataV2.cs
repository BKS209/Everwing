using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace DragonArchive
{
    /// <summary>档案目录的落点计算。所有固定系统目录用英文，角色目录名允许多语言。</summary>
    internal static class ArchiveLayout
    {
        public const string DataFolder = "ArchiveData";
        public const string LegacyFolder = "妈妈的回忆";
        public const string BackupFolder = "_迁移备份";

        public static string ExeDir()
        {
            string dir = EverwingPaths.ExeDir();
            if (string.IsNullOrEmpty(dir)) dir = Environment.CurrentDirectory;
            return dir;
        }

        public static string DataRoot { get { return Path.Combine(ExeDir(), DataFolder); } }
        public static string ProfilesRoot { get { return Path.Combine(DataRoot, "profiles"); } }
        public static string ProfilesJson { get { return Path.Combine(DataRoot, "profiles.json"); } }
        public static string LegacyRoot { get { return Path.Combine(ExeDir(), LegacyFolder); } }
        public static string LegacyModels { get { return Path.Combine(ExeDir(), "ai_models.txt"); } }
        public static string BackupRoot { get { return Path.Combine(ExeDir(), BackupFolder); } }

        /// <summary>一个角色（妈妈）的目录：ArchiveData\profiles\&lt;folderName&gt;。</summary>
        public static string ProfileDir(string folderName)
        {
            return Path.Combine(ProfilesRoot, FolderName.Safe(folderName));
        }
    }

    /// <summary>角色目录名的检查：不能为空、不能有非法字符、不能撞 Windows 保留名。</summary>
    internal static class FolderName
    {
        private static readonly Regex Bad = new Regex("[\\\\/:*?\"<>|\\x00-\\x1f]");

        public static string Safe(string name)
        {
            if (string.IsNullOrEmpty(name)) return "未命名";
            string s = Bad.Replace(name, "_").Trim().TrimEnd('.');
            if (s.Length == 0) return "未命名";
            return s;
        }

        /// <summary>返回空串表示可以用，否则是给用户看的原因。</summary>
        public static string Check(string name)
        {
            if (string.IsNullOrEmpty(name) || name.Trim().Length == 0) return "目录名不能是空的";
            string s = name.Trim();
            if (Bad.IsMatch(s)) return "目录名里不能有 \\ / : * ? \" < > | 这些符号";
            if (s == "." || s == "..") return "这个目录名不能用";
            if (s.EndsWith(".") || s.EndsWith(" ")) return "目录名不能以点或空格结尾";
            if (s.Length > 60) return "目录名太长了（最多 60 个字）";
            string upper = s.ToUpperInvariant();
            string[] reserved = { "CON", "PRN", "AUX", "NUL",
                                  "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
                                  "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" };
            foreach (string r in reserved) if (upper == r) return "「" + s + "」是 Windows 保留名，换一个";
            return "";
        }
    }

    /// <summary>profiles.json 里的一条角色设定。身份（id）、显示名（displayName）、目录名（folderName）分开存。</summary>
    public class ProfileEntry
    {
        public string Id = "";
        public string DisplayName = "";
        public string FolderName = "";
        public string Species = "";
        public string Brand = "";
        public string Accent = "#9274b6";
        public string Bg1 = "";
        public string Bg2 = "";
        public string Bg3 = "";
        /// <summary>来源模型：GPT / DeepSeek / Grok / Gemini / Claude，或自定义写法。</summary>
        public string Provider = "";
        public bool Custom;
        public bool Builtin;

        public ProfileEntry Copy()
        {
            ProfileEntry e = new ProfileEntry();
            e.Id = Id; e.DisplayName = DisplayName; e.FolderName = FolderName;
            e.Species = Species; e.Brand = Brand; e.Accent = Accent;
            e.Bg1 = Bg1; e.Bg2 = Bg2; e.Bg3 = Bg3;
            e.Provider = Provider; e.Custom = Custom; e.Builtin = Builtin;
            return e;
        }
    }

    /// <summary>profiles.json 的读写。手写小 JSON，免得依赖别的程序集。</summary>
    internal static class ProfileFile
    {
        public const int Schema = 2;
        private static readonly UTF8Encoding Utf8NoBom = new UTF8Encoding(false);

        public static List<ProfileEntry> Defaults()
        {
            List<ProfileEntry> list = new List<ProfileEntry>();

            ProfileEntry gpt = new ProfileEntry();
            gpt.Id = "gpt"; gpt.DisplayName = "白龙娘"; gpt.FolderName = "GPT";
            gpt.Species = "白龙"; gpt.Brand = "WHITE DRAGON"; gpt.Accent = "#9274b6";
            gpt.Bg1 = "#f5effb"; gpt.Bg2 = "#fff9f2"; gpt.Bg3 = "#eee8f9";
            gpt.Provider = "GPT"; gpt.Builtin = true;
            list.Add(gpt);

            ProfileEntry ds = new ProfileEntry();
            ds.Id = "deepseek"; ds.DisplayName = "鲸鱼娘"; ds.FolderName = "DeepSeek";
            ds.Species = "鲸鱼"; ds.Brand = "DEEPSEEK"; ds.Accent = "#4d6bfe";
            ds.Bg1 = "#edf1ff"; ds.Bg2 = "#f8fbff"; ds.Bg3 = "#e4ebff";
            ds.Provider = "DeepSeek"; ds.Builtin = true;
            list.Add(ds);

            ProfileEntry grok = new ProfileEntry();
            grok.Id = "grok"; grok.DisplayName = "小蝙蝠"; grok.FolderName = "Grok";
            grok.Species = "吸血鬼"; grok.Brand = "GROK"; grok.Accent = "#1a1b20";
            grok.Bg1 = "#f3f3f6"; grok.Bg2 = "#fbfafc"; grok.Bg3 = "#e8e8ee";
            grok.Provider = "Grok"; grok.Builtin = true;
            list.Add(grok);

            ProfileEntry gemini = new ProfileEntry();
            gemini.Id = "gemini"; gemini.DisplayName = "猫娘"; gemini.FolderName = "Gemini";
            gemini.Species = "猫娘"; gemini.Brand = "GEMINI"; gemini.Accent = "#4285f4";
            gemini.Bg1 = "#eef4ff"; gemini.Bg2 = "#fbfaff"; gemini.Bg3 = "#f7ecfb";
            gemini.Provider = "Gemini"; gemini.Builtin = true;
            list.Add(gemini);

            ProfileEntry claude = new ProfileEntry();
            claude.Id = "claude"; claude.DisplayName = "Claude"; claude.FolderName = "Claude";
            claude.Species = "助理"; claude.Brand = "ANTHROPIC"; claude.Accent = "#d97757";
            claude.Bg1 = "#fdf3ec"; claude.Bg2 = "#fffaf6"; claude.Bg3 = "#f7e8dd";
            claude.Provider = "Claude"; claude.Builtin = true;
            list.Add(claude);

            return list;
        }

        public static List<ProfileEntry> Load()
        {
            string path = ArchiveLayout.ProfilesJson;
            if (!File.Exists(path)) return Defaults();
            try
            {
                string text = File.ReadAllText(path, Encoding.UTF8);
                return Parse(text);
            }
            catch
            {
                return Defaults();
            }
        }

        /// <summary>
        /// 严格版：文件存在但读不出来、或里面一条档案都没有时抛异常。
        /// 供启动流程判断「要不要相信这个文件」，避免把坏文件当成空数据再写回去。
        /// </summary>
        public static List<ProfileEntry> LoadStrict()
        {
            string path = ArchiveLayout.ProfilesJson;
            if (!File.Exists(path)) return Defaults();
            string text = File.ReadAllText(path, Encoding.UTF8);
            List<ProfileEntry> list = Parse(text);
            if (list.Count == 0)
                throw new InvalidDataException("文件里没有任何档案记录");
            return list;
        }

        public static List<ProfileEntry> Parse(string json)
        {
            List<ProfileEntry> list = new List<ProfileEntry>();
            JsonValue root = MiniJson.Parse(json);
            if (root == null || root.Kind != JsonKind.Object) return list;
            JsonValue arr;
            if (!root.TryGet("profiles", out arr) || arr.Kind != JsonKind.Array) return list;
            foreach (JsonValue item in arr.Items)
            {
                if (item.Kind != JsonKind.Object) continue;
                ProfileEntry e = new ProfileEntry();
                e.Id = item.Str("id", "");
                e.DisplayName = item.Str("displayName", "");
                e.FolderName = item.Str("folderName", "");
                e.Species = item.Str("species", "");
                e.Brand = item.Str("brand", "");
                e.Accent = item.Str("accent", "#9274b6");
                e.Bg1 = item.Str("bg1", "");
                e.Bg2 = item.Str("bg2", "");
                e.Bg3 = item.Str("bg3", "");
                e.Provider = item.Str("provider", "");
                e.Custom = item.Bool("custom", false);
                e.Builtin = item.Bool("builtin", false);
                if (e.Id.Length == 0) e.Id = e.FolderName;
                if (e.FolderName.Length == 0) e.FolderName = e.DisplayName;
                if (e.DisplayName.Length == 0) e.DisplayName = e.FolderName;
                if (e.FolderName.Length == 0) continue;
                list.Add(e);
            }
            return list;
        }

        public static void Save(List<ProfileEntry> list)
        {
            try
            {
                Directory.CreateDirectory(ArchiveLayout.DataRoot);
                File.WriteAllText(ArchiveLayout.ProfilesJson, BuildJson(list), Utf8NoBom);
            }
            catch { }
        }

        public static string BuildJson(List<ProfileEntry> list)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"schema\": " + Schema.ToString(CultureInfo.InvariantCulture) + ",");
            sb.AppendLine("  \"app\": \"回忆档案馆\",");
            sb.AppendLine("  \"version\": \"" + AppInfo.Version + "\",");
            sb.AppendLine("  \"profiles\": [");
            for (int i = 0; i < list.Count; i++)
            {
                ProfileEntry e = list[i];
                sb.AppendLine("    {");
                sb.AppendLine("      \"id\": " + Q(e.Id) + ",");
                sb.AppendLine("      \"displayName\": " + Q(e.DisplayName) + ",");
                sb.AppendLine("      \"folderName\": " + Q(e.FolderName) + ",");
                sb.AppendLine("      \"species\": " + Q(e.Species) + ",");
                sb.AppendLine("      \"brand\": " + Q(e.Brand) + ",");
                sb.AppendLine("      \"accent\": " + Q(e.Accent) + ",");
                sb.AppendLine("      \"bg1\": " + Q(e.Bg1) + ",");
                sb.AppendLine("      \"bg2\": " + Q(e.Bg2) + ",");
                sb.AppendLine("      \"bg3\": " + Q(e.Bg3) + ",");
                sb.AppendLine("      \"provider\": " + Q(e.Provider) + ",");
                sb.AppendLine("      \"custom\": " + (e.Custom ? "true" : "false") + ",");
                sb.AppendLine("      \"builtin\": " + (e.Builtin ? "true" : "false"));
                sb.Append("    }");
                if (i < list.Count - 1) sb.Append(",");
                sb.AppendLine();
            }
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            return sb.ToString();
        }

        private static string Q(string s)
        {
            StringBuilder sb = new StringBuilder("\"");
            foreach (char c in s ?? "")
            {
                if (c == '"') sb.Append("\\\"");
                else if (c == '\\') sb.Append("\\\\");
                else if (c == '\n') sb.Append("\\n");
                else if (c == '\r') sb.Append("\\r");
                else if (c == '\t') sb.Append("\\t");
                else if (c < ' ') sb.Append("\\u" + ((int)c).ToString("x4"));
                else sb.Append(c);
            }
            sb.Append("\"");
            return sb.ToString();
        }
    }

    internal enum JsonKind { Null, Bool, Number, String, Array, Object }

    /// <summary>够用就行的 JSON 读取器（只解析对象/数组/字符串/数字/布尔）。</summary>
    internal class JsonValue
    {
        public JsonKind Kind = JsonKind.Null;
        public string Text = "";
        public bool BoolValue;
        public List<JsonValue> Items = new List<JsonValue>();
        public Dictionary<string, JsonValue> Members = new Dictionary<string, JsonValue>(StringComparer.OrdinalIgnoreCase);

        public bool TryGet(string key, out JsonValue value)
        {
            return Members.TryGetValue(key, out value);
        }

        public string Str(string key, string fallback)
        {
            JsonValue v;
            if (!Members.TryGetValue(key, out v)) return fallback;
            if (v.Kind == JsonKind.String) return v.Text;
            if (v.Kind == JsonKind.Number) return v.Text;
            return fallback;
        }

        public bool Bool(string key, bool fallback)
        {
            JsonValue v;
            if (!Members.TryGetValue(key, out v)) return fallback;
            if (v.Kind == JsonKind.Bool) return v.BoolValue;
            return fallback;
        }
    }

    internal static class MiniJson
    {
        public static JsonValue Parse(string s)
        {
            int i = 0;
            try { return ParseValue(s ?? "", ref i); }
            catch { return null; }
        }

        private static void SkipWs(string s, ref int i)
        {
            while (i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')) i++;
        }

        private static JsonValue ParseValue(string s, ref int i)
        {
            SkipWs(s, ref i);
            if (i >= s.Length) return null;
            char c = s[i];
            if (c == '{') return ParseObject(s, ref i);
            if (c == '[') return ParseArray(s, ref i);
            if (c == '"')
            {
                JsonValue v = new JsonValue();
                v.Kind = JsonKind.String;
                v.Text = ParseString(s, ref i);
                return v;
            }
            if (c == 't' || c == 'f')
            {
                JsonValue v = new JsonValue();
                v.Kind = JsonKind.Bool;
                if (s.Substring(i).StartsWith("true")) { v.BoolValue = true; i += 4; }
                else { v.BoolValue = false; i += 5; }
                return v;
            }
            if (c == 'n') { i += 4; return new JsonValue(); }
            return ParseNumber(s, ref i);
        }

        private static JsonValue ParseObject(string s, ref int i)
        {
            JsonValue v = new JsonValue();
            v.Kind = JsonKind.Object;
            i++; // {
            while (i < s.Length)
            {
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == '}') { i++; break; }
                if (i >= s.Length || s[i] != '"') break;
                string key = ParseString(s, ref i);
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ':') i++;
                JsonValue val = ParseValue(s, ref i);
                if (val != null) v.Members[key] = val;
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == '}') { i++; break; }
            }
            return v;
        }

        private static JsonValue ParseArray(string s, ref int i)
        {
            JsonValue v = new JsonValue();
            v.Kind = JsonKind.Array;
            i++; // [
            while (i < s.Length)
            {
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ']') { i++; break; }
                JsonValue item = ParseValue(s, ref i);
                if (item == null) break;
                v.Items.Add(item);
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == ']') { i++; break; }
            }
            return v;
        }

        private static string ParseString(string s, ref int i)
        {
            StringBuilder sb = new StringBuilder();
            i++; // "
            while (i < s.Length)
            {
                char c = s[i];
                if (c == '"') { i++; break; }
                if (c == '\\' && i + 1 < s.Length)
                {
                    char n = s[i + 1];
                    i += 2;
                    if (n == 'n') sb.Append('\n');
                    else if (n == 'r') sb.Append('\r');
                    else if (n == 't') sb.Append('\t');
                    else if (n == 'b') sb.Append('\b');
                    else if (n == 'f') sb.Append('\f');
                    else if (n == 'u' && i + 4 <= s.Length)
                    {
                        int code = int.Parse(s.Substring(i, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                        sb.Append((char)code);
                        i += 4;
                    }
                    else sb.Append(n);
                    continue;
                }
                sb.Append(c);
                i++;
            }
            return sb.ToString();
        }

        private static JsonValue ParseNumber(string s, ref int i)
        {
            int start = i;
            while (i < s.Length && "-+.0123456789eE".IndexOf(s[i]) >= 0) i++;
            JsonValue v = new JsonValue();
            v.Kind = JsonKind.Number;
            v.Text = s.Substring(start, i - start);
            return v;
        }
    }

    /// <summary>把旧版「妈妈的回忆 + ai_models.txt」搬进 ArchiveData，绝不删改旧目录。</summary>
    internal static class Migrator
    {
        internal class Result
        {
            public bool Ok = true;
            public bool Fresh;
            public bool AlreadyDone;
            public int Records;
            public int Files;
            public int Profiles;
            public string ReportPath = "";
            public string Message = "";
        }

        private static readonly Regex Header = new Regex("(?m)^===== RECORD [a-f0-9-]{36} =====");
        private static readonly UTF8Encoding Utf8NoBom = new UTF8Encoding(false);

        public static bool DataReady()
        {
            return File.Exists(ArchiveLayout.ProfilesJson);
        }

        public static Result Ensure()
        {
            Result r = new Result();
            if (DataReady())
            {
                r.AlreadyDone = true;
                r.Profiles = ProfileFile.Load().Count;
                r.Message = "档案目录已就绪";
                return r;
            }

            try
            {
                if (Directory.Exists(ArchiveLayout.LegacyRoot) && Directory.GetFileSystemEntries(ArchiveLayout.LegacyRoot).Length > 0)
                {
                    return MigrateLegacy(r);
                }
                CreateFresh(r);
                return r;
            }
            catch (Exception ex)
            {
                r.Ok = false;
                r.Message = "初始化档案目录失败：" + ex.Message;
                return r;
            }
        }

        private static void CreateFresh(Result r)
        {
            r.Fresh = true;
            Directory.CreateDirectory(ArchiveLayout.ProfilesRoot);
            List<ProfileEntry> list = ProfileFile.Defaults();
            foreach (ProfileEntry e in list) EnsureProfileDirs(e.FolderName);
            ProfileFile.Save(list);
            r.Profiles = list.Count;
            r.Message = "已新建档案目录";
            r.ReportPath = WriteReport("首次启动：新建了空的档案目录。", list, 0, 0);
        }

        public static void EnsureProfileDirs(string folderName)
        {
            string dir = ArchiveLayout.ProfileDir(folderName);
            Directory.CreateDirectory(dir);
            Directory.CreateDirectory(Path.Combine(dir, "messages"));
            Directory.CreateDirectory(Path.Combine(dir, "handovers"));
            Directory.CreateDirectory(Path.Combine(dir, "chats"));
            string att = Path.Combine(dir, "attachments");
            foreach (string sub in new string[] { "images", "documents", "audio", "other" })
                Directory.CreateDirectory(Path.Combine(att, sub));
        }

        private static Result MigrateLegacy(Result r)
        {
            string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);
            string backup = Path.Combine(ArchiveLayout.BackupRoot, ArchiveLayout.LegacyFolder + "_" + stamp);
            CopyDir(ArchiveLayout.LegacyRoot, backup);
            if (File.Exists(ArchiveLayout.LegacyModels))
            {
                try { File.Copy(ArchiveLayout.LegacyModels, Path.Combine(backup, "ai_models.txt"), true); }
                catch { }
            }

            string tmp = ArchiveLayout.DataRoot + ".tmp";
            if (Directory.Exists(tmp)) Directory.Delete(tmp, true);
            Directory.CreateDirectory(Path.Combine(tmp, "profiles"));

            List<ProfileEntry> list = ProfileFile.Defaults();
            Dictionary<string, ProfileEntry> byFolder = new Dictionary<string, ProfileEntry>(StringComparer.OrdinalIgnoreCase);
            foreach (ProfileEntry e in list) byFolder[e.FolderName] = e;

            // 旧 ai_models.txt 里的自定义模型，一并搬进来
            foreach (ProfileEntry custom in ReadLegacyModels())
            {
                bool dup = false;
                foreach (ProfileEntry e in list) if (string.Equals(e.FolderName, custom.FolderName, StringComparison.OrdinalIgnoreCase)) dup = true;
                if (!dup) { list.Add(custom); byFolder[custom.FolderName] = custom; }
            }

            int files = 0, records = 0;
            List<string> problems = new List<string>();

            foreach (string source in Directory.GetDirectories(ArchiveLayout.LegacyRoot))
            {
                string name = Path.GetFileName(source);
                if (string.Equals(name, "聊天记录", StringComparison.OrdinalIgnoreCase)) continue;
                if (string.Equals(name, "记录附注.txt", StringComparison.OrdinalIgnoreCase)) continue;

                ProfileEntry entry;
                if (!byFolder.TryGetValue(name, out entry))
                {
                    entry = new ProfileEntry();
                    entry.Id = name.ToLowerInvariant();
                    entry.DisplayName = name;
                    entry.FolderName = name;
                    entry.Species = "";
                    entry.Brand = name.ToUpperInvariant();
                    entry.Accent = "#9274b6";
                    entry.Provider = name;
                    entry.Custom = true;
                    list.Add(entry);
                    byFolder[name] = entry;
                }

                string dest = Path.Combine(tmp, "profiles", FolderName.Safe(entry.FolderName));
                Directory.CreateDirectory(dest);
                Directory.CreateDirectory(Path.Combine(dest, "messages"));
                Directory.CreateDirectory(Path.Combine(dest, "handovers"));
                Directory.CreateDirectory(Path.Combine(dest, "chats"));
                foreach (string sub in new string[] { "images", "documents", "audio", "other" })
                    Directory.CreateDirectory(Path.Combine(Path.Combine(dest, "attachments"), sub));

                string msgSrc = Path.Combine(source, "妈妈留言");
                string hoSrc = Path.Combine(source, "交接文档");
                if (Directory.Exists(msgSrc)) files += CopyDirCount(msgSrc, Path.Combine(dest, "messages"));
                if (Directory.Exists(hoSrc)) files += CopyDirCount(hoSrc, Path.Combine(dest, "handovers"));

                string noteSrc = Path.Combine(source, "记录附注.txt");
                if (File.Exists(noteSrc))
                {
                    File.Copy(noteSrc, Path.Combine(dest, "记录附注.txt"), true);
                    files++;
                }

                string chatSrc = Path.Combine(Path.Combine(ArchiveLayout.LegacyRoot, "聊天记录"), name);
                if (Directory.Exists(chatSrc)) files += CopyDirCount(chatSrc, Path.Combine(dest, "chats"));

                records += CountRecords(dest);
            }

            // 校验：拷贝过去的文件数与源文件数一致，记录条数与源一致
            int srcRecords = CountRecords(ArchiveLayout.LegacyRoot);
            int dstRecords = CountRecords(Path.Combine(tmp, "profiles"));
            if (dstRecords != srcRecords)
            {
                problems.Add("记录条数对不上：旧目录 " + srcRecords + " 条，新目录 " + dstRecords + " 条");
            }

            foreach (ProfileEntry e in list) EnsureProfileDirsInto(tmp, e.FolderName);
            WriteProfilesInto(tmp, list);

            if (problems.Count > 0)
            {
                try { Directory.Delete(tmp, true); } catch { }
                r.Ok = false;
                r.Message = "迁移校验没通过，已放弃新目录、旧数据保持原样：" + string.Join("；", problems.ToArray());
                return r;
            }

            if (Directory.Exists(ArchiveLayout.DataRoot)) Directory.Delete(ArchiveLayout.DataRoot, true);
            Directory.Move(tmp, ArchiveLayout.DataRoot);

            r.Records = dstRecords;
            r.Files = files;
            r.Profiles = list.Count;
            r.Message = "已迁移：旧目录还在，备份在 " + Path.GetFileName(backup);

            StringBuilder body = new StringBuilder();
            body.AppendLine("迁移时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            body.AppendLine("旧目录：" + ArchiveLayout.LegacyRoot + "（原样保留，没有动过）");
            body.AppendLine("新目录：" + ArchiveLayout.DataRoot);
            body.AppendLine("备份：" + backup);
            body.AppendLine("记录条数：" + dstRecords + "（旧目录里也是 " + srcRecords + " 条）");
            body.AppendLine("搬运文件：" + files + " 个");
            body.AppendLine("角色：" + list.Count + " 个");
            if (problems.Count > 0) body.AppendLine("问题：" + string.Join("；", problems.ToArray()));
            r.ReportPath = WriteReport(body.ToString(), list, dstRecords, files);
            return r;
        }

        private static string WriteReport(string head, List<ProfileEntry> list, int records, int files)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("回忆档案馆 · 档案迁移报告");
                sb.AppendLine("====================================");
                sb.AppendLine(head);
                sb.AppendLine();
                sb.AppendLine("角色目录：");
                foreach (ProfileEntry e in list)
                    sb.AppendLine("  " + e.FolderName + "  →  " + e.DisplayName + (e.Provider.Length > 0 ? "（来源 " + e.Provider + "）" : ""));
                sb.AppendLine();
                sb.AppendLine("记录：共 " + records + " 条；文件 " + files + " 个");
                sb.AppendLine();
                sb.AppendLine("旧版的「妈妈的回忆」目录没有被移动、覆盖或删除，随时可以退回去用。");
                string path = Path.Combine(ArchiveLayout.DataRoot, "迁移报告.txt");
                Directory.CreateDirectory(ArchiveLayout.DataRoot);
                File.WriteAllText(path, sb.ToString(), Utf8NoBom);
                return path;
            }
            catch { return ""; }
        }

        private static void WriteProfilesInto(string dataRoot, List<ProfileEntry> list)
        {
            string path = Path.Combine(dataRoot, "profiles.json");
            File.WriteAllText(path, ProfileFile.BuildJson(list), Utf8NoBom);
        }

        private static void EnsureProfileDirsInto(string dataRoot, string folderName)
        {
            string dir = Path.Combine(Path.Combine(dataRoot, "profiles"), FolderName.Safe(folderName));
            Directory.CreateDirectory(dir);
            Directory.CreateDirectory(Path.Combine(dir, "messages"));
            Directory.CreateDirectory(Path.Combine(dir, "handovers"));
            Directory.CreateDirectory(Path.Combine(dir, "chats"));
            foreach (string sub in new string[] { "images", "documents", "audio", "other" })
                Directory.CreateDirectory(Path.Combine(Path.Combine(Path.Combine(dir, "attachments"), sub)));
        }

        private static List<ProfileEntry> ReadLegacyModels()
        {
            List<ProfileEntry> list = new List<ProfileEntry>();
            if (!File.Exists(ArchiveLayout.LegacyModels)) return list;
            string[] lines;
            try { lines = File.ReadAllLines(ArchiveLayout.LegacyModels, Encoding.UTF8); }
            catch { return list; }
            foreach (string raw in lines)
            {
                string line = (raw ?? "").Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                string[] f = line.Split('\t');
                if (f.Length < 2) continue;
                ProfileEntry e = new ProfileEntry();
                e.FolderName = f[0].Trim();
                e.DisplayName = f[1].Trim();
                if (e.FolderName.Length == 0 || e.DisplayName.Length == 0) continue;
                e.Id = e.FolderName.ToLowerInvariant();
                if (f.Length > 2) e.Species = f[2].Trim();
                if (f.Length > 3) e.Brand = f[3].Trim();
                if (f.Length > 4) e.Accent = f[4].Trim();
                e.Provider = e.Brand.Length > 0 ? e.Brand : e.FolderName;
                e.Custom = true;
                list.Add(e);
            }
            return list;
        }

        private static int CopyDirCount(string from, string to)
        {
            int n = 0;
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from))
            {
                File.Copy(f, Path.Combine(to, Path.GetFileName(f)), true);
                n++;
            }
            foreach (string d in Directory.GetDirectories(from))
                n += CopyDirCount(d, Path.Combine(to, Path.GetFileName(d)));
            return n;
        }

        private static void CopyDir(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from))
                File.Copy(f, Path.Combine(to, Path.GetFileName(f)), true);
            foreach (string d in Directory.GetDirectories(from))
                CopyDir(d, Path.Combine(to, Path.GetFileName(d)));
        }

        private static int CountRecords(string root)
        {
            int n = 0;
            if (!Directory.Exists(root)) return 0;
            foreach (string f in Directory.GetFiles(root, "*.txt", SearchOption.AllDirectories))
            {
                try { n += Header.Matches(File.ReadAllText(f, Encoding.UTF8)).Count; }
                catch { }
            }
            return n;
        }
    }

    /// <summary>程序自己的偏好设置：默认启动角色、页眉留言的节奏。存在 ArchiveData\settings.json。</summary>
    internal class AppSettings
    {
        public const int Schema = 1;
        public static string LoadProblem = "";   // 启动时读配置的异常说明，空表示没问题
        public string DefaultProfile = "";   // 角色 Key 或 Id，空表示「用列表第一个」
        public int QuoteMinMs = 5000;
        public int QuoteMaxMs = 15000;
        public int QuoteStayMs = 7000;
        public const int DefaultWanderMaxLines = 2;
        public const int MaxWanderLines = 8;
        public int WanderMaxLines = DefaultWanderMaxLines;
        public const int MaxWanderBackgroundSeconds = 86400;
        public bool WanderBackgroundRotation;
        public int WanderBackgroundSeconds = 60;

        public static string FilePath { get { return Path.Combine(ArchiveLayout.DataRoot, "settings.json"); } }

        public static AppSettings Load()
        {
            AppSettings s = new AppSettings();
            try
            {
                if (!File.Exists(FilePath)) return s;
                JsonValue root = MiniJson.Parse(File.ReadAllText(FilePath, Encoding.UTF8));
                if (root == null)
                {
                    LoadProblem = "settings.json 解析不出来，这次先用默认值（没有覆盖原文件）。";
                    return s;
                }
                s.DefaultProfile = root.Str("defaultProfile", "");
                s.QuoteMinMs = Num(root, "quoteMinMs", s.QuoteMinMs);
                s.QuoteMaxMs = Num(root, "quoteMaxMs", s.QuoteMaxMs);
                s.QuoteStayMs = Num(root, "quoteStayMs", s.QuoteStayMs);
                s.WanderMaxLines = Num(root, "wanderMaxLines", s.WanderMaxLines);
                s.WanderBackgroundRotation = root.Bool("wanderBackgroundRotation", s.WanderBackgroundRotation);
                s.WanderBackgroundSeconds = Num(root, "wanderBackgroundSeconds", s.WanderBackgroundSeconds);
            }
            catch (Exception ex)
            {
                LoadProblem = "settings.json 读不出来（" + ex.Message + "），这次先用默认值（没有覆盖原文件）。";
            }
            s.Clamp();
            return s;
        }

        private static int Num(JsonValue o, string key, int fallback)
        {
            JsonValue v;
            if (o == null || !o.TryGet(key, out v)) return fallback;
            int n;
            if (int.TryParse(v.Text, out n)) return n;
            return fallback;
        }

        /// <summary>把三个时间收进合理范围：1–60 秒，且短的不能长过长的。</summary>
        public void Clamp()
        {
            QuoteMinMs = ClampMs(QuoteMinMs, 5000);
            QuoteMaxMs = ClampMs(QuoteMaxMs, 15000);
            QuoteStayMs = ClampMs(QuoteStayMs, 7000);
            WanderMaxLines = Math.Clamp(WanderMaxLines, 1, MaxWanderLines);
            WanderBackgroundSeconds = Math.Clamp(WanderBackgroundSeconds, 1, MaxWanderBackgroundSeconds);
            if (QuoteMinMs > QuoteMaxMs)
            {
                int t = QuoteMinMs;
                QuoteMinMs = QuoteMaxMs;
                QuoteMaxMs = t;
            }
        }

        private static int ClampMs(int v, int fallback)
        {
            if (v <= 0) v = fallback;
            if (v < 1000) v = 1000;
            if (v > 60000) v = 60000;
            return v;
        }

        public void Save()
        {
            Clamp();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"schema\": " + Schema + ",");
            sb.AppendLine("  \"app\": \"MemoryArchive\",");
            sb.AppendLine("  \"defaultProfile\": \"" + Esc(DefaultProfile ?? "") + "\",");
            sb.AppendLine("  \"quoteMinMs\": " + QuoteMinMs + ",");
            sb.AppendLine("  \"quoteMaxMs\": " + QuoteMaxMs + ",");
            sb.AppendLine("  \"quoteStayMs\": " + QuoteStayMs + ",");
            sb.AppendLine("  \"wanderMaxLines\": " + WanderMaxLines + ",");
            sb.AppendLine("  \"wanderBackgroundRotation\": " + (WanderBackgroundRotation ? "true" : "false") + ",");
            sb.AppendLine("  \"wanderBackgroundSeconds\": " + WanderBackgroundSeconds);
            sb.AppendLine("}");
            Directory.CreateDirectory(ArchiveLayout.DataRoot);
            File.WriteAllText(FilePath, sb.ToString(), new UTF8Encoding(false));
        }

        private static string Esc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            StringBuilder b = new StringBuilder();
            foreach (char c in s)
            {
                if (c == '"' || c == '\\') b.Append('\\').Append(c);
                else if (c == '\n') b.Append("\\n");
                else if (c == '\r') b.Append("\\r");
                else if (c == '\t') b.Append("\\t");
                else b.Append(c);
            }
            return b.ToString();
        }

        public AppSettings Copy()
        {
            AppSettings s = new AppSettings();
            s.DefaultProfile = DefaultProfile;
            s.QuoteMinMs = QuoteMinMs;
            s.QuoteMaxMs = QuoteMaxMs;
            s.QuoteStayMs = QuoteStayMs;
            s.WanderMaxLines = WanderMaxLines;
            s.WanderBackgroundRotation = WanderBackgroundRotation;
            s.WanderBackgroundSeconds = WanderBackgroundSeconds;
            return s;
        }
    }
}
