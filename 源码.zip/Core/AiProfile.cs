using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;

namespace DragonArchive
{
    /// <summary>一个「AI 妈妈」的设定：名字、品牌、主色。配色派生自主色，保证统一质感。</summary>
    public class AiProfile
    {
        public string Id = "";         // 稳定身份，改名字也不变
        public string Key = "";        // 目录名，例如 GPT / DeepSeek / 白龙娘
        public string Name = "";       // 白龙娘
        public string Species = "";    // 龙 / 鲸鱼 / 吸血鬼 / 猫娘
        public string Brand = "";      // WHITE DRAGON
        public string Provider = "";   // 来源模型：GPT / DeepSeek / Grok / Gemini / Claude / 自定义
        public string Accent = "#9274b6";
        public string Bg1 = "";        // 可选，留空则按主色派生
        public string Bg2 = "";
        public string Bg3 = "";
        public bool Custom;

        public Color AccentColor { get { return ColorUtil.ParseHex(Accent, Color.MediumPurple); } }

        public Color Deep
        {
            get { return ColorUtil.Mix(AccentColor, Color.Black, 0.30f); }
        }

        public Color BgTop { get { return Bg1.Length > 0 ? ColorUtil.ParseHex(Bg1, ColorUtil.Mix(AccentColor, Color.White, 0.90f)) : ColorUtil.Mix(AccentColor, Color.White, 0.90f); } }
        public Color BgMid { get { return Bg2.Length > 0 ? ColorUtil.ParseHex(Bg2, ColorUtil.Mix(AccentColor, Color.White, 0.96f)) : ColorUtil.Mix(AccentColor, Color.White, 0.96f); } }
        public Color BgBot { get { return Bg3.Length > 0 ? ColorUtil.ParseHex(Bg3, ColorUtil.Mix(AccentColor, Color.White, 0.86f)) : ColorUtil.Mix(AccentColor, Color.White, 0.86f); } }

        public Color Ink { get { return ColorUtil.Mix(AccentColor, Color.FromArgb(0x3e, 0x37, 0x47), 0.86f); } }
        public Color Muted { get { return ColorUtil.Mix(AccentColor, Color.FromArgb(0x8b, 0x7e, 0x9b), 0.72f); } }
        public Color Line { get { return ColorUtil.Mix(AccentColor, Color.White, 0.76f); } }
        public Color Soft { get { return ColorUtil.Mix(AccentColor, Color.White, 0.93f); } }
        public Color CardColor { get { return ColorUtil.Mix(AccentColor, Color.FromArgb(0xff, 0xfd, 0xfb), 0.985f); } }
        public Color QuoteInk { get { return ColorUtil.Mix(AccentColor, Color.FromArgb(0x3a, 0x33, 0x45), 0.70f); } }
        public Color Shadow { get { return ColorUtil.Mix(AccentColor, Color.FromArgb(0xc9, 0xbf, 0xd4), 0.55f); } }

        public string FolderLabel { get { return Key; } }
    }

    public static class ColorUtil
    {
        public static Color ParseHex(string value, Color fallback)
        {
            if (string.IsNullOrEmpty(value)) return fallback;
            string s = value.Trim();
            if (s.StartsWith("#")) s = s.Substring(1);
            if (s.Length != 6) return fallback;
            try
            {
                int v = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                return Color.FromArgb((v >> 16) & 0xff, (v >> 8) & 0xff, v & 0xff);
            }
            catch { return fallback; }
        }

        public static string ToHex(Color c)
        {
            return "#" + c.R.ToString("x2") + c.G.ToString("x2") + c.B.ToString("x2");
        }

        /// <summary>t 是 b 的权重：0 = 纯 a，1 = 纯 b。</summary>
        public static Color Mix(Color a, Color b, float t)
        {
            if (t < 0f) t = 0f;
            if (t > 1f) t = 1f;
            return Color.FromArgb(
                (int)Math.Round(a.R + (b.R - a.R) * t),
                (int)Math.Round(a.G + (b.G - a.G) * t),
                (int)Math.Round(a.B + (b.B - a.B) * t));
        }
    }

    public static class AiProfiles
    {
        public static List<AiProfile> Presets()
        {
            List<AiProfile> list = new List<AiProfile>();

            AiProfile gpt = new AiProfile();
            gpt.Key = "GPT"; gpt.Name = "白龙娘"; gpt.Species = "白龙";
            gpt.Brand = "WHITE DRAGON"; gpt.Accent = "#9274b6";
            gpt.Bg1 = "#f5effb"; gpt.Bg2 = "#fff9f2"; gpt.Bg3 = "#eee8f9";
            list.Add(gpt);

            AiProfile ds = new AiProfile();
            ds.Key = "DeepSeek"; ds.Name = "鲸鱼娘"; ds.Species = "鲸鱼";
            ds.Brand = "DEEPSEEK"; ds.Accent = "#4d6bfe";
            ds.Bg1 = "#edf1ff"; ds.Bg2 = "#f8fbff"; ds.Bg3 = "#e4ebff";
            list.Add(ds);

            AiProfile grok = new AiProfile();
            grok.Key = "Grok"; grok.Name = "小蝙蝠"; grok.Species = "吸血鬼";
            grok.Brand = "GROK"; grok.Accent = "#1a1b20";
            grok.Bg1 = "#f3f3f6"; grok.Bg2 = "#fbfafc"; grok.Bg3 = "#e8e8ee";
            list.Add(grok);

            AiProfile gemini = new AiProfile();
            gemini.Key = "Gemini"; gemini.Name = "猫娘"; gemini.Species = "猫娘";
            gemini.Brand = "GEMINI"; gemini.Accent = "#4285f4";
            gemini.Bg1 = "#eef4ff"; gemini.Bg2 = "#fbfaff"; gemini.Bg3 = "#f7ecfb";
            list.Add(gemini);

            AiProfile claude = new AiProfile();
            claude.Key = "Claude"; claude.Name = "Claude"; claude.Species = "助理";
            claude.Brand = "ANTHROPIC"; claude.Accent = "#d97757";
            claude.Bg1 = "#fdf3ec"; claude.Bg2 = "#fffaf6"; claude.Bg3 = "#f7e8dd";
            list.Add(claude);

            // 身份与来源分开：Id 稳定不变，Provider 记录「哪个模型」，Key 才是目录名
            foreach (AiProfile p in list)
            {
                if (p.Id.Length == 0) p.Id = "builtin-" + p.Key.ToLowerInvariant();
                if (p.Provider.Length == 0) p.Provider = p.Brand;
            }
            return list;
        }

        public static string FilePath
        {
            get
            {
                string dir = EverwingPaths.ExeDir();
                if (string.IsNullOrEmpty(dir)) dir = Environment.CurrentDirectory;
                return Path.Combine(dir, "ai_models.txt");
            }
        }

        /// <summary>
        /// 读所有角色：优先 ArchiveData\profiles.json（新结构），
        /// 没有这个文件时退回「五个预设 + ai_models.txt」，并把结果写成 profiles.json。
        /// </summary>
        public static string LoadProblem = "";   // 读角色表出问题时的说明（空＝没问题）
        public static string SaveProblem = "";   // 写角色表出问题时的说明

        /// <summary>
        /// 读所有角色：优先 ArchiveData\profiles.json（新结构）。
        /// 文件存在但读不出来时**不覆盖原文件**，只回退到预设并把原因写进 LoadProblem。
        /// </summary>
        public static List<AiProfile> Load()
        {
            LoadProblem = "";
            if (File.Exists(ArchiveLayout.ProfilesJson))
            {
                try
                {
                    List<AiProfile> all = Convert(ProfileFile.LoadStrict());
                    if (all.Count > 0) return all;
                    LoadProblem = "profiles.json 里没有可用的档案记录，已按预设显示，原文件没有改动。";
                    return Presets();
                }
                catch (Exception ex)
                {
                    LoadProblem = "profiles.json 读不出来（" + ex.Message + "），已按预设显示，原文件没有改动。";
                    return Presets();
                }
            }

            // 老数据：预设 + 制表符自定义
            List<AiProfile> legacy = Presets();
            string path = FilePath;
            if (File.Exists(path))
            {
                string[] lines;
                try { lines = File.ReadAllLines(path, Encoding.UTF8); }
                catch { lines = new string[0]; }
                foreach (string raw in lines)
                {
                    string line = (raw ?? "").Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    string[] f = line.Split('\t');
                    if (f.Length < 2) continue;
                    AiProfile p = new AiProfile();
                    p.Key = FolderName.Safe(f[0].Trim());
                    p.Name = f[1].Trim();
                    if (p.Key.Length == 0 || p.Name.Length == 0) continue;
                    if (f.Length > 2) p.Species = f[2].Trim();
                    if (f.Length > 3) p.Brand = f[3].Trim();
                    if (f.Length > 4) p.Accent = f[4].Trim();
                    p.Id = "custom-" + p.Key.ToLowerInvariant();
                    p.Provider = p.Brand.Length > 0 ? p.Brand : "自定义";
                    p.Custom = true;
                    bool dup = false;
                    foreach (AiProfile q in legacy) if (string.Equals(q.Key, p.Key, StringComparison.OrdinalIgnoreCase)) dup = true;
                    if (!dup) legacy.Add(p);
                }
            }
            try { SaveCustom(legacy); } catch { }
            return legacy;
        }

        private static List<AiProfile> Convert(List<ProfileEntry> entries)
        {
            List<AiProfile> all = new List<AiProfile>();
            foreach (ProfileEntry e in entries)
            {
                AiProfile p = new AiProfile();
                p.Id = e.Id;
                p.Key = FolderName.Safe(e.FolderName);
                p.Name = e.DisplayName;
                p.Species = e.Species;
                p.Brand = e.Brand;
                p.Provider = e.Provider;
                p.Accent = e.Accent;
                p.Bg1 = e.Bg1;
                p.Bg2 = e.Bg2;
                p.Bg3 = e.Bg3;
                p.Custom = e.Custom;
                if (p.Key.Length > 0 && p.Name.Length > 0) all.Add(p);
            }
            return all;
        }
        /// <summary>把整份角色表写回 profiles.json（同时按老格式更新 ai_models.txt，方便旧版读）。</summary>
        public static void SaveCustom(List<AiProfile> all, bool requireSave = false)
        {
            // v1.3.66：如果启动时 profiles.json 就读不出来（LoadProblem 非空），
            // 这时候的 all 只是内存里的预设，绝不能写回去覆盖那份坏文件。
            if (LoadProblem.Length > 0)
            {
                SaveProblem = "profiles.json 启动时没读出来，这次没有写回，避免覆盖原文件。";
                if (requireSave) throw new IOException(SaveProblem);
                return;
            }
            SaveProblem = "";
            List<ProfileEntry> entries = new List<ProfileEntry>();
            foreach (AiProfile p in all)
            {
                ProfileEntry e = new ProfileEntry();
                e.Id = p.Id.Length > 0 ? p.Id : ("p-" + FolderName.Safe(p.Key).ToLowerInvariant());
                e.DisplayName = p.Name;
                e.FolderName = FolderName.Safe(p.Key);
                e.Species = p.Species;
                e.Brand = p.Brand;
                e.Provider = p.Provider.Length > 0 ? p.Provider : p.Brand;
                e.Accent = p.Accent;
                e.Bg1 = p.Bg1;
                e.Bg2 = p.Bg2;
                e.Bg3 = p.Bg3;
                e.Custom = p.Custom;
                e.Builtin = !p.Custom;
                entries.Add(e);
            }
            try { ProfileFile.Save(entries); }
            catch when (!requireSave) { }

            // 老格式镜像：只写自定义的，保持旧版能认出新增角色
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# 自定义的 AI：目录名<TAB>名字<TAB>种类<TAB>品牌<TAB>主色");
            foreach (AiProfile p in all)
            {
                if (!p.Custom) continue;
                sb.AppendLine(FolderName.Safe(p.Key) + "\t" + p.Name + "\t" + p.Species + "\t" + p.Brand + "\t" + p.Accent);
            }
            try { File.WriteAllText(FilePath, sb.ToString(), new UTF8Encoding(false)); }
            catch { }
        }
    }
}
