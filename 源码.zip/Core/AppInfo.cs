namespace DragonArchive
{
    /// <summary>v2.0：版本号集中处（原来挂在 MainForm.AppVersion 上，Core 层不该依赖界面类）。</summary>
    public static class AppInfo
    {
        public const string Version = "2.2.11";
    }
}
