using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace DragonArchive;

internal sealed class BackgroundImage
{
    public string FileName { get; set; } = "";
    public string Label { get; set; } = "";
    public double X { get; set; }
    public double Y { get; set; }
    public double Scale { get; set; } = 1;
    public double Angle { get; set; }
    public double Opacity { get; set; } = 0.35;
    public bool MirrorX { get; set; }
    public bool MirrorY { get; set; }
    internal string? SourcePath { get; set; }

    internal void Normalize()
    {
        X = Range(X, -2, 2, 0);
        Y = Range(Y, -2, 2, 0);
        Scale = Range(Scale, 0.25, 4, 1);
        Angle = Range(Angle, -180, 180, 0);
        Opacity = Range(Opacity, 0, 1, 0.35);
    }

    private static double Range(double value, double min, double max, double fallback) =>
        double.IsFinite(value) ? Math.Clamp(value, min, max) : fallback;
}

internal sealed class BackgroundPool
{
    public List<BackgroundImage> Images { get; set; } = new();
    public bool AutoRotate { get; set; } = true;
    public int IntervalSeconds { get; set; } = 60;
}

internal sealed class BackgroundStore(string key)
{
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true };
    internal const string Folder = "BackgroundImages";
    internal string DirectoryPath { get; } = Path.Combine(ArchiveLayout.ExeDir(), Folder, FolderName.Safe(key));
    private string Manifest => Path.Combine(DirectoryPath, "pool.json");

    internal static bool Supported(string path) => Path.GetExtension(path).ToLowerInvariant() is
        ".png" or ".jpg" or ".jpeg" or ".webp" or ".bmp";

    private static bool OwnedName(string? name) => !string.IsNullOrEmpty(name) &&
        Guid.TryParseExact(Path.GetFileNameWithoutExtension(name), "N", out _) &&
        string.Equals(Path.GetFileName(name), name, StringComparison.Ordinal) && Supported(name);

    internal string PathFor(BackgroundImage image) => image.SourcePath ?? Path.Combine(DirectoryPath, image.FileName);

    internal BackgroundPool Load()
    {
        if (!File.Exists(Manifest)) return new();
        return Parse(File.ReadAllText(Manifest));
    }

    internal static BackgroundPool Parse(string text)
    {
        BackgroundPool pool = JsonSerializer.Deserialize<BackgroundPool>(text, Json)
            ?? throw new InvalidDataException("背景图片池内容为空。");
        pool.Images = (pool.Images ?? new()).Where(image => image != null && OwnedName(image.FileName))
            .DistinctBy(image => image.FileName, StringComparer.OrdinalIgnoreCase).ToList();
        foreach (BackgroundImage image in pool.Images) image.Normalize();
        pool.IntervalSeconds = Math.Clamp(pool.IntervalSeconds, 1, 86400);
        return pool;
    }

    internal static string Serialize(BackgroundPool pool) => JsonSerializer.Serialize(pool, Json);

    internal void Save(BackgroundPool pool)
    {
        BackgroundPool previous = Load();
        if (pool.Images.Count == 0 && !File.Exists(Manifest)) return;
        bool hadDirectory = Directory.Exists(DirectoryPath);
        string root = Path.GetDirectoryName(DirectoryPath)!;
        bool hadRoot = Directory.Exists(root);
        string temporary = Path.Combine(DirectoryPath, $".{Guid.NewGuid():N}.tmp");
        List<string> copied = new();
        try
        {
            Directory.CreateDirectory(DirectoryPath);
            foreach (BackgroundImage image in pool.Images.Where(image => image.SourcePath != null))
            {
                string destination = Path.Combine(DirectoryPath, image.FileName);
                using var source = File.OpenRead(image.SourcePath!);
                using var target = new FileStream(destination, FileMode.CreateNew, FileAccess.Write);
                copied.Add(destination);
                source.CopyTo(target);
            }
            File.WriteAllText(temporary, Serialize(pool));
            File.Move(temporary, Manifest, overwrite: true);
        }
        catch
        {
            foreach (string file in copied) TryDelete(file);
            TryDelete(temporary);
            if (!hadDirectory) TryRemoveEmpty(DirectoryPath);
            if (!hadRoot) TryRemoveEmpty(root);
            throw;
        }
        var retained = pool.Images.Select(image => image.FileName).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (BackgroundImage image in previous.Images)
            if (!retained.Contains(image.FileName)) TryDelete(PathFor(image));
    }

    private static void TryDelete(string path)
    {
        try { File.Delete(path); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private static void TryRemoveEmpty(string path)
    {
        try { Directory.Delete(path); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }
}
