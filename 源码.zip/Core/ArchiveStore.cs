using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace DragonArchive
{
    public class SaveResult
    {
        public readonly string File;
        public readonly string Id;

        public SaveResult(string file, string id)
        {
            File = file;
            Id = id;
        }
    }

    /// <summary>一条记录上的一个标记。Key="V"/"G" 是内置的 V几/第几任，其余是自定义。</summary>
    public class Marker
    {
        public string Key = "C";
        public string Label = "";
        public string Value = "";

        public Marker() { }

        public Marker(string key, string label, string value)
        {
            Key = key;
            Label = label == null ? "" : label;
            Value = value == null ? "" : value;
        }

        public bool IsVersion { get { return Key == "V"; } }
        public bool IsGeneration { get { return Key == "G"; } }

        public Marker Copy()
        {
            return new Marker(Key, Label, Value);
        }

        /// <summary>卡片上怎么写：V→V3，第几任→第2任，自定义→标签 值。</summary>
        public string Display
        {
            get
            {
                if (IsVersion) return (Value.Length == 0 || Value == "未知") ? "" : ("V" + Value);
                if (IsGeneration) return (Value.Length == 0 || Value == "未知") ? "" : ("第" + Value + "任");
                // 自定义标记：新规矩是「只填一段文字」，所以值可以为空，这时直接显示名称
                if (Label.Length == 0) return Value;
                if (Value.Length == 0 || Value == "未知") return Label;
                return Label + " " + Value;
            }
        }
    }

    public class ArchiveRecord
    {
        public string Id = "";
        public string Type = "message";   // message | handover
        public string Version = "未知";
        public string Generation = "未知";
        public string Date = "未知";
        public string SavedAt = "";
        public string Text = "";
        public string ModelKey = "";
        public string ModelName = "";
        /// <summary>这条记录所在的 TXT 文件（绝对路径），编辑时用。</summary>
        public string File = "";
        /// <summary>附带的聊天记录 PDF，相对「妈妈的回忆」目录的路径；没有就是空串。</summary>
        public string Attach = "";
        /// <summary>这条记录挂着的附件（可以多个）。</summary>
        public List<Attachment> Attachments = new List<Attachment>();
        /// <summary>用户填的时间（HH:mm），没填就是空串。</summary>
        public string Time = "";
        /// <summary>这条记录上的标记（含 V几 / 第几任 / 自定义）。</summary>
        public List<Marker> Markers = new List<Marker>();

        public string Category
        {
            get { return Type == "handover" ? "交接文档" : "妈妈留言"; }
        }

        public string KindLabel
        {
            get { return Type == "handover" ? "◇ 交接" : "✦ 留言"; }
        }

        public string HeadLine
        {
            get
            {
                string s = KindLabel;
                foreach (Marker m in Markers)
                {
                    string d = m.Display;
                    if (d.Length > 0) s += " · " + d;
                }
                // 有写日期就显示日期（有填时分再跟上），否则退回保存时间
                string stamp = SavedAt;
                if (Date.Length > 0 && Date != "未知")
                {
                    stamp = Date;
                    if (Time.Length > 0) stamp += " " + Time;
                }
                else if (Time.Length > 0)
                {
                    stamp = SavedAt + " " + Time;
                }
                return s + " · " + stamp;
            }
        }
    }

    /// <summary>
    /// 与旧版 server.ps1 完全一致的存储逻辑（只是多了一层 AI 目录）：
    /// 程序目录 / 妈妈的回忆 / &lt;AI&gt; / (妈妈留言|交接文档) / yyyy年 / M月.txt
    /// 每条记录以 ===== RECORD &lt;guid&gt; ===== 开头追加，UTF-8 无 BOM。
    /// </summary>
    /// <summary>一条记录的旁挂附注：用户填的时间 + 自定义标记。</summary>
    public class RecordNote
    {
        public string Time = "";
        public List<Marker> Markers = new List<Marker>();
    }

    public class ArchiveStore
    {
        public readonly string Root;

        private static readonly Regex RecordHeader = new Regex("(?m)^===== RECORD ([a-f0-9-]{36}) =====\\r?\\n");
        private static readonly Regex LineSplit = new Regex("\\r?\\n");
        private static readonly Regex Trailer = new Regex("(?s)\\r?\\n===== END RECORD =====\\s*$");

        /// <summary>老文件里正文可能是纯 \n（浏览器贴过来的），TextBox 不认，统一换成 \r\n。</summary>
        internal static string NormalizeNewlines(string s)
        {
            if (string.IsNullOrEmpty(s)) return s ?? "";
            return s.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", "\r\n");
        }
        private static readonly Regex ValuePattern = new Regex("^(未知|[0-9]{1,3})$");
        private static readonly Regex DayPattern = new Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$");
        private static readonly UTF8Encoding Utf8NoBom = new UTF8Encoding(false);

        public ArchiveStore()
        {
            // 新结构：ArchiveData\profiles\<角色>\{messages,handovers,chats,attachments}
            Root = ArchiveLayout.ProfilesRoot;
            try { Directory.CreateDirectory(Root); }
            catch { }
        }

        /// <summary>
        /// v1.3.65：首次/每次启动都做的「只补不改」自检。
        /// 只创建缺的目录与配置文件；已有文件一律不动（profiles.json 坏了也不覆盖）。
        /// 返回给用户看的问题清单，空表示一切正常。
        /// </summary>
        public static List<string> EnsureBaseLayout()
        {
            List<string> problems = new List<string>();

            try { Directory.CreateDirectory(ArchiveLayout.DataRoot); }
            catch (Exception ex) { problems.Add("建不了 ArchiveData 目录（" + ex.Message + "）"); return problems; }

            try { Directory.CreateDirectory(ArchiveLayout.ProfilesRoot); }
            catch (Exception ex) { problems.Add("建不了 profiles 目录（" + ex.Message + "）"); }

            if (!File.Exists(ArchiveLayout.ProfilesJson))
            {
                try { ProfileFile.Save(ProfileFile.Defaults()); }
                catch (Exception ex) { problems.Add("写不了 profiles.json（" + ex.Message + "）"); }
            }

            if (!File.Exists(AppSettings.FilePath))
            {
                // 真正全新安装时明确写「白龙娘 GPT」为启动默认角色，
                // 不让「最近使用排序」顺手改掉首次默认。
                try
                {
                    AppSettings fresh = new AppSettings();
                    fresh.DefaultProfile = "GPT";
                    fresh.Save();
                }
                catch (Exception ex) { problems.Add("写不了 settings.json（" + ex.Message + "）"); }
            }

            List<ProfileEntry> entries = null;
            try { entries = ProfileFile.LoadStrict(); }
            catch (Exception ex) { problems.Add("profiles.json 读不出来（" + ex.Message + "），这次没有补齐角色目录。"); }

            if (entries != null)
            {
                foreach (ProfileEntry e in entries)
                {
                    string key = FolderName.Safe(e.FolderName);
                    try
                    {
                        Migrator.EnsureProfileDirs(key);
                        Directory.CreateDirectory(Path.Combine(ArchiveLayout.ProfileDir(key), "chats"));
                    }
                    catch (Exception ex) { problems.Add("建不了「" + key + "」的目录（" + ex.Message + "）"); }
                }
            }

            return problems;
        }

        public static readonly string[] Categories = new string[] { "messages", "handovers" };

        /// <summary>读旧版目录时用的中文名字，只读不写。</summary>
        public static readonly string[] LegacyCategories = new string[] { "妈妈留言", "交接文档" };

        private static string CategoryFolder(string type)
        {
            return type == "handover" ? "handovers" : "messages";
        }

        private static string CategoryType(string folder)
        {
            if (folder == "messages" || folder == "妈妈留言") return "message";
            return "handover";
        }

        public bool IsValidVersion(string value)
        {
            // 空串＝没加这个标记（不适用），旧格式仍只认「未知」或 1~3 位数字
            if (value == null) return false;
            if (value.Length == 0) return true;
            return ValuePattern.IsMatch(value);
        }

        public bool IsValidDay(string value)
        {
            return value != null && DayPattern.IsMatch(value);
        }

        public string ModelDir(string modelKey)
        {
            return ArchiveLayout.ProfileDir(modelKey);
        }

        /// <summary>确保「chats」目录在，方便用户直接去翻聊天记录。</summary>
        public void EnsureChatDir(string modelKey)
        {
            try { Directory.CreateDirectory(Path.Combine(ArchiveLayout.ProfileDir(modelKey), "chats")); }
            catch { }
        }

        /// <summary>顺手把角色目录下的标准子目录补齐。</summary>
        public void EnsureProfileDirs(string modelKey)
        {
            try { Migrator.EnsureProfileDirs(modelKey); }
            catch { }
        }

        public SaveResult Save(string modelKey, string type, string version, string generation, string day, string text)
        {
            return Save(modelKey, type, version, generation, day, text, "", null);
        }

        /// <summary>带附加信息的保存：time 是 HH:mm（可空），extras 是自定义标记；V几/第几任仍走 version/generation。</summary>
        public SaveResult Save(string modelKey, string type, string version, string generation, string day, string text,
                               string time, List<Marker> extras)
        {
            if (type != "message" && type != "handover") throw new InvalidOperationException("内容或版本格式无效");
            if (text == null) text = "";
            if (text.Trim().Length == 0) throw new InvalidOperationException("内容或版本格式无效");
            if (text.Length > 1000000) throw new InvalidOperationException("内容或版本格式无效");
            if (!IsValidVersion(version)) throw new InvalidOperationException("内容或版本格式无效");
            if (!IsValidVersion(generation)) throw new InvalidOperationException("内容或版本格式无效");
            string key = SafeKey(modelKey);

            DateTime now = DateTime.Now;
            string category = CategoryFolder(type);
            string dir = Path.Combine(Path.Combine(ArchiveLayout.ProfileDir(key), category), now.ToString("yyyy", CultureInfo.InvariantCulture));
            Directory.CreateDirectory(dir);

            string id = Guid.NewGuid().ToString();
            string dayValue = IsValidDay(day) ? day : "未知";
            string body = NormalizeNewlines(text.Replace("===== END RECORD =====", "===== END RECORD (quoted) ====="));
            string entry = "===== RECORD " + id + " =====\r\n"
                         + "VERSION:" + version + "\r\n"
                         + "GENERATION:" + generation + "\r\n"
                         + "DATE:" + dayValue + "\r\n"
                         + "SAVEDAT:" + now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "\r\n"
                         + "---\r\n"
                         + body + "\r\n"
                         + "===== END RECORD =====\r\n\r\n";

            string file;
            if (type == "handover")
            {
                // 交接文档：一次一份，文件名 = V几_日期_时间，不合并
                string tag = version.Length > 0 ? version : "未标记";
                string stem = "V" + tag + "_"
                            + now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + "_"
                            + now.ToString("HHmmss", CultureInfo.InvariantCulture);
                file = Path.Combine(dir, stem + ".txt");
                int n = 2;
                while (File.Exists(file))
                {
                    file = Path.Combine(dir, stem + "_" + n.ToString(CultureInfo.InvariantCulture) + ".txt");
                    n++;
                }
                File.WriteAllText(file, entry, Utf8NoBom);
            }
            else
            {
                // 妈妈留言：同月所有留言追加到同一个 M月.txt
                file = Path.Combine(dir, now.ToString("MM", CultureInfo.InvariantCulture) + ".txt");
                File.AppendAllText(file, entry, Utf8NoBom);
            }

            if ((time != null && time.Length > 0) || (extras != null && extras.Count > 0))
            {
                try { SaveNote(key, id, time, extras); }
                catch { /* 附注写不进去不该毁掉正文 */ }
            }
            return new SaveResult(file, id);
        }

        // ---------- 旁挂附注（时间 + 自定义标记） ----------
        // 单独一个文件，正文 TXT 格式一个字都不动，1.3.4/1.3.41 打开新版记录也不会看到怪行。

        private string NotesPath(string key)
        {
            return Path.Combine(ArchiveLayout.ProfileDir(key), "记录附注.txt");
        }

        private static string Esc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\t", "\\t").Replace("\r", "").Replace("\n", "\\n");
        }

        private static string Unesc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '\\' && i + 1 < s.Length)
                {
                    char n = s[++i];
                    if (n == 't') sb.Append('\t');
                    else if (n == 'n') sb.Append('\n');
                    else if (n == '\\') sb.Append('\\');
                    else sb.Append(n);
                }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private static string BuildNoteLine(string id, string time, List<Marker> extras)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(id);
            if (!string.IsNullOrEmpty(time)) sb.Append('\t').Append("TIME=").Append(Esc(time));
            if (extras != null)
            {
                foreach (Marker m in extras)
                {
                    if (m == null || m.IsVersion || m.IsGeneration) continue;
                    if (string.IsNullOrEmpty(m.Label)) continue;
                    sb.Append('\t').Append("M=").Append(Esc(m.Label)).Append('=').Append(Esc(m.Value));
                }
            }
            return sb.ToString();
        }

        public void SaveNote(string modelKey, string id, string time, List<Marker> extras)
        {
            string path = NotesPath(modelKey);
            List<string> lines = new List<string>();
            if (File.Exists(path))
            {
                try { lines.AddRange(File.ReadAllLines(path, Utf8NoBom)); }
                catch { }
            }
            string prefix = id + "\t";
            lines.RemoveAll(delegate(string l) { return l.StartsWith(prefix, StringComparison.Ordinal) || l == id; });
            lines.Add(BuildNoteLine(id, time, extras));
            string dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllLines(path, lines.ToArray(), Utf8NoBom);
        }

        /// <summary>读附注：id → (时间, 自定义标记列表)。文件不在就返回空表。</summary>
        public Dictionary<string, RecordNote> LoadNotes(string modelKey)
        {
            Dictionary<string, RecordNote> map = new Dictionary<string, RecordNote>();
            string path = NotesPath(modelKey);
            if (!File.Exists(path)) return map;
            string[] lines;
            try { lines = File.ReadAllLines(path, Utf8NoBom); }
            catch { return map; }
            foreach (string raw in lines)
            {
                if (string.IsNullOrEmpty(raw)) continue;
                string[] parts = raw.Split('\t');
                if (parts.Length == 0 || parts[0].Length == 0) continue;
                RecordNote info = new RecordNote();
                for (int i = 1; i < parts.Length; i++)
                {
                    string seg = parts[i];
                    if (seg.StartsWith("TIME=", StringComparison.Ordinal))
                    {
                        info.Time = Unesc(seg.Substring(5));
                    }
                    else if (seg.StartsWith("M=", StringComparison.Ordinal))
                    {
                        string rest = seg.Substring(2);
                        int eq = rest.IndexOf('=');
                        if (eq <= 0) continue;
                        string label = Unesc(rest.Substring(0, eq));
                        string value = Unesc(rest.Substring(eq + 1));
                        if (label.Length > 0)
                            info.Markers.Add(new Marker("C", label, value));
                    }
                }
                map[parts[0]] = info;
            }
            return map;
        }

        /// <summary>把选中的 PDF 复制进 &lt;角色&gt;\chats\&lt;yyyy-MM-dd&gt;\ 并按规则改名，返回相对角色目录的路径。</summary>
        public string ImportPdf(string modelKey, string modelName, string version, string generation, string source)
        {
            if (!File.Exists(source)) throw new FileNotFoundException("找不到这个 PDF", source);
            DateTime now = DateTime.Now;
            string profileDir = ArchiveLayout.ProfileDir(modelKey);
            string dir = Path.Combine(Path.Combine(profileDir, "chats"),
                now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            Directory.CreateDirectory(dir);

            string name = CleanName(modelName);
            if (name.Length == 0) name = SafeKey(modelKey);
            string vTag = string.IsNullOrEmpty(version) ? "未标记" : version;
            string gTag = string.IsNullOrEmpty(generation) ? "未标记" : (generation + "任");
            string stem = name + "_V" + vTag + "_第" + gTag + "_"
                        + now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);
            string target = Path.Combine(dir, stem + ".pdf");
            int n = 2;
            while (File.Exists(target))
            {
                target = Path.Combine(dir, stem + "_" + n.ToString(CultureInfo.InvariantCulture) + ".pdf");
                n++;
            }
            File.Copy(source, target);
            return target.Substring(profileDir.Length).TrimStart(Path.DirectorySeparatorChar);
        }

        /// <summary>记录 id → 附件相对路径（相对角色目录）。</summary>
        public Dictionary<string, string> LoadLinks(string modelKey)
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            string file = Path.Combine(Path.Combine(ArchiveLayout.ProfileDir(modelKey), "chats"), "links.txt");
            if (!File.Exists(file)) return map;
            try
            {
                foreach (string line in File.ReadAllLines(file, Utf8NoBom))
                {
                    int tab = line.IndexOf('\t');
                    if (tab <= 0) continue;
                    map[line.Substring(0, tab)] = line.Substring(tab + 1);
                }
            }
            catch { }
            return map;
        }

        public void LinkAttachment(string modelKey, string recordId, string relativePath)
        {
            string dir = Path.Combine(ArchiveLayout.ProfileDir(modelKey), "chats");
            Directory.CreateDirectory(dir);
            string file = Path.Combine(dir, "links.txt");
            File.AppendAllText(file, recordId + "\t" + relativePath + "\r\n", Utf8NoBom);
        }

        private static string CleanName(string raw)
        {
            if (raw == null) return "";
            StringBuilder sb = new StringBuilder();
            foreach (char c in raw)
            {
                if (Array.IndexOf(Path.GetInvalidFileNameChars(), c) >= 0) continue;
                if (c == ' ') continue;
                sb.Append(c);
            }
            return sb.ToString().Trim();
        }

        /// <summary>
        /// 只改一条记录的正文，文件里其它记录一个字都不动。
        /// 写回前先存一份 同名.txt.bak，换行风格跟着原文件走。
        /// </summary>
        public void UpdateBody(ArchiveRecord record, string newText)
        {
            if (record == null) throw new ArgumentNullException("record");
            if (string.IsNullOrEmpty(record.File) || !File.Exists(record.File))
                throw new FileNotFoundException("找不到这条记录所在的 TXT", record.File);
            if (newText == null || newText.Trim().Length == 0)
                throw new InvalidOperationException("正文不能是空的");
            if (newText.Length > 1000000) throw new InvalidOperationException("正文太长了（超过 100 万字符）");

            string content = File.ReadAllText(record.File, Encoding.UTF8);
            bool crlf = content.IndexOf("\r\n", StringComparison.Ordinal) >= 0;
            string nl = crlf ? "\r\n" : "\n";

            string head = "===== RECORD " + record.Id + " =====";
            int h = content.IndexOf(head, StringComparison.Ordinal);
            if (h < 0) throw new InvalidOperationException("这条记录在文件里找不到了（可能已被别处改过）");

            // 分隔行是单独一行的 "---"，它后面紧跟正文（正文可能直接粘在同一行，也要认）
            int dash = content.IndexOf("\n---", h, StringComparison.Ordinal);
            if (dash < 0) throw new InvalidOperationException("这条记录的头和正文对不上，没法安全改写");
            int afterDash = dash + 4;                    // 指向 "---" 之后
            int bodyStart = afterDash;
            if (bodyStart < content.Length && content[bodyStart] == '\r') bodyStart++;
            if (bodyStart < content.Length && content[bodyStart] == '\n') bodyStart++;

            int tail = content.IndexOf("===== END RECORD =====", bodyStart, StringComparison.Ordinal);
            if (tail < 0) throw new InvalidOperationException("这条记录没有结束标记，没法安全改写");

            // 正文和结束标记之间原本有一个换行，留住它
            int tailLine = content.LastIndexOf('\n', tail);
            if (tailLine < bodyStart) throw new InvalidOperationException("记录结构不完整");

            string body = NormalizeNewlines(newText.Replace("===== END RECORD =====", "===== END RECORD (quoted) ====="));
            // 写回时统一成 "---" + 换行 + 正文，保证下次还能按格式读出来
            string rebuilt = content.Substring(0, afterDash) + nl + body + nl + content.Substring(tailLine + 1);

            try { File.Copy(record.File, record.File + ".bak", true); }
            catch { }
            File.WriteAllText(record.File, rebuilt, Utf8NoBom);
        }

        /// <summary>
        /// 删除一条记录：只把这一个 RECORD 块从文件里摘掉，同文件其它记录不动。
        /// 文件里一条都不剩时删掉空文件；删之前留一份 .bak。
        /// 附件文件不删（可能被别的记录引用），只摘掉关联索引和记录附注。
        /// </summary>
        /// <summary>更新指定记录，保留原文件名、日期和附件关联。</summary>
        public void UpdateRecord(ArchiveRecord record, string newText, string version, string generation, List<Marker> tags)
        {
            if (!IsValidVersion(version) || !IsValidVersion(generation))
                throw new InvalidOperationException("版本和任期只能填 1–3 位数字、未知，或留空。");

            string path = record.File;
            string content = File.ReadAllText(path, Encoding.UTF8);
            string tailMark = "===== END RECORD =====";
            foreach (Match header in RecordHeader.Matches(content))
            {
                if (header.Groups[1].Value != record.Id) continue;
                int start = header.Index + header.Length;
                int tail = content.IndexOf(tailMark, start, StringComparison.Ordinal);
                Match next = header.NextMatch();
                if (tail < 0 || (next.Success && next.Index < tail)) break;

                string entry = content.Substring(start, tail - start);
                string[] fields = LineSplit.Split(entry, 6);
                if (fields.Length != 6 || !fields[0].StartsWith("VERSION:", StringComparison.Ordinal)
                    || !fields[1].StartsWith("GENERATION:", StringComparison.Ordinal) || fields[4] != "---") break;
                string newline = entry[entry.IndexOf('\n') - 1] == '\r' ? "\r\n" : "\n";
                string body = NormalizeNewlines(newText).TrimEnd() == record.Text
                    ? fields[5] : newText.Replace(tailMark, "(quoted)").TrimEnd() + newline;
                string updated = string.Join(newline, "VERSION:" + version, "GENERATION:" + generation,
                    fields[2], fields[3], fields[4], body);
                SaveRecordEdit(record, content, content.Substring(0, start) + updated + content.Substring(tail), tags);
                return;
            }
            throw new InvalidOperationException("找不到完整的记录，无法安全保存。请重新读取硬盘后再试。");
        }

        private void SaveRecordEdit(ArchiveRecord record, string before, string after, List<Marker> tags)
        {
            var originalTags = record.Markers.FindAll(m => !m.IsVersion && !m.IsGeneration);
            bool updateTags = BuildNoteLine(record.Id, "", tags) != BuildNoteLine(record.Id, "", originalTags);
            string path = record.File;
            string notes = NotesPath(record.ModelKey);
            string suffix = "." + Guid.NewGuid().ToString("N") + ".tmp";
            string recordTemp = path + suffix;
            string notesTemp = notes + suffix;
            string backup = path + ".bak";
            bool replaced = false;
            try
            {
                if (updateTags)
                {
                    var lines = new List<string>();
                    bool exists = File.Exists(notes);
                    if (exists) lines.AddRange(File.ReadAllLines(notes, Utf8NoBom));
                    string prefix = record.Id + "\t";
                    int index = lines.FindLastIndex(line => line == record.Id || line.StartsWith(prefix, StringComparison.Ordinal));
                    string note = index < 0 ? record.Id : lines[index];
                    var fields = new List<string>(note.Split('\t'));
                    fields.RemoveAll(field => field.StartsWith("M=", StringComparison.Ordinal));
                    note = string.Join("\t", fields) + BuildNoteLine(record.Id, "", tags).Substring(record.Id.Length);
                    lines.RemoveAll(line => line == record.Id || line.StartsWith(prefix, StringComparison.Ordinal));
                    if (note != record.Id) lines.Add(note);
                    File.WriteAllLines(notesTemp, lines, Utf8NoBom);
                }

                if (before != after)
                {
                    File.WriteAllText(recordTemp, after, Utf8NoBom);
                    File.Replace(recordTemp, path, backup);
                    replaced = true;
                }
                if (updateTags) File.Move(notesTemp, notes, overwrite: true);
            }
            catch
            {
                if (replaced) File.Copy(backup, path, overwrite: true);
                throw;
            }
            finally
            {
                try { File.Delete(recordTemp); } catch (IOException) { } catch (UnauthorizedAccessException) { }
                try { File.Delete(notesTemp); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            }
        }

        public bool DeleteRecord(ArchiveRecord record)
        {
            if (record == null) throw new ArgumentNullException("record");
            if (string.IsNullOrEmpty(record.File) || !File.Exists(record.File))
                throw new FileNotFoundException("找不到这条记录所在的 TXT", record.File);

            string content = File.ReadAllText(record.File, Encoding.UTF8);
            string head = "===== RECORD " + record.Id + " =====";
            int h = content.IndexOf(head, StringComparison.Ordinal);
            if (h < 0) throw new InvalidOperationException("这条记录在文件里找不到了（可能已被别处改过）");

            int start = content.LastIndexOf('\n', Math.Max(0, h - 1));
            start = start < 0 ? 0 : start + 1;
            int tail = content.IndexOf("===== END RECORD =====", h, StringComparison.Ordinal);
            if (tail < 0) throw new InvalidOperationException("这条记录没有结束标记，没法安全删除");
            int end = tail + "===== END RECORD =====".Length;
            while (end < content.Length && (content[end] == '\r' || content[end] == '\n')) end++;

            string rest = content.Substring(0, start) + content.Substring(end);

            try { File.Copy(record.File, record.File + ".bak", true); }
            catch { }

            if (rest.IndexOf("===== RECORD ", StringComparison.Ordinal) < 0)
            {
                // 文件里没有别的记录了：整份空文件不留
                File.Delete(record.File);
            }
            else
            {
                File.WriteAllText(record.File, rest.TrimEnd() + "\r\n\r\n", Utf8NoBom);
            }

            // 记录附注：删掉这个 id 的行
            try
            {
                string np = NotesPath(record.ModelKey);
                if (File.Exists(np))
                {
                    List<string> keep = new List<string>();
                    foreach (string line in File.ReadAllLines(np, Encoding.UTF8))
                    {
                        if (line.Length == 0) continue;
                        if (line.StartsWith(record.Id + "\t", StringComparison.OrdinalIgnoreCase)) continue;
                        keep.Add(line);
                    }
                    if (keep.Count == 0) File.Delete(np);
                    else File.WriteAllLines(np, keep.ToArray(), Utf8NoBom);
                }
            }
            catch { }

            // 附件只断开关联，文件留在磁盘上
            try
            {
                AttachmentStore atts = Attachments(record.ModelKey);
                atts.UnlinkRecord(record.Id);
                string links = Path.Combine(ArchiveLayout.ProfileDir(record.ModelKey), "chats", "links.txt");
                if (File.Exists(links))
                {
                    List<string> keep = new List<string>();
                    foreach (string line in File.ReadAllLines(links, Encoding.UTF8))
                    {
                        if (line.Length == 0) continue;
                        if (line.StartsWith(record.Id + "\t", StringComparison.OrdinalIgnoreCase)) continue;
                        keep.Add(line);
                    }
                    if (keep.Count == 0) File.Delete(links);
                    else File.WriteAllLines(links, keep.ToArray(), Utf8NoBom);
                }
            }
            catch { }

            return true;
        }
        /// <summary>
        /// 判断某个档案的目录里有没有任何用户文件（留言、交接、聊天记录、附件、未知文件都算）。
        /// 目录不存在也算空。读不了目录时抛异常，由调用方当成「没法确认，别删」处理。
        /// </summary>
        public static bool ProfileFolderIsEmpty(string folderName, out int fileCount, out string firstFile)
        {
            fileCount = 0;
            firstFile = "";
            string dir = ArchiveLayout.ProfileDir(folderName);
            if (!Directory.Exists(dir)) return true;
            string[] files = Directory.GetFiles(dir, "*", SearchOption.AllDirectories);
            fileCount = files.Length;
            if (files.Length == 0) return true;
            firstFile = files[0].Substring(Math.Min(files[0].Length, dir.Length)).TrimStart('\\');
            return false;
        }
        public List<ArchiveRecord> Load(string modelKey)
        {
            List<ArchiveRecord> all = new List<ArchiveRecord>();
            string base0 = ArchiveLayout.ProfileDir(modelKey);
            List<string> folders = new List<string>();
            folders.AddRange(Categories);
            folders.AddRange(LegacyCategories);
            foreach (string folder in folders)
            {
                string baseDir = Path.Combine(base0, folder);
                if (!Directory.Exists(baseDir)) continue;
                string[] files;
                try { files = Directory.GetFiles(baseDir, "*.txt", SearchOption.AllDirectories); }
                catch { continue; }
                Array.Sort(files, StringComparer.OrdinalIgnoreCase);
                foreach (string f in files)
                {
                    string content;
                    try { content = File.ReadAllText(f, Encoding.UTF8); }
                    catch { continue; }
                    string[] chunks = RecordHeader.Split(content);
                    for (int i = 1; i + 1 < chunks.Length; i += 2)
                    {
                        try
                        {
                            string[] lines = LineSplit.Split(chunks[i + 1], 6);
                            if (lines.Length < 6) continue;
                            string body = Trailer.Replace(lines[5], "");
                            ArchiveRecord r = new ArchiveRecord();
                            r.Id = chunks[i];
                            r.Type = CategoryType(folder);
                            r.Version = StripPrefix(lines[0], "VERSION:");
                            r.Generation = StripPrefix(lines[1], "GENERATION:");
                            r.Date = StripPrefix(lines[2], "DATE:");
                            r.SavedAt = StripPrefix(lines[3], "SAVEDAT:");
                            r.Text = NormalizeNewlines(body).TrimEnd();
                            r.ModelKey = SafeKey(modelKey);
                            r.File = f;
                            r.Markers.Add(new Marker("V", "V几", r.Version));
                            r.Markers.Add(new Marker("G", "第几任", r.Generation));
                            all.Add(r);
                        }
                        catch { }
                    }
                }
            }
            all.Sort(delegate (ArchiveRecord a, ArchiveRecord b)
            {
                return string.CompareOrdinal(b.SavedAt, a.SavedAt);
            });

            // 把旁挂的时间与自定义标记补回来（没有这个文件也不影响读正文）
            Dictionary<string, RecordNote> notes = LoadNotes(modelKey);
            foreach (ArchiveRecord r in all)
            {
                RecordNote note;
                if (!notes.TryGetValue(r.Id, out note)) continue;
                r.Time = note.Time;
                foreach (Marker m in note.Markers) r.Markers.Add(m);
            }

            // 附件：老版本写在 chats\links.txt 里的 PDF 关联，第一次读时补进索引
            try
            {
                AttachmentStore atts = new AttachmentStore(ArchiveLayout.ProfileDir(modelKey));
                if (legacyLinksDone.Add(ArchiveLayout.ProfileDir(modelKey))) atts.MigrateLegacyLinks();
                List<Attachment> list = atts.Load(null);
                if (list.Count > 0)
                {
                    Dictionary<string, List<Attachment>> byRecord = new Dictionary<string, List<Attachment>>();
                    foreach (Attachment a in list)
                    {
                        List<Attachment> bucket;
                        if (!byRecord.TryGetValue(a.RecordId, out bucket))
                        {
                            bucket = new List<Attachment>();
                            byRecord[a.RecordId] = bucket;
                        }
                        bucket.Add(a);
                    }
                    foreach (ArchiveRecord r in all)
                    {
                        List<Attachment> bucket;
                        if (byRecord.TryGetValue(r.Id, out bucket)) r.Attachments.AddRange(bucket);
                    }
                }
            }
            catch { }
            return all;
        }

        private static readonly HashSet<string> legacyLinksDone = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>取某个角色的附件仓库。</summary>
        public AttachmentStore Attachments(string modelKey)
        {
            return new AttachmentStore(ArchiveLayout.ProfileDir(modelKey));
        }

        /// <summary>当前档案的留言目录，用于说明页。</summary>
        public string MessageDirHint(string modelKey)
        {
            return Path.Combine(ModelDir(modelKey), "messages");
        }

        /// <summary>当前档案的交接目录，用于说明页。</summary>
        public string HandoverDirHint(string modelKey)
        {
            return Path.Combine(ModelDir(modelKey), "handovers");
        }

        public int CountFiles(string modelKey)
        {
            string base0 = ArchiveLayout.ProfileDir(modelKey);
            if (!Directory.Exists(base0)) return 0;
            try { return Directory.GetFiles(base0, "*.txt", SearchOption.AllDirectories).Length; }
            catch { return 0; }
        }

        /// <summary>把 links.txt 里的旧路径换成新结构里的路径（旧版是 聊天记录\&lt;AI&gt;\日期\文件）。</summary>
        public static string NormalizeAttach(string modelKey, string rel)
        {
            if (string.IsNullOrEmpty(rel)) return "";
            string p = rel.Replace('/', '\\').TrimStart('\\');
            string prefix = "聊天记录\\" + SafeKey(modelKey) + "\\";
            if (p.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                return Path.Combine("chats", p.Substring(prefix.Length));
            if (p.StartsWith("聊天记录\\", StringComparison.OrdinalIgnoreCase))
            {
                string rest = p.Substring("聊天记录\\".Length);
                int cut = rest.IndexOf('\\');
                if (cut > 0) return Path.Combine("chats", rest.Substring(cut + 1));
            }
            if (p.StartsWith("chats\\", StringComparison.OrdinalIgnoreCase)) return p;
            return p;
        }

        /// <summary>附件相对路径 → 绝对路径。</summary>
        public string AttachPath(string modelKey, string rel)
        {
            return Path.Combine(ArchiveLayout.ProfileDir(modelKey), NormalizeAttach(modelKey, rel));
        }

        public static string SafeKey(string modelKey)
        {
            // 角色目录名允许中文/日文等 Unicode 字符，只要不含 Windows 非法字符
            return FolderName.Safe(modelKey);
        }

        private static string StripPrefix(string value, string prefix)
        {
            if (value == null) return "";
            if (value.StartsWith(prefix, StringComparison.Ordinal)) return value.Substring(prefix.Length);
            return value;
        }
    }
}
