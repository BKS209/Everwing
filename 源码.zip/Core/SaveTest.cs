using System;
using System.IO;
using System.Text;

namespace DragonArchive
{
    /// <summary>P2 校对用：往副本里真写一条留言，确认 Avalonia 侧保存链路与 WinForms 版一致。</summary>
    internal static class SaveTest
    {
        public static void Run(string key, string outPath)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                ArchiveStore.EnsureBaseLayout();
                ArchiveStore store = new ArchiveStore();
                int before = store.Load(key).Count;
                SaveResult r = store.Save(key, "message", "", "", DateTime.Now.ToString("yyyy-MM-dd"),
                    "（v2.0 P2 自测留言：这条是 Avalonia 版写进来的，用来核对存储协议。）");
                int after = store.Load(key).Count;
                sb.AppendLine("before=" + before + " after=" + after);
                sb.AppendLine("file=" + r.File);
                sb.AppendLine("id=" + r.Id);
                sb.AppendLine("exists=" + File.Exists(r.File));
                if (File.Exists(r.File))
                {
                    string[] lines = File.ReadAllLines(r.File);
                    sb.AppendLine("lines=" + lines.Length);
                    sb.AppendLine("first=" + (lines.Length > 0 ? lines[0] : ""));
                    sb.AppendLine("last=" + (lines.Length > 0 ? lines[lines.Length - 1] : ""));
                }
            }
            catch (Exception ex) { sb.AppendLine("ERROR " + ex); }
            File.WriteAllText(outPath, sb.ToString(), new UTF8Encoding(false));
        }
    }
}
