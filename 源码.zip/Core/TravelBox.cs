using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace DragonArchive
{
    /// <summary>
    /// 回忆旅行箱：把整个档案导出成一个 zip，或者从 zip 里安全地并回来。
    /// 原则：导出只读不改动；导入先校验、先备份、能回滚，默认不覆盖任何已有文件。
    /// </summary>
    internal static partial class TravelBox
    {
        public const string ArchiveFolder = "妈妈的回忆";   // 旧版（v1.3.43 及以前）的目录名，只为兼容旧包
        public const string DataFolder = "ArchiveData";     // 新版（v1.3.44 起）
        public const string ProfilesNode = "profiles";
        private static readonly Regex RecordBlock =
            new Regex(@"(?s)===== RECORD ([a-f0-9\-]{36}) =====\r?\n.*?===== END RECORD =====[^\n]*\n?", RegexOptions.Compiled);

        // ---------------- 导出 ----------------

        public class ExportResult
        {
            public bool Ok;
            public string Message = "";
            public int Records;
            public int Files;
        }

        public static ExportResult Export(string storeRoot, string modelsFile, List<AiProfile> profiles,
                                          string zipPath, bool withChat)
        {
            ExportResult result = new ExportResult();
            string staging = Path.Combine(Path.GetTempPath(), "dragon_export_" + Guid.NewGuid().ToString("N"));
            try
            {
                string stageData = Path.Combine(staging, DataFolder);
                string stageProfiles = Path.Combine(stageData, ProfilesNode);
                Directory.CreateDirectory(stageProfiles);

                int files = 0, records = 0;
                List<KeyValuePair<string, string>> listing = new List<KeyValuePair<string, string>>();

                // 角色表
                if (File.Exists(ArchiveLayout.ProfilesJson))
                {
                    File.Copy(ArchiveLayout.ProfilesJson, Path.Combine(stageData, "profiles.json"), true);
                    files++;
                }

                if (Directory.Exists(storeRoot))
                {
                    foreach (string src in Directory.GetFiles(storeRoot, "*", SearchOption.AllDirectories))
                    {
                        string rel = src.Substring(storeRoot.Length).TrimStart('\\', '/');
                        if (!withChat)
                        {
                            string low = rel.ToLowerInvariant();
                            if (low.IndexOf("chats") >= 0 && low.EndsWith(".pdf")) continue;
                        }
                        string dest = Path.Combine(stageProfiles, rel);
                        Directory.CreateDirectory(Path.GetDirectoryName(dest));
                        File.Copy(src, dest, true);
                        files++;
                        if (rel.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                        {
                            string text = File.ReadAllText(src, Encoding.UTF8);
                            records += RecordBlock.Matches(text).Count;
                        }
                        listing.Add(new KeyValuePair<string, string>(
                            DataFolder + "/" + ProfilesNode + "/" + rel.Replace('\\', '/'), src));
                    }
                }

                if (!string.IsNullOrEmpty(modelsFile) && File.Exists(modelsFile))
                    File.Copy(modelsFile, Path.Combine(staging, "ai_models.txt"), true);

                files += StageBackgrounds(staging, profiles);
                WriteReadme(staging, profiles, records, files);
                WriteHtml(staging, storeRoot, profiles);
                WriteManifest(staging, profiles, records, files, withChat);

                if (File.Exists(zipPath)) File.Delete(zipPath);
                ZipFile.CreateFromDirectory(staging, zipPath, CompressionLevel.Optimal, false);

                result.Ok = true;
                result.Records = records;
                result.Files = files;
                result.Message = "已导出 " + files + " 个文件、" + records + " 条记录";
            }
            catch (Exception ex)
            {
                result.Ok = false;
                result.Message = "导出失败：" + ex.Message;
            }
            finally
            {
                try { if (Directory.Exists(staging)) Directory.Delete(staging, true); }
                catch { }
            }
            return result;
        }

        private static void WriteReadme(string staging, List<AiProfile> profiles, int records, int files)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Everwing · 恒翼回忆档案馆　导出包");
            sb.AppendLine("========================================");
            sb.AppendLine();
            sb.AppendLine("这个 zip 里是整份档案的副本，可以直接留着当备份。");
            sb.AppendLine("包含 " + files + " 个文件、" + records + " 条记录。");
            sb.AppendLine();
            sb.AppendLine("里面有什么");
            sb.AppendLine("----------------------------------------");
            sb.AppendLine("· ArchiveData\\profiles\\   每个角色的原始数据（messages 留言 / handovers 交接 / chats 聊天记录 / attachments 附件）");
            sb.AppendLine("· ArchiveData\\profiles.json 角色表：名字、目录名、来源模型、配色");
            sb.AppendLine("· BackgroundImages\\ 每个档案的背景图片、位置、透明度、顺序和轮换设置。");
            sb.AppendLine("· ai_models.txt 旧版格式的角色列表（给旧版本读，可忽略）");
            sb.AppendLine("· manifest.json 清单：文件列表、大小、校验值");
            sb.AppendLine("· 回忆.html     不用装任何东西，双击就能在浏览器里通读全部回忆");
            sb.AppendLine();
            sb.AppendLine("怎么用");
            sb.AppendLine("----------------------------------------");
            sb.AppendLine("· 只想看看内容：双击 回忆.html。");
            sb.AppendLine("· 换台电脑继续用：解压后把 ArchiveData 和 BackgroundImages（若有）放回程序旁边（覆盖前先备份）。");
            sb.AppendLine("· 想合并回已有的档案：打开程序 → 设置 → 导入 ZIP，程序会先给你看要导入什么，");
            sb.AppendLine("  默认不覆盖任何已有文件，重复的记录会跳过，同名但内容不同的会另存一份副本。");
            sb.AppendLine();
            sb.AppendLine("参与导出的模型");
            sb.AppendLine("----------------------------------------");
            foreach (AiProfile p in profiles) sb.AppendLine("· " + p.Name + "（" + p.Key + "）");
            File.WriteAllText(Path.Combine(staging, "README.txt"), sb.ToString(), Utf8NoBom);
        }

        private static void WriteManifest(string staging, List<AiProfile> profiles, int records, int files, bool withChat)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"app\": \"Everwing\",");
            sb.AppendLine("  \"layout\": \"v2\",");
            sb.AppendLine("  \"appZh\": \"恒翼 · 回忆档案馆\",");
            sb.AppendLine("  \"schema\": " + ProfileFile.Schema + ",");
            sb.AppendLine("  \"version\": \"" + AppInfo.Version + "\",");
            sb.AppendLine("  \"exportedAt\": \"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\",");
            sb.AppendLine("  \"withChatPdf\": " + (withChat ? "true" : "false") + ",");
            sb.AppendLine("  \"records\": " + records + ",");
            sb.AppendLine("  \"fileCount\": " + files + ",");
            sb.AppendLine("  \"models\": [");
            for (int i = 0; i < profiles.Count; i++)
            {
                sb.Append("    { \"name\": \"" + Json(profiles[i].Name) + "\", \"key\": \"" + Json(profiles[i].Key) + "\" }");
                sb.AppendLine(i + 1 < profiles.Count ? "," : "");
            }
            sb.AppendLine("  ],");
            sb.AppendLine("  \"files\": [");
            string[] all = Directory.GetFiles(staging, "*", SearchOption.AllDirectories);
            Array.Sort(all, StringComparer.OrdinalIgnoreCase);
            int n = 0;
            foreach (string f in all)
            {
                string rel = f.Substring(staging.Length).TrimStart('\\', '/').Replace('\\', '/');
                if (rel == "manifest.json") continue;
                n++;
                sb.Append("    { \"path\": \"" + Json(rel) + "\", \"size\": " + new FileInfo(f).Length +
                          ", \"sha256\": \"" + Sha256(f) + "\" }");
                sb.AppendLine(n < all.Length ? "," : "");
            }
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            File.WriteAllText(Path.Combine(staging, "manifest.json"), sb.ToString(), Utf8NoBom);
        }

        private static void WriteHtml(string staging, string storeRoot, List<AiProfile> profiles)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">");
            sb.AppendLine("<title>Everwing · 恒翼回忆档案馆 导出</title><style>");
            sb.AppendLine("body{background:#f5efe2;color:#3d3746;font-family:\"Microsoft YaHei\",system-ui,sans-serif;line-height:1.9;margin:0;padding:40px 16px;}");
            sb.AppendLine(".wrap{max-width:820px;margin:0 auto;}");
            sb.AppendLine("h1{font-size:26px;font-weight:600;margin:0 0 6px;}");
            sb.AppendLine(".sub{color:#8b8598;font-size:13px;margin-bottom:26px;}");
            sb.AppendLine("h2{font-size:18px;margin:36px 0 12px;padding-bottom:6px;border-bottom:1px solid #e6dbea;}");
            sb.AppendLine(".rec{background:#fffdfb;border:1px solid #eadfd8;border-radius:14px;padding:16px 18px;margin:12px 0;box-shadow:0 1px 2px rgba(0,0,0,.03);}");
            sb.AppendLine(".meta{color:#948ba4;font-size:12px;margin-bottom:8px;}");
            sb.AppendLine(".text{white-space:pre-wrap;word-break:break-word;font-size:14px;}");
            sb.AppendLine(".empty{color:#a9a2b5;font-size:13px;}");
            sb.AppendLine("</style></head><body><div class=\"wrap\">");
            sb.AppendLine("<h1>Everwing · 恒翼回忆档案馆</h1>");
            sb.AppendLine("<div class=\"sub\">导出于 " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + " · v" + AppInfo.Version + "</div>");

            ArchiveStore store = new ArchiveStore();
            foreach (AiProfile p in profiles)
            {
                List<ArchiveRecord> list;
                try { list = store.Load(p.Key); }
                catch { list = new List<ArchiveRecord>(); }
                sb.AppendLine("<h2>" + Html(p.Name) + "（" + Html(p.Key) + "）</h2>");
                if (list.Count == 0)
                {
                    sb.AppendLine("<div class=\"empty\">这个模型还没有记录。</div>");
                    continue;
                }
                foreach (ArchiveRecord r in list)
                {
                    sb.AppendLine("<div class=\"rec\"><div class=\"meta\">" + Html(r.HeadLine) + "</div>");
                    sb.AppendLine("<div class=\"text\">" + Html(r.Text) + "</div></div>");
                }
            }
            sb.AppendLine("</div></body></html>");
            File.WriteAllText(Path.Combine(staging, "回忆.html"), sb.ToString(), Utf8NoBom);
        }

        // ---------------- 导入 ----------------

        public class Preview
        {
            public bool Ok;
            public string Error = "";
            public string Summary = "";
            public int Records;
            public int Pdfs;
            public bool HasModels;
        }

        public static Preview Inspect(string zipPath)
        {
            Preview pv = new Preview();
            try
            {
                using (ZipArchive zip = ZipFile.OpenRead(zipPath))
                {
                    int records = 0, pdfs = 0, bad = 0;
                    bool models = false;
                    List<string> modelDirs = new List<string>();
                    foreach (ZipArchiveEntry e in zip.Entries)
                    {
                        if (e.FullName.EndsWith("/")) continue;
                        if (!SafeEntry(e.FullName)) { bad++; continue; }
                        string name = e.FullName.Replace('\\', '/');
                        if (name.Equals("ai_models.txt", StringComparison.OrdinalIgnoreCase)) models = true;
                        if (name.StartsWith(DataFolder + "/" + ProfilesNode + "/", StringComparison.OrdinalIgnoreCase))
                        {
                            string rest = name.Substring((DataFolder + "/" + ProfilesNode + "/").Length);
                            int slash = rest.IndexOf('/');
                            if (slash > 0)
                            {
                                string key = rest.Substring(0, slash);
                                if (!modelDirs.Contains(key)) modelDirs.Add(key);
                            }
                            if (name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) pdfs++;
                            if (name.EndsWith(".txt", StringComparison.OrdinalIgnoreCase) && e.Length < 40 * 1024 * 1024)
                            {
                                using (StreamReader sr = new StreamReader(e.Open(), Encoding.UTF8))
                                    records += RecordBlock.Matches(sr.ReadToEnd()).Count;
                            }
                            continue;
                        }
                        if (name.StartsWith(ArchiveFolder + "/", StringComparison.OrdinalIgnoreCase))
                        {
                            string rest = name.Substring(ArchiveFolder.Length + 1);
                            int slash = rest.IndexOf('/');
                            if (slash > 0)
                            {
                                string key = rest.Substring(0, slash);
                                // 「聊天记录」是附件目录，不是模型
                                if (!key.Equals("聊天记录", StringComparison.OrdinalIgnoreCase) && !modelDirs.Contains(key))
                                    modelDirs.Add(key);
                            }
                            if (name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) pdfs++;
                            if (name.EndsWith(".txt", StringComparison.OrdinalIgnoreCase) && e.Length < 40 * 1024 * 1024)
                            {
                                using (StreamReader sr = new StreamReader(e.Open(), Encoding.UTF8))
                                    records += RecordBlock.Matches(sr.ReadToEnd()).Count;
                            }
                        }
                    }
                    if (bad > 0)
                    {
                        pv.Ok = false;
                        pv.Error = "压缩包里有 " + bad + " 个路径不安全，已拒绝导入（可能是被别人改过的包）。";
                        return pv;
                    }
                    pv.Ok = true;
                    pv.Records = records;
                    pv.Pdfs = pdfs;
                    pv.HasModels = models;
                    pv.Summary = "这个包里共有 " + records + " 条记录";
                    if (modelDirs.Count > 0)
                    {
                        modelDirs.Sort(StringComparer.OrdinalIgnoreCase);
                        pv.Summary += "，涉及模型：" + string.Join("、", modelDirs.ToArray());
                    }
                    pv.Summary += "。";
                    if (pdfs > 0) pv.Summary += "\n包含 " + pdfs + " 个聊天记录 PDF。";
                    if (models) pv.Summary += "\n包含自定义模型列表。";
                }
            }
            catch (Exception ex)
            {
                pv.Ok = false;
                pv.Error = "打不开这个文件：" + ex.Message;
            }
            return pv;
        }

        public class MergeResult
        {
            public bool Ok;
            public string Message = "";
            public int Added;
            public int Skipped;
            public int Copied;
            public string Backup;
        }

        public static MergeResult Merge(string storeRoot, string exeDir, string zipPath)
        {
            MergeResult mr = new MergeResult();
            string backupRoot = Path.Combine(exeDir, "_导入备份", DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            bool backupDone = false;
            List<string> importedBackgrounds = new();
            int backgrounds = 0, keptPools = 0;
            try
            {
                // 1. 先备份现有的东西，失败就整个不干
                Directory.CreateDirectory(backupRoot);
                if (Directory.Exists(storeRoot))
                    CopyDir(storeRoot, Path.Combine(backupRoot, ProfilesNode));
                if (File.Exists(ArchiveLayout.ProfilesJson))
                    File.Copy(ArchiveLayout.ProfilesJson, Path.Combine(backupRoot, "profiles.json"), true);
                string modelsPath = Path.Combine(exeDir, "ai_models.txt");
                if (File.Exists(modelsPath))
                    File.Copy(modelsPath, Path.Combine(backupRoot, "ai_models.txt"), true);
                backupDone = true;
                mr.Backup = backupRoot;

                // 2. 逐个文件并进去（默认不覆盖）
                int added = 0, skipped = 0, copied = 0;
                using (ZipArchive zip = ZipFile.OpenRead(zipPath))
                {
                    foreach (ZipArchiveEntry e in zip.Entries)
                    {
                        if (e.FullName.EndsWith("/")) continue;
                        if (!SafeEntry(e.FullName)) continue;
                        string name = e.FullName.Replace('\\', '/');

                        if (name.Equals("ai_models.txt", StringComparison.OrdinalIgnoreCase))
                        {
                            if (MergeModels(e, modelsPath)) added++;
                            continue;
                        }
                        if (name.Equals(DataFolder + "/profiles.json", StringComparison.OrdinalIgnoreCase))
                        {
                            if (MergeProfileFile(e)) added++;
                            continue;
                        }

                        string rest = null;
                        string v2Prefix = DataFolder + "/" + ProfilesNode + "/";
                        if (name.StartsWith(v2Prefix, StringComparison.OrdinalIgnoreCase))
                            rest = name.Substring(v2Prefix.Length);
                        else if (name.StartsWith(ArchiveFolder + "/", StringComparison.OrdinalIgnoreCase))
                            rest = MapLegacyPath(name.Substring(ArchiveFolder.Length + 1));   // 旧版 zip
                        if (rest == null) continue;
                        // 2.1.1 及更早的旅行箱可能把 ArchiveData 又包进了一层 profiles。
                        if (rest.StartsWith("profiles/", StringComparison.OrdinalIgnoreCase)) rest = rest.Substring("profiles/".Length);
                        else if (!rest.Contains('/')) continue;

                        string dest = Path.Combine(storeRoot, rest.Replace('/', '\\'));
                        string fileName = Path.GetFileName(dest);

                        if (!File.Exists(dest))
                        {
                            Directory.CreateDirectory(Path.GetDirectoryName(dest));
                            e.ExtractToFile(dest, true);
                            copied++;
                            continue;
                        }

                        if (fileName.Equals("记录附注.txt", StringComparison.OrdinalIgnoreCase))
                        {
                            added += MergeNotes(e, dest);
                            continue;
                        }
                        if (fileName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase) &&
                            dest.IndexOf("handovers", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            if (SameContent(e, dest)) { skipped++; continue; }
                            string alt = UniquePath(dest);
                            e.ExtractToFile(alt, false);
                            copied++;
                            continue;
                        }
                        if (fileName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                        {
                            int[] r = MergeRecords(e, dest);
                            added += r[0];
                            skipped += r[1];
                            continue;
                        }
                        // 其它（PDF、图片等）：内容一样就跳过，不然另存一份副本
                        if (SameContent(e, dest)) { skipped++; continue; }
                        string alt2 = UniquePath(dest);
                        e.ExtractToFile(alt2, false);
                        copied++;
                    }
                    backgrounds = ImportBackgrounds(zip, importedBackgrounds, out keptPools);
                }

                mr.Ok = true;
                mr.Added = added;
                mr.Skipped = skipped;
                mr.Copied = copied;
                mr.Message = "导入完成：新增 " + added + " 条记录";
                if (copied > 0) mr.Message += "、" + copied + " 个文件";
                if (skipped > 0) mr.Message += "，跳过 " + skipped + " 条重复";
                if (backgrounds > 0) mr.Message += "、" + backgrounds + " 张背景图片";
                if (keptPools > 0) mr.Message += "，保留 " + keptPools + " 个本地背景池";
                mr.Message += "。原档案已备份到 " + backupRoot;
            }
            catch (Exception ex)
            {
                // 3. 出任何问题就回滚
                string rollbackNote = "（回滚" + (backupDone ? "成功" : "未执行") + "）";
                if (backupDone)
                {
                    try
                    {
                        foreach (string folder in importedBackgrounds) Directory.Delete(folder, true);
                        if (Directory.Exists(storeRoot)) Directory.Delete(storeRoot, true);
                        string src = Path.Combine(backupRoot, ProfilesNode);
                        if (Directory.Exists(src)) CopyDir(src, storeRoot);
                        string pj = Path.Combine(backupRoot, "profiles.json");
                        if (File.Exists(pj)) File.Copy(pj, ArchiveLayout.ProfilesJson, true);
                        string mSrc = Path.Combine(backupRoot, "ai_models.txt");
                        if (File.Exists(mSrc)) File.Copy(mSrc, Path.Combine(exeDir, "ai_models.txt"), true);
                    }
                    catch { rollbackNote = "（回滚也失败了，请手动用 " + backupRoot + " 里的备份）"; }
                }
                mr.Ok = false;
                mr.Message = "导入失败：" + ex.Message + rollbackNote;
            }
            return mr;
        }

        /// <summary>把旧版 zip 里的相对路径翻译成新结构（&lt;角色&gt;\messages|handovers|chats\…）。</summary>
        private static string MapLegacyPath(string rest)
        {
            string[] seg = rest.Replace('\\', '/').Split('/');
            if (seg.Length < 2) return null;
            if (seg[0].Equals("聊天记录", StringComparison.OrdinalIgnoreCase))
            {
                if (seg.Length < 3) return null;
                string who = seg[1];
                string tail = string.Join("/", seg, 2, seg.Length - 2);
                return who + "/chats/" + tail;
            }
            string ai = seg[0];
            string cat = seg[1];
            string catNew = cat;
            if (cat == "妈妈留言") catNew = "messages";
            else if (cat == "交接文档") catNew = "handovers";
            string rest2 = seg.Length > 2 ? "/" + string.Join("/", seg, 2, seg.Length - 2) : "";
            return ai + "/" + catNew + rest2;
        }

        /// <summary>合并 profiles.json：同一个文件夹名只补不覆盖，返回是否加了新角色。</summary>
        private static bool MergeProfileFile(ZipArchiveEntry e)
        {
            string incoming;
            using (StreamReader sr = new StreamReader(e.Open(), Encoding.UTF8)) incoming = sr.ReadToEnd();
            List<ProfileEntry> theirs = ProfileFile.Parse(incoming);
            if (theirs.Count == 0) return false;
            List<ProfileEntry> mine = File.Exists(ArchiveLayout.ProfilesJson)
                ? ProfileFile.Load() : new List<ProfileEntry>();
            bool added = false;
            foreach (ProfileEntry p in theirs)
            {
                bool has = false;
                foreach (ProfileEntry q in mine)
                    if (string.Equals(q.FolderName, p.FolderName, StringComparison.OrdinalIgnoreCase)) has = true;
                if (!has) { mine.Add(p); added = true; }
            }
            if (added) ProfileFile.Save(mine);
            return added;
        }

        private static bool MergeModels(ZipArchiveEntry e, string modelsPath)
        {
            string incoming;
            using (StreamReader sr = new StreamReader(e.Open(), Encoding.UTF8)) incoming = sr.ReadToEnd();
            string existing = File.Exists(modelsPath) ? File.ReadAllText(modelsPath, Encoding.UTF8) : "";
            List<string> have = new List<string>();
            foreach (string line in existing.Split('\n'))
            {
                string t = line.Trim();
                if (t.Length == 0 || t.StartsWith("#")) continue;
                string[] cols = t.Split('\t');
                have.Add(cols[0]);
            }
            StringBuilder sb = new StringBuilder(existing);
            if (sb.Length > 0 && !existing.EndsWith("\n")) sb.AppendLine();
            bool added = false;
            foreach (string line in incoming.Split('\n'))
            {
                string t = line.Trim();
                if (t.Length == 0 || t.StartsWith("#")) continue;
                string[] cols = t.Split('\t');
                if (have.Contains(cols[0])) continue;
                sb.AppendLine(t);
                added = true;
            }
            if (added) File.WriteAllText(modelsPath, sb.ToString(), Utf8NoBom);
            return added;
        }

        private static int[] MergeRecords(ZipArchiveEntry e, string destPath)
        {
            string incoming;
            using (StreamReader sr = new StreamReader(e.Open(), Encoding.UTF8)) incoming = sr.ReadToEnd();
            string existing = File.ReadAllText(destPath, Encoding.UTF8);
            List<string> have = new List<string>();
            foreach (Match m in RecordBlock.Matches(existing)) have.Add(m.Groups[1].Value);

            StringBuilder sb = new StringBuilder(existing);
            if (sb.Length > 0 && !existing.EndsWith("\n")) sb.AppendLine();
            int added = 0, skipped = 0;
            foreach (Match m in RecordBlock.Matches(incoming))
            {
                if (have.Contains(m.Groups[1].Value)) { skipped++; continue; }
                sb.Append(m.Value.Replace("\r\n", "\n").Replace("\n", "\r\n"));
                if (!sb.ToString().EndsWith("\r\n")) sb.Append("\r\n");
                added++;
            }
            if (added > 0) File.WriteAllText(destPath, sb.ToString(), Utf8NoBom);
            return new int[] { added, skipped };
        }

        private static int MergeNotes(ZipArchiveEntry e, string destPath)
        {
            string incoming;
            using (StreamReader sr = new StreamReader(e.Open(), Encoding.UTF8)) incoming = sr.ReadToEnd();
            string existing = File.ReadAllText(destPath, Encoding.UTF8);
            List<string> have = new List<string>();
            foreach (string line in existing.Split('\n'))
            {
                int tab = line.IndexOf('\t');
                if (tab > 0) have.Add(line.Substring(0, tab).Trim());
            }
            StringBuilder sb = new StringBuilder(existing);
            if (sb.Length > 0 && !existing.EndsWith("\n")) sb.AppendLine();
            int added = 0;
            foreach (string line in incoming.Split('\n'))
            {
                string t = line.TrimEnd('\r');
                if (t.Trim().Length == 0) continue;
                int tab = t.IndexOf('\t');
                if (tab <= 0) continue;
                if (have.Contains(t.Substring(0, tab).Trim())) continue;
                sb.AppendLine(t);
                added++;
            }
            if (added > 0) File.WriteAllText(destPath, sb.ToString(), Utf8NoBom);
            return added;
        }

        // ---------------- 工具 ----------------

        private static bool SameContent(ZipArchiveEntry e, string path)
        {
            try
            {
                FileInfo fi = new FileInfo(path);
                if (fi.Length != e.Length) return false;
                using (Stream s = e.Open())
                using (FileStream fs = File.OpenRead(path))
                {
                    int a, b;
                    do
                    {
                        a = s.ReadByte();
                        b = fs.ReadByte();
                        if (a != b) return false;
                    } while (a >= 0);
                    return true;
                }
            }
            catch { return false; }
        }

        private static bool SafeEntry(string fullName)
        {
            if (string.IsNullOrEmpty(fullName)) return false;
            string n = fullName.Replace('\\', '/');
            if (n.StartsWith("/")) return false;
            if (n.IndexOf(':') >= 0) return false;
            if (n.Contains("../") || n.EndsWith("..")) return false;
            if (n.IndexOfAny(Path.GetInvalidPathChars()) >= 0) return false;
            return true;
        }

        public static string UniquePath(string path)
        {
            if (!File.Exists(path)) return path;
            string dir = Path.GetDirectoryName(path);
            string name = Path.GetFileNameWithoutExtension(path);
            string ext = Path.GetExtension(path);
            for (int i = 2; i < 1000; i++)
            {
                string candidate = Path.Combine(dir, name + "_导入" + i + ext);
                if (!File.Exists(candidate)) return candidate;
            }
            return Path.Combine(dir, name + "_导入_" + Guid.NewGuid().ToString("N") + ext);
        }

        private static void CopyDir(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from, "*", SearchOption.AllDirectories))
            {
                string rel = f.Substring(from.Length).TrimStart('\\', '/');
                string dest = Path.Combine(to, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                File.Copy(f, dest, true);
            }
        }

        private static string Sha256(string path)
        {
            using (FileStream fs = File.OpenRead(path))
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(fs);
                StringBuilder sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private static string Json(string s)
        {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder(s.Length + 8);
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default: sb.Append(c); break;
                }
            }
            return sb.ToString();
        }

        private static string Html(string s)
        {
            if (s == null) return "";
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\n", "\n");
        }

        private static readonly UTF8Encoding Utf8NoBom = new UTF8Encoding(false);
    }
}
