using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace DragonArchive
{
    /// <summary>一条附件：属于某条记录，文件本身躺在 <角色>\attachments\&lt;类别&gt;\yyyy\MM\dd\ 下。</summary>
    public class Attachment
    {
        public string Id;
        public string RecordId;
        public string Kind;          // images / documents / audio / other
        public string RelPath;       // 相对角色目录，用反斜杠
        public string Name;          // 原文件名
        public string ImportedAt;    // yyyy-MM-dd HH:mm:ss
        public string Sha256;
        public long Size;

        public string KindLabel
        {
            get
            {
                switch (Kind)
                {
                    case "images": return "图片";
                    case "documents": return "文档";
                    case "audio": return "音频";
                    default: return "文件";
                }
            }
        }

        public string SizeText
        {
            get
            {
                if (Size < 1024) return Size + " B";
                if (Size < 1024 * 1024) return (Size / 1024.0).ToString("0.#") + " KB";
                return (Size / 1024.0 / 1024.0).ToString("0.#") + " MB";
            }
        }

        public Attachment Copy()
        {
            Attachment a = new Attachment();
            a.Id = Id; a.RecordId = RecordId; a.Kind = Kind; a.RelPath = RelPath;
            a.Name = Name; a.ImportedAt = ImportedAt; a.Sha256 = Sha256; a.Size = Size;
            return a;
        }
    }

    /// <summary>附件的索引文件（每个角色一份）：&lt;角色&gt;\attachments\index.tsv。</summary>
    public class AttachmentStore
    {
        private readonly string profileDir;

        public AttachmentStore(string profileDir)
        {
            this.profileDir = profileDir;
        }

        public string ProfileDir { get { return profileDir; } }
        public string AttachRoot { get { return Path.Combine(profileDir, "attachments"); } }
        public string IndexPath { get { return Path.Combine(AttachRoot, "index.tsv"); } }

        /// <summary>按扩展名判断归属哪一类。</summary>
        public static string KindOf(string path)
        {
            string ext = (Path.GetExtension(path) ?? "").ToLowerInvariant();
            switch (ext)
            {
                case ".png": case ".jpg": case ".jpeg": case ".webp": case ".gif": case ".bmp":
                    return "images";
                case ".pdf": case ".txt": case ".md": case ".doc": case ".docx":
                case ".xls": case ".xlsx": case ".ppt": case ".pptx": case ".rtf": case ".csv":
                    return "documents";
                case ".mp3": case ".wav": case ".m4a": case ".flac": case ".ogg": case ".aac":
                    return "audio";
                default:
                    return "other";
            }
        }

        public string FullPath(Attachment a)
        {
            if (a == null || string.IsNullOrEmpty(a.RelPath)) return "";
            return Path.Combine(profileDir, a.RelPath.Replace('/', '\\'));
        }

        public bool Exists(Attachment a)
        {
            string p = FullPath(a);
            return p.Length > 0 && File.Exists(p);
        }

        /// <summary>读索引；recordId 为空表示全都要。</summary>
        public List<Attachment> Load(string recordId)
        {
            List<Attachment> list = new List<Attachment>();
            try
            {
                if (!File.Exists(IndexPath)) return list;
                foreach (string raw in File.ReadAllLines(IndexPath, Encoding.UTF8))
                {
                    if (raw.Length == 0 || raw[0] == '#') continue;
                    string[] f = raw.Split('\t');
                    if (f.Length < 8) continue;
                    Attachment a = new Attachment();
                    a.Id = f[0];
                    a.RecordId = f[1];
                    a.Kind = f[2];
                    a.RelPath = Unesc(f[3]);
                    a.Name = Unesc(f[4]);
                    a.ImportedAt = f[5];
                    a.Sha256 = f[6];
                    long sz;
                    long.TryParse(f[7], out sz);
                    a.Size = sz;
                    if (recordId == null || a.RecordId == recordId) list.Add(a);
                }
            }
            catch { }
            return list;
        }

        /// <summary>把外部文件复制进来并登记，返回登记好的附件。</summary>
        public Attachment Add(string recordId, string sourcePath, string originNote)
        {
            if (string.IsNullOrEmpty(recordId)) throw new InvalidOperationException("缺少记录 ID");
            if (!File.Exists(sourcePath)) throw new FileNotFoundException("找不到这个文件", sourcePath);

            string kind = KindOf(sourcePath);
            string id = Guid.NewGuid().ToString("N").Substring(0, 12);
            DateTime now = DateTime.Now;
            string relDir = Path.Combine("attachments", kind,
                now.ToString("yyyy"), now.ToString("MM"), now.ToString("dd"));
            string absDir = Path.Combine(profileDir, relDir);
            Directory.CreateDirectory(absDir);

            string baseName = Path.GetFileName(sourcePath);
            string clean = CleanFileName(baseName);
            string rel = Path.Combine(relDir, id + "_" + clean);
            string abs = Path.Combine(profileDir, rel);
            int n = 2;
            while (File.Exists(abs))
            {
                rel = Path.Combine(relDir, id + "_" + n + "_" + clean);
                abs = Path.Combine(profileDir, rel);
                n++;
            }
            File.Copy(sourcePath, abs, false);

            Attachment a = new Attachment();
            a.Id = id;
            a.RecordId = recordId;
            a.Kind = kind;
            a.RelPath = rel;
            a.Name = baseName;
            a.ImportedAt = now.ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
            a.Size = new FileInfo(abs).Length;
            a.Sha256 = Sha256Of(abs);
            AppendLine(a);
            return a;
        }

        /// <summary>解除关联；同一个文件没有别的记录在用时才删掉实体。</summary>
        public bool RemoveLink(string attId)
        {
            List<Attachment> all = Load(null);
            Attachment gone = null;
            foreach (Attachment a in all) if (a.Id == attId) { gone = a; break; }
            if (gone == null) return false;

            List<Attachment> keep = new List<Attachment>();
            foreach (Attachment a in all) if (a.Id != attId) keep.Add(a);

            // 改索引前先备份一份；写失败直接抛出去，不谎报成功
            try
            {
                if (File.Exists(IndexPath)) File.Copy(IndexPath, IndexPath + ".bak", true);
            }
            catch { }

            WriteAll(keep);

            // 回读核对：索引里不应再出现这条
            List<Attachment> after = Load(null);
            foreach (Attachment a in after)
                if (a.Id == attId) throw new IOException("附件索引没有写入成功。");

            return true;
        }

        public void UnlinkRecord(string recordId)
        {
            if (string.IsNullOrEmpty(recordId)) return;
            List<Attachment> all = Load(null);
            List<Attachment> keep = new List<Attachment>();
            foreach (Attachment a in all)
                if (!string.Equals(a.RecordId, recordId, StringComparison.OrdinalIgnoreCase)) keep.Add(a);
            if (keep.Count != all.Count) WriteAll(keep);
        }
        /// <summary>老版本把 PDF 关联写在 chats\links.txt 里，第一次运行时补进索引。</summary>
        public int MigrateLegacyLinks()
        {
            try
            {
                string legacy = Path.Combine(profileDir, "chats", "links.txt");
                if (!File.Exists(legacy)) return 0;
                List<Attachment> existing = Load(null);
                HashSet<string> known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (Attachment a in existing) known.Add(a.RecordId + "|" + a.RelPath.Replace('\\', '/'));

                int added = 0;
                foreach (string raw in File.ReadAllLines(legacy, Encoding.UTF8))
                {
                    string line = raw.Trim();
                    if (line.Length == 0) continue;
                    string[] f = line.Split('\t');
                    if (f.Length < 2) continue;
                    string rid = f[0].Trim();
                    string rel = NormalizeOld(f[1].Trim());
                    if (rid.Length == 0 || rel.Length == 0) continue;
                    string key = rid + "|" + rel.Replace('\\', '/');
                    if (known.Contains(key)) continue;

                    string abs = Path.Combine(profileDir, rel);
                    if (!File.Exists(abs)) continue;

                    Attachment a = new Attachment();
                    a.Id = Guid.NewGuid().ToString("N").Substring(0, 12);
                    a.RecordId = rid;
                    a.Kind = KindOf(rel);
                    a.RelPath = rel;
                    a.Name = Path.GetFileName(rel);
                    a.ImportedAt = File.GetLastWriteTime(abs).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                    a.Size = new FileInfo(abs).Length;
                    a.Sha256 = Sha256Of(abs);
                    existing.Add(a);
                    known.Add(key);
                    added++;
                }
                if (added > 0) WriteAll(existing);
                return added;
            }
            catch { return 0; }
        }

        private static string NormalizeOld(string rel)
        {
            string r = rel.Replace('/', '\\');
            if (r.StartsWith("chats\\", StringComparison.OrdinalIgnoreCase)) return r;
            int p = r.IndexOf("聊天记录\\", StringComparison.Ordinal);
            if (p >= 0)
            {
                string rest = r.Substring(p + "聊天记录\\".Length);
                int slash = rest.IndexOf('\\');
                if (slash >= 0) return Path.Combine("chats", rest.Substring(slash + 1));
            }
            return r;
        }

        public static string CleanFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "file";
            StringBuilder sb = new StringBuilder();
            foreach (char c in name)
            {
                if (c < 32 || c == '\\' || c == '/' || c == ':' || c == '*' ||
                    c == '?' || c == '"' || c == '<' || c == '>' || c == '|') sb.Append('_');
                else sb.Append(c);
            }
            string s = sb.ToString().Trim();
            if (s.Length > 60)
            {
                string ext = Path.GetExtension(s);
                if (ext.Length > 12) ext = "";
                s = s.Substring(0, 60 - ext.Length) + ext;
            }
            if (s.Length == 0) s = "file";
            return s;
        }

        public static string Sha256Of(string path)
        {
            try
            {
                using (FileStream fs = File.OpenRead(path))
                using (SHA256 sha = SHA256.Create())
                {
                    byte[] hash = sha.ComputeHash(fs);
                    StringBuilder sb = new StringBuilder();
                    foreach (byte b in hash) sb.Append(b.ToString("x2"));
                    return sb.ToString();
                }
            }
            catch { return ""; }
        }

        private void AppendLine(Attachment a)
        {
            Directory.CreateDirectory(AttachRoot);
            bool needHeader = !File.Exists(IndexPath);
            StringBuilder sb = new StringBuilder();
            if (needHeader) sb.Append("# 附件索引：id\t记录ID\t类别\t相对路径\t原文件名\t导入时间\tsha256\t字节数\r\n");
            sb.Append(Line(a)).Append("\r\n");
            File.AppendAllText(IndexPath, sb.ToString(), new UTF8Encoding(false));
        }

        private void WriteAll(List<Attachment> list)
        {
            Directory.CreateDirectory(AttachRoot);
            StringBuilder sb = new StringBuilder();
            sb.Append("# 附件索引：id\t记录ID\t类别\t相对路径\t原文件名\t导入时间\tsha256\t字节数\r\n");
            foreach (Attachment a in list) sb.Append(Line(a)).Append("\r\n");
            File.WriteAllText(IndexPath, sb.ToString(), new UTF8Encoding(false));
        }

        private static string Line(Attachment a)
        {
            return string.Join("\t", new string[] {
                a.Id, a.RecordId, a.Kind, Esc(a.RelPath), Esc(a.Name),
                a.ImportedAt, a.Sha256,
                a.Size.ToString(System.Globalization.CultureInfo.InvariantCulture)
            });
        }

        private static string Esc(string s)
        {
            if (s == null) return "";
            return s.Replace("\\", "\\\\").Replace("\t", "\\t").Replace("\r", "").Replace("\n", "\\n");
        }

        private static string Unesc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '\\' && i + 1 < s.Length)
                {
                    char c = s[i + 1];
                    if (c == '\\') { sb.Append('\\'); i++; continue; }
                    if (c == 't') { sb.Append('\t'); i++; continue; }
                    if (c == 'n') { sb.Append('\n'); i++; continue; }
                }
                sb.Append(s[i]);
            }
            return sb.ToString();
        }
    }
}
