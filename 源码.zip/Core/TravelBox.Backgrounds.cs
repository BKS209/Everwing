using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace DragonArchive;

internal static partial class TravelBox
{
    private static int StageBackgrounds(string staging, List<AiProfile> profiles)
    {
        int files = 0;
        foreach (AiProfile profile in profiles)
        {
            var store = new BackgroundStore(profile.Key);
            var pool = store.Load();
            pool.Images.RemoveAll(image => !File.Exists(store.PathFor(image)));
            if (pool.Images.Count == 0) continue;

            string target = Path.Combine(staging, BackgroundStore.Folder, FolderName.Safe(profile.Key));
            Directory.CreateDirectory(target);
            foreach (var image in pool.Images)
                File.Copy(store.PathFor(image), Path.Combine(target, image.FileName));
            File.WriteAllText(Path.Combine(target, "pool.json"), BackgroundStore.Serialize(pool));
            files += pool.Images.Count + 1;
        }
        return files;
    }

    private static int ImportBackgrounds(ZipArchive zip, List<string> created, out int kept)
    {
        kept = 0;
        const string prefix = BackgroundStore.Folder + "/";
        var entries = new Dictionary<string, ZipArchiveEntry>(StringComparer.OrdinalIgnoreCase);
        foreach (var entry in zip.Entries)
        {
            string name = entry.FullName.Replace('\\', '/');
            if (!name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || name.EndsWith('/')) continue;
            if (!SafeEntry(name) || !entries.TryAdd(name, entry))
                throw new InvalidDataException("ZIP 中的背景文件路径无效或重复。");
        }

        int restored = 0;
        var profileKeys = new HashSet<string>(AiProfiles.Load().Select(p => FolderName.Safe(p.Key)), StringComparer.OrdinalIgnoreCase);
        foreach (var pair in entries)
        {
            string[] path = pair.Key.Split('/');
            if (path.Length != 3 || !path[2].Equals("pool.json", StringComparison.OrdinalIgnoreCase) || !profileKeys.Contains(path[1])) continue;

            var store = new BackgroundStore(path[1]);
            if (Directory.Exists(store.DirectoryPath)) { kept++; continue; }
            if (pair.Value.Length > 16 * 1024 * 1024) throw new InvalidDataException("背景图片池清单太大。");
            using var reader = new StreamReader(pair.Value.Open());
            var pool = BackgroundStore.Parse(reader.ReadToEnd());
            if (pool.Images.Count == 0) continue;

            string root = Path.GetDirectoryName(store.DirectoryPath)!;
            Directory.CreateDirectory(root);
            string staging = Path.Combine(root, $".import-{Guid.NewGuid():N}");
            Directory.CreateDirectory(staging);
            try
            {
                foreach (var image in pool.Images)
                {
                    if (!entries.TryGetValue(prefix + path[1] + "/" + image.FileName, out var entry))
                        throw new InvalidDataException("ZIP 中缺少背景图片：" + image.Label);
                    entry.ExtractToFile(Path.Combine(staging, image.FileName));
                }
                File.WriteAllText(Path.Combine(staging, "pool.json"), BackgroundStore.Serialize(pool));
                Directory.Move(staging, store.DirectoryPath);
                created.Add(store.DirectoryPath);
                restored += pool.Images.Count;
            }
            finally { if (Directory.Exists(staging)) Directory.Delete(staging, true); }
        }
        return restored;
    }
}
