using System;
using System.IO;

namespace DragonArchive
{
    /// <summary>
    /// v2.0：替代 WinForms 的 Application.ExecutablePath。
    /// 优先读 EVERWING_HOME（方便把数据放在别的目录/做只读校对），否则用进程所在目录。
    /// </summary>
    internal static class EverwingPaths
    {
        public static string ExeDir()
        {
            string env = null;
            try { env = Environment.GetEnvironmentVariable("EVERWING_HOME"); } catch { }
            if (!string.IsNullOrEmpty(env) && Directory.Exists(env)) return env;

            string p = null;
            try { p = Environment.ProcessPath; } catch { }
            string dir = string.IsNullOrEmpty(p) ? null : Path.GetDirectoryName(p);
            if (string.IsNullOrEmpty(dir)) dir = AppContext.BaseDirectory;
            if (string.IsNullOrEmpty(dir)) dir = Environment.CurrentDirectory;
            return dir;
        }
    }
}
