using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DragonArchive
{
    /// <summary>P2 校对用：只读地把 ArchiveData 读一遍，把条数写进 verify-log.txt。</summary>
    internal static class DataCheck
    {
        public static void Run(string outPath)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.AppendLine("exeDir = " + EverwingPaths.ExeDir());
                sb.AppendLine("dataRoot = " + ArchiveLayout.DataRoot);
                sb.AppendLine("dataRootExists = " + Directory.Exists(ArchiveLayout.DataRoot));
                List<string> problems = ArchiveStore.EnsureBaseLayout();
                sb.AppendLine("layoutProblems = " + problems.Count);
                foreach (string s in problems) sb.AppendLine("  ! " + s);

                List<AiProfile> profiles = AiProfiles.Load();
                sb.AppendLine("profiles = " + profiles.Count);
                sb.AppendLine("loadProblem = " + AiProfiles.LoadProblem);

                ArchiveStore store = new ArchiveStore();
                int totalMsg = 0, totalHo = 0, totalAtt = 0, totalMarkers = 0, totalLinks = 0;
                foreach (AiProfile p in profiles)
                {
                    List<ArchiveRecord> recs = store.Load(p.Key);
                    int msg = 0, ho = 0, att = 0;
                    foreach (ArchiveRecord r in recs)
                    {
                        if (r.Type == "handover") ho++; else msg++;
                        att += r.Attachments.Count;
                    }
                    Dictionary<string, RecordNote> notes = store.LoadNotes(p.Key);
                    Dictionary<string, string> links = store.LoadLinks(p.Key);
                    sb.AppendLine("profile " + p.Key + " | name=" + p.Name + " | records=" + recs.Count
                        + " msg=" + msg + " ho=" + ho + " attach=" + att
                        + " notes=" + notes.Count + " links=" + links.Count);
                    totalMsg += msg; totalHo += ho; totalAtt += att;
                    totalMarkers += notes.Count; totalLinks += links.Count;
                }
                string detail = Environment.GetEnvironmentVariable("VERIFY_DETAIL") ?? "";
                if (detail.Length > 0)
                {
                    foreach (AiProfile p in profiles)
                    {
                        if (p.Key != detail) continue;
                        foreach (ArchiveRecord r in store.Load(p.Key))
                        {
                            string head = r.Text ?? "";
                            if (head.Length > 30) head = head.Substring(0, 30);
                            head = head.Replace("\r", " ").Replace("\n", " ");
                            sb.AppendLine("REC " + r.Id + " | " + r.Type + " | " + r.Date + " | " + r.SavedAt + " | len=" + (r.Text ?? "").Length + " | " + head);
                        }
                    }
                }                sb.AppendLine("TOTAL msg=" + totalMsg + " ho=" + totalHo + " attach=" + totalAtt
                    + " notes=" + totalMarkers + " links=" + totalLinks);
            }
            catch (Exception ex)
            {
                sb.AppendLine("ERROR " + ex);
            }
            File.WriteAllText(outPath, sb.ToString(), new UTF8Encoding(false));
        }
    }
}
