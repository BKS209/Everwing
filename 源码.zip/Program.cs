using System;
using System.IO;
using Avalonia;

namespace Everwing;

internal static class Program
{
    [STAThread]
    public static void Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "--verify-data")
        {
            DragonArchive.DataCheck.Run(Path.Combine(AppContext.BaseDirectory, "verify-log.txt"));
            return;
        }
        if (args.Length > 1 && args[0] == "--save-test")
        {
            DragonArchive.SaveTest.Run(args[1], Path.Combine(AppContext.BaseDirectory, "save-log.txt"));
            return;
        }

        try
        {
            BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }
        catch (Exception ex)
        {
            try
            {
                string dir = Path.GetDirectoryName(Environment.ProcessPath ?? AppContext.BaseDirectory) ?? AppContext.BaseDirectory;
                File.AppendAllText(Path.Combine(dir, "startup-error.log"), "[" + DateTime.Now.ToString("HH:mm:ss") + "] Main: " + ex + "\r\n\r\n");
            }
            catch { }
            throw;
        }
    }

    public static AppBuilder BuildAvaloniaApp()
        => AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .LogToTrace();
}
